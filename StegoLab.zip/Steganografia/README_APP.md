# StegoLab — aplikacja do demonstracji, testowania i analizy algorytmów

StegoLab to aplikacja okienkowa (PySide6) zbudowana na algorytmach z tego repozytorium. Pozwala
wybrać algorytm, poznać zasadę jego działania, przeprowadzić demonstrację, wykonać test na serii
tekstów, porównać algorytmy, przeglądać historię eksperymentów, importować publikacje źródłowe
(PDF), przypisywać je do algorytmów i eksportować wyniki do raportów PDF / CSV / JSON.

Aplikacja **nie zastępuje** algorytmów uproszczonymi wersjami: woła oryginalne klasy i funkcje
z pakietów `unigram_watermark` i `synthid_watermark` oraz funkcje pomocnicze z `demo.py`
i `demo_synthid.py`. Żaden plik oryginalnego repozytorium nie został zmieniony ani usunięty.

---

## 1. Najważniejsze ustalenie z analizy repozytorium

Repozytorium nie zawiera steganografii obrazowej. Zawiera dwa algorytmy **znakowania wodnego
tekstu generowanego przez duże modele językowe** (steganografia lingwistyczna typu *zero-bit*):

| | Unigram-Watermark | SynthID-Text (Tournament sampling) |
|---|---|---|
| Publikacja | Zhao, Ananth, Li, Wang, *Provable Robust Watermarking for AI-Generated Text*, arXiv:2306.17439 (ICLR 2024) | Dathathri i in., *Scalable watermarking for identifying large language model outputs*, Nature 634 (2024) |
| Pakiet | `unigram_watermark` (`UnigramWatermark`, `generate`) | `synthid_watermark` (`TournamentWatermark`, `generate`) |
| Weryfikacja | 25 testów w `tests/test_core.py` (Tw. 3.1, 3.7, FPR) – **przechodzą** | 7 testów w `tests/test_synthid.py` – **przechodzą** |

Konsekwencje dla aplikacji:

* „Kodowanie” = generacja tekstu przez model językowy ze znakiem wodnym; „dekodowanie” = detekcja
  znaku testem statystycznym z kluczem. Osadzany jest **jeden bit** (obecność znaku), nie wiadomość.
* Metryki obrazowe **PSNR, MSE, MAE, SSIM nie są liczone** – nośnikiem jest tekst, nie obraz.
* **BER nie jest liczony** – nie ma ciągu bitów wiadomości do porównania.
* **Pojemność w bitach nie jest liczona** – zawsze wynosi 1 bit na tekst.
* Zamiast nich aplikacja liczy metryki z publikacji i skryptów demo: z-score, p-value, TPR/FPR
  (z przedziałami ufności), AUC, TPR przy ustalonym FPR, perplexity, czasy generacji i detekcji,
  odporność na edycje, kontrolę z błędnym kluczem.

## 2. Instalacja

Wymagany Python ≥ 3.10.

```bash
git clone https://github.com/hubertiwan/Steganografia.git
cd Steganografia
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements-app.txt
```

`requirements-app.txt` dołącza zależności oryginalnego projektu (`requirements.txt`: numpy, torch,
transformers, accelerate, matplotlib, pytest) oraz PySide6, PyMuPDF, reportlab i pytest-qt.
Na Windows z kartą NVIDIA warto zainstalować PyTorch z CUDA według instrukcji z pytorch.org.

## 3. Uruchomienie

```bash
python app.py
```

Po starcie aktywny jest **model syntetyczny** (działa natychmiast, bez pobierania). Do wyników do
pracy wczytaj rzeczywisty model: panel boczny → **Zmień model…** → *Model Hugging Face* →
`Qwen/Qwen2.5-0.5B-Instruct` (domyślny model z `demo.py`). Pierwsze wczytanie pobiera ok. 1 GB
z huggingface.co; potem model jest w lokalnej pamięci podręcznej. Można też wskazać lokalny
katalog modelu. Dla modeli bazowych (OPT, GPT-2) wyłącz *szablon czatu* (jak `--no-chat-template`).

Dane aplikacji (historia, kopie PDF) trafiają do katalogu `stegolab_data/` obok repozytorium
(zmienna `STEGOLAB_DATA` pozwala wskazać inny katalog).

## 4. Funkcje aplikacji

| Sekcja | Co można zrobić |
|---|---|
| **Panel główny** | opis projektu, karty algorytmów (szybki dostęp do demo/testu/opisu), statystyki i ostatnie eksperymenty, informacja o aktywnym modelu |
| **Algorytmy** | lista generowana z importowalnych pakietów repozytorium; opis, zasada działania, kodowanie/dekodowanie, parametry, dane wejściowe, formaty, operacje, metryki, metryki nieadekwatne, ograniczenia, przypisane dokumenty źródłowe |
| **Demonstracja** | polecenie (wpisane lub z pliku .txt) → tekst ze znakiem i bez znaku obok siebie, kolorowanie tokenów (Unigram: lista zielona/czerwona jak w Tabeli 1 pracy; SynthID: średnia g-wartość), wynik detekcji, detekcja z błędnym kluczem, wykres z-score; modyfikacja tekstu (ręczna lub losowe edycje) i ponowna detekcja z porównaniem do oryginału; zakładka detekcji dowolnego tekstu |
| **Tryb testowy** | N poleceń (wbudowane 20 z `demo.py` lub plik .txt) → N tekstów ze znakiem i N bez; postęp z szacowanym czasem, przerwanie; wynik: komunikat powodzenia, kafelki, tabela metryk, odporność na edycje, wnioski, 3 wykresy, podgląd każdego tekstu |
| **Porównanie** | kilka algorytmów na tych samych poleceniach, ziarnach, modelu i długości; tabela warunków z ostrzeżeniami o elementach nieporównywalnych; tabela porównawcza, 3 wykresy, szczegóły każdego algorytmu |
| **Historia** | każdy eksperyment (również przerwany i zakończony błędem): data, rodzaj, algorytmy, parametry, pliki, model, wyniki, status, czas; filtrowanie, wyszukiwanie, ponowne wyświetlenie wyników, eksport, usuwanie |
| **Dokumenty PDF** | import, informacje i metadane, podgląd stron z powiększeniem, tekst, wyszukiwanie z podświetleniem trafień, wykrywanie braku warstwy tekstowej (skan), przypisanie do algorytmu (rola, strony, notatka), wiele dokumentów |
| **Eksport** | PDF (raport z opisem, parametrami, ustawieniami, tabelami, wykresami i wnioskami), CSV (wiersz na tekst + plik podsumowania), JSON (pełne dane) – z każdej strony eksperymentu i z historii |

## 5. Architektura

```
app.py                        punkt wejścia (python app.py)
stegolab/
  algorithms/                 warstwa integracyjna – BEZ logiki znakowania
    base.py                   ParamSpec / AlgorithmSpec (opis, walidacja parametrów), interfejs adaptera
    unigram.py, synthid.py    adaptery: build → generate → detect → annotate (wołają oryginalny kod)
    __init__.py               rejestr: lista algorytmów z rzeczywiście importowalnych pakietów
  models.py                   backend modeli: Hugging Face (demo.load_model) i model syntetyczny
  experiments.py              demo, detekcja tekstu, test serii, porównanie; postęp i przerywanie
  metrics.py                  metryki (auc, perplexity z demo_synthid.py; tpr_at_fpr, random_edits z repo)
  history.py                  historia (JSON na eksperyment, zapis atomowy)
  pdf_reader.py               PyMuPDF: info, tekst, render, wyszukiwanie, wykrywanie skanów
  documents.py                biblioteka PDF i przypisania do algorytmów
  charts.py                   wykresy matplotlib wspólne dla GUI i raportów
  reports.py                  eksport JSON / CSV / PDF, wnioski wyłącznie z danych
  errors.py                   wyjątki z komunikatem i podpowiedzią dla użytkownika
  gui/                        jedyna warstwa zależna od Qt
    main_window.py, state.py  okno, nawigacja, stan (model, zadanie w tle)
    workers.py                QThread + sygnały: obliczenia poza wątkiem GUI
    widgets.py, results.py    elementy wielokrotnego użytku i widoki wyników
    model_dialog.py           wybór i ładowanie modelu (w tle)
    pages/                    strony: overview, experiments_pages, history_page, documents_page
tests/
  test_core.py, test_synthid.py   oryginalne testy repozytorium (bez zmian)
  test_app_core.py            rejestr, walidacja, round-trip, metryki, przerywanie, historia
  test_app_io.py              PDF, biblioteka dokumentów, eksport raportów
  test_app_hf.py              integracja z prawdziwym potokiem transformers (mały lokalny GPT-2)
  test_app_gui.py             GUI (pytest-qt): przebiegi w tle, responsywność, przerwanie, błędy, eksport
```

Zasady: warstwa obliczeniowa (`stegolab/*.py`) nie importuje Qt i działa samodzielnie (np. w
skryptach do pracy); GUI uruchamia długie operacje w `QThread` (eksperymenty, ładowanie modelu,
import PDF, eksport) i blokuje równoległe zadania, żeby ten sam model nie był używany z dwóch
wątków naraz.

## 6. Mapa algorytmów

### Unigram-Watermark
* **Działanie:** klucz → SHA-256 → ziarno → losowa permutacja słownika; pierwsze ⌊γ·|V|⌋ tokenów to
  stała lista zielona G. Algorytm 1: `l̂[v] = l[v] + δ·1(v ∈ G)`, potem temperatura i top-p.
  Algorytm 2: `z = (|y|_G − γn) / √(nγ(1−γ))`, decyzja `z > τ`. Algorytm 4 („Unique”): to samo na
  tekście bez powtórzeń, próg z równania (9) dla poziomu α.
* **Dane wejściowe:** polecenie (tekst / .txt), klucz (liczba całkowita), model językowy; do
  detekcji dowolny tekst.
* **Kodowanie:** `unigram_watermark.generate(model, tokenizer, prompt, wm=…)`.
* **Dekodowanie:** `UnigramWatermark.detect` (Alg. 2) i `detect_unique` (Alg. 4).
* **Parametry (domyślne z `demo.py`):** klucz 15485863, γ = 0.5, δ = 2.0, τ = 6.0, α = 0.01,
  temperatura 1.0, top-p 0.9.
* **Ograniczenia:** znak zerobitowy; siła ~√n (krótkie teksty słabo); niska entropia osłabia znak;
  stałą listę można odtworzyć statystycznie; wymagany ten sam tokenizer; ataki parafrazą nieodtworzone.
* **Metryki:** z, p-value, odsetek zielonych tokenów, Alg. 4, TPR/FPR (+95% CI Wilsona), TPR@FPR,
  AUC, perplexity, czasy, narzut, odporność na edycje, błędny klucz.

### SynthID-Text (Tournament sampling)
* **Działanie:** ziarno `r_t = h(ostatnie H tokenów, klucz)` (blake2b); g-wartości
  `g_l(x, r_t) ∈ {0,1}`; 2^m kandydatów z rozkładu modelu (temperatura + top-k) gra m rund turnieju
  (wygrywa większe g, remis losowo); powtórzony kontekst → zwykłe próbkowanie. Detekcja:
  `z = (Σg − nm/2)/√(nm/4)`, decyzja `z > 2.326` (FPR 1%).
* **Dane wejściowe:** polecenie, klucz (tekst), model językowy; do detekcji dowolny tekst.
* **Kodowanie:** `synthid_watermark.generate(model, tokenizer, prompt, wm=…)`.
* **Dekodowanie:** `TournamentWatermark.detect`.
* **Parametry (domyślne z `demo_synthid.py`):** klucz `secret-watermark-key`, H = 4, m = 8,
  próg 2.326, temperatura 0.7, top-k 100. W GUI m ≤ 10 (koszt 2^m kandydatów w czystym Pythonie).
* **Ograniczenia:** znak zerobitowy; zależność od entropii; koszt rośnie z 2^m; edycja niszczy
  okna H tokenów; tylko detektor średniej g (bez bayesowskiego); perplexity liczona tym samym modelem.
* **Metryki:** jak wyżej, zamiast odsetka zielonych – średnia g-wartość (bez znaku ≈ 0.5).

## 7. Metryki

| Metryka | Znaczenie i sposób liczenia |
|---|---|
| z-score, p-value | statystyka detektora z oryginalnego kodu; p = ½·erfc(z/√2) (jednostronnie) |
| TPR / FPR przy progu | odsetek wykryć w tekstach ze znakiem / bez znaku; zawsze z liczebnością k/n i **95% przedziałem Wilsona** |
| AUC | P(z_ze_znakiem > z_bez_znaku) – funkcja `auc` z `demo_synthid.py` |
| TPR @ FPR 1% / 10% | próg dobrany tak, by FPR na tekstach bez znaku był zadany (`tpr_at_fpr` z repozytorium); gdy tekstów jest za mało (n·FPR < 1), wynik oznaczany jako orientacyjny |
| Błędny klucz | detekcja tekstów ze znakiem kluczem zmienionym – powinna dawać z ≈ N(0,1) |
| Perplexity | `perplexity` z `demo_synthid.py` (ten sam model ocenia własny tekst – zgrubnie); raportowany stosunek median ze znakiem / bez |
| Czas kodowania | czas generacji na token ze znakiem i bez; narzut = stosunek |
| Czas dekodowania | czas tokenizacji + detekcji jednego tekstu |
| Odporność na edycje | `random_edits` z repozytorium (wstawienia/usunięcia/zamiany ułamka tokenów), średni z i odsetek wykryć |
| z a długość | średni z prefiksów długości n (drugi wykres z `demo.py`) |
| Odsetek zielonych / średnia g | specyficzne dla algorytmu; bez znaku oczekiwane γ / 0.5 |

## 8. Jak przeprowadzić eksperymenty do pracy

1. Wczytaj rzeczywisty model (sekcja 3). Na CPU 100 tokenów to kilka sekund; na GPU dużo szybciej.
2. **Demonstracja** – pokaż na jednym poleceniu kolorowane tokeny, wynik detekcji i błędny klucz;
   w karcie „Modyfikacja tekstu” zastosuj np. 20% losowych edycji i wykryj ponownie.
3. **Tryb testowy** – zalecane ≥ 50 poleceń (własny plik .txt, jedno polecenie w wierszu) i
   200 tokenów jak w publikacjach. Przy 20 poleceniach przedziały ufności są szerokie i aplikacja to
   zaznacza we wnioskach.
4. **Porównanie** – zaznacz oba algorytmy. Uwaga na komunikaty o warunkach: algorytmy mają różne
   progi (6 vs 2.326) i różne próbkowanie (top-p vs top-k). Do porównania skuteczności używaj AUC
   i TPR przy tym samym empirycznym FPR; do jakości i kosztu – stosunku do własnej linii bazowej.
5. Eksportuj raport PDF (tabele, wykresy, wnioski) oraz CSV/JSON z surowymi danymi z historii.

Ziarna są zapisywane (teksty ze znakiem: ziarno bazowe + i, bez znaku: ziarno bazowe + 10000 + i,
edycje: 123 – jak w `demo.py`), więc eksperyment można powtórzyć z identycznym wynikiem.

## 9. Dokumenty PDF

1. **Dokumenty PDF → Importuj PDF…** – plik jest sprawdzany (uszkodzony, zaszyfrowany, pusty →
   czytelny komunikat), kopiowany do biblioteki i opisywany metadanymi.
2. Podgląd stron (powiększenie, nawigacja), zakładka **Tekst** (pełny tekst), wyszukiwanie z listą
   trafień i podświetleniem na stronie.
3. **Przypisanie do algorytmu** – rola dokumentu (publikacja źródłowa / instrukcja do zajęć /
   materiał uzupełniający), istotne strony, notatka. Przypisanie widać na stronie algorytmu.
4. Jeśli PDF nie ma warstwy tekstowej (skan), aplikacja to zgłasza; podgląd działa, ale
   wyszukiwanie nie. OCR nie jest wbudowany – użyj np. `ocrmypdf` i zaimportuj wynik.

Treść PDF jest wyłącznie materiałem referencyjnym: aplikacja niczego do niego nie dopisuje i nie
traktuje go jako zweryfikowanej dokumentacji algorytmu.

## 10. Testy

```bash
pytest -q                       # wszystkie testy (oryginalne + aplikacji), ok. 30 s
pytest -q tests/test_core.py tests/test_synthid.py   # tylko oryginalne
```

Wynik w środowisku deweloperskim (Linux, Python 3.13, PyTorch 2.15 bez GPU, transformers 5.22, PySide6 6.12, testy GUI
w trybie offscreen): **98 passed** (32 oryginalne + 66 nowych).

Test round-trip dla każdego algorytmu: polecenie + klucz → generacja ze znakiem → detekcja →
oczekiwanie: wykryty ze znakiem, niewykryty bez znaku, niewykryty z błędnym kluczem. Ponieważ
algorytmy są probabilistyczne i zerobitowe, testy nie sprawdzają „bezstratnego odzyskania danych”,
tylko własności statystyczne (z rośnie z długością, edycje obniżają z, δ = 0 usuwa znak, niższa
entropia osłabia SynthID, z bez znaku ≈ N(0,1)). Dodatkowo sprawdzane są niezależnie: wzór z-score
(Eq. 2), perplexity (ręczne obliczenie na znanym rozkładzie), przedziały Wilsona, AUC.

## 11. Ograniczenia implementacji i kompromisy

* **Model syntetyczny** (rozkład `softmax(s·N(0,1))`, deterministyczny względem kontekstu – jak
  w testach repozytorium) służy do szybkich eksperymentów statystycznych i testów; jego tekst to
  pseudosłowa. Wyniki są zawsze oznaczane jako „model syntetyczny” – nie należy ich przenosić na LLM.
* **Retokenizacja:** detektor domyślnie tokenizuje tekst ponownie (jak `demo_synthid.py`), co jest
  realistyczne, ale może dawać inne tokeny niż przy generacji (np. gdy model wygeneruje niepełne
  sekwencje bajtów UTF-8 zamienione na „�”, albo tokeny specjalne). Obniża to z-score. W trybie
  testowym można przełączyć detekcję na tokeny z generacji (jak `demo.py`).
* **Przerwanie** działa między kolejnymi tekstami – bieżąca generacja (kilka sekund) jest kończona.
  Oryginalna funkcja `generate()` nie ma punktu przerwania, a jej logika nie była zmieniana.
* **Porównanie** używa domyślnego próbkowania każdego algorytmu z repozytorium (Unigram: top-p 0.9,
  T = 1.0; SynthID: top-k 100, T = 0.7). Można je wyrównać w formularzach; różnice są oznaczane.
* Edycje losowe działają na identyfikatorach tokenów (jak w skryptach demo), nie na tekście.
* Brak OCR, ataków parafrazą (wymagają dodatkowych modeli) i detektora bayesowskiego SynthID – tak
  jak w oryginalnym repozytorium.
* W środowisku, w którym powstała aplikacja, nie było dostępu do huggingface.co, więc ścieżka
  Hugging Face została sprawdzona testem z małym, lokalnie zbudowanym modelem GPT-2 (prawdziwe
  `transformers` + oryginalne `generate()`), a nie z Qwen. Pierwsze uruchomienie z Qwen na własnym
  komputerze jest więc pierwszym testem z tym konkretnym modelem.
