"""Test integracyjny z prawdziwym potokiem Hugging Face (transformers + tokenizers).

Model jest mały i budowany lokalnie (GPT-2 z losowymi wagami + tokenizer BPE wytrenowany na
krótkim tekście), więc test nie wymaga pobierania. Sprawdza ścieżkę używaną dla Qwen:
demo.load_model → oryginalne generate() obu pakietów → retokenizacja → detekcja → perplexity.
Wyniki jakościowe (czytelność tekstu) nie są tu oceniane – tylko poprawność integracji.

Tokenizer jest słownikowy (WordLevel), a nie bajtowy BPE: model z losowymi wagami wybierałby
fragmenty bajtów UTF-8, które po dekodowaniu zamieniają się w „�” i zmieniają sekwencję tokenów
przy retokenizacji. To realne zjawisko (opisane w README_APP.md), ale tu testujemy samą integrację.
"""
import pytest

transformers = pytest.importorskip("transformers")
tokenizers = pytest.importorskip("tokenizers")

from stegolab import algorithms, experiments, models  # noqa: E402

CORPUS = ("The watermark detector counts green tokens and computes a z score. "
          "Language models generate text one token at a time. A secret key selects the green list. "
          "Tournament sampling draws candidates and keeps the winner of each round. ") * 40


@pytest.fixture(scope="module")
def tiny_hf_dir(tmp_path_factory):
    from tokenizers import Tokenizer, models as tk_models, pre_tokenizers
    from transformers import GPT2Config, GPT2LMHeadModel, PreTrainedTokenizerFast

    d = tmp_path_factory.mktemp("tiny_gpt2")
    words = sorted(set(CORPUS.split()))
    vocab = {"<|endoftext|>": 0, "[UNK]": 1, **{w: i + 2 for i, w in enumerate(words)}}
    raw = Tokenizer(tk_models.WordLevel(vocab=vocab, unk_token="[UNK]"))
    raw.pre_tokenizer = pre_tokenizers.WhitespaceSplit()
    tok = PreTrainedTokenizerFast(tokenizer_object=raw, eos_token="<|endoftext|>", unk_token="[UNK]")
    tok.save_pretrained(d)
    import torch
    torch.manual_seed(0)
    cfg = GPT2Config(vocab_size=len(tok), n_positions=256, n_embd=64, n_layer=2, n_head=2,
                     eos_token_id=tok.eos_token_id, bos_token_id=tok.eos_token_id,
                     pad_token_id=tok.eos_token_id)
    GPT2LMHeadModel(cfg).save_pretrained(d)
    return d


@pytest.fixture(scope="module")
def hf_lm(tiny_hf_dir):
    lm = models.load_hf_model(str(tiny_hf_dir), use_chat_template=True)
    assert lm.kind == "hf" and not lm.use_chat_template  # brak szablonu czatu → wyłączony automatycznie
    return lm


@pytest.mark.parametrize("aid", ["unigram", "synthid"])
def test_hf_demo_pipeline(aid, hf_lm):
    d = algorithms.get(aid).spec.defaults()
    r = experiments.run_demo(hf_lm, aid, d, "The detector", max_new_tokens=60, seed=0)
    wm, plain = r["watermarked"], r["plain"]
    assert wm["n_generated"] > 0 and isinstance(wm["text"], str)
    # tokenizer słownikowy jest odwracalny → retokenizacja odtwarza tokeny z generacji
    # (poza tokenami specjalnymi, które generate() z repozytorium pomija przy dekodowaniu)
    special = set(hf_lm.tokenizer.all_special_ids)
    assert wm["tokens"] == [t for t in wm["generated_tokens"] if t not in special]
    assert all(t < hf_lm.vocab_size for t in wm["tokens"])
    assert wm["perplexity"] is not None and wm["perplexity"] > 1
    # model z losowymi wagami ma wysoką entropię → znak jest silny
    assert wm["detection"]["z"] > plain["detection"]["z"]
    assert wm["detection"]["z"] > 2.0


def test_hf_series_and_text_detection(hf_lm):
    d = algorithms.get("synthid").spec.defaults()
    s = {"prompts": ["The detector", "A secret key"], "max_new_tokens": 40, "edit_fractions": [0.0, 0.3]}
    r = experiments.run_test(hf_lm, "synthid", d, s)
    assert r["summary"]["n_texts"] == 2
    assert r["summary"]["perplexity_watermarked"]["n"] == 2
    det = experiments.detect_text(hf_lm, "synthid", d, r["samples"][0]["watermarked"]["text"])
    assert det["detection"]["z"] == pytest.approx(r["samples"][0]["watermarked"]["detection"]["z"])
