"""Wspólna konfiguracja testów aplikacji StegoLab.

Oryginalne testy repozytorium (test_core.py, test_synthid.py) nie korzystają z tych fixture.
"""
import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")  # testy GUI bez ekranu


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    """Każdy test ma własny katalog danych (historia, biblioteka PDF)."""
    d = tmp_path / "stegolab_data"
    monkeypatch.setenv("STEGOLAB_DATA", str(d))
    return d


@pytest.fixture(scope="session")
def synthetic_lm():
    from stegolab import models
    return models.make_synthetic_model(vocab_size=5000, spread=3.0, context_size=2, seed=0)


@pytest.fixture(scope="session")
def text_pdf(tmp_path_factory):
    import pymupdf
    path = tmp_path_factory.mktemp("pdf") / "publikacja.pdf"
    doc = pymupdf.open()
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 90), f"Strona {i + 1}: test detekcji", fontsize=14)
        page.insert_textbox(pymupdf.Rect(72, 110, 520, 700),
                            "The detector computes a z-score of green tokens. " * 8, fontsize=11)
    doc.set_metadata({"title": "Publikacja testowa", "author": "Autor Testowy"})
    doc.save(str(path))
    return path


@pytest.fixture(scope="session")
def scanned_pdf(tmp_path_factory):
    """PDF zawierający wyłącznie obraz (bez warstwy tekstowej) – jak skan."""
    import pymupdf
    path = tmp_path_factory.mktemp("pdf") / "skan.pdf"
    pix = pymupdf.Pixmap(pymupdf.csRGB, pymupdf.IRect(0, 0, 200, 100), False)
    pix.clear_with(200)
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_image(pymupdf.Rect(72, 72, 472, 272), pixmap=pix)
    doc.save(str(path))
    return path
