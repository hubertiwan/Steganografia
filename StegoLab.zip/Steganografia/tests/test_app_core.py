"""Testy warstwy integracyjnej StegoLab (bez GUI).

Testy round-trip: dane wejściowe (polecenie + klucz) → kodowanie (generacja ze znakiem) →
dekodowanie (detekcja) → porównanie z oczekiwaniem. Algorytmy są zerobitowe i probabilistyczne,
więc „poprawne odzyskanie” oznacza: znak wykryty w tekście ze znakiem, niewykryty w tekście bez
znaku i niewykryty przy błędnym kluczu. Ziarna są stałe, a progi asercji wynikają z teorii
(z rośnie ~√n), z dużym zapasem.
"""
import math

import numpy as np
import pytest

from stegolab import algorithms, experiments, history, metrics, models
from stegolab.errors import ExperimentCancelled, InputError, ModelError, ParameterError

ALGOS = ["unigram", "synthid"]


def defaults(aid):
    return algorithms.get(aid).spec.defaults()


# ------------------------------------------------------------------ rejestr i specyfikacje
def test_registry_lists_real_repository_algorithms():
    avail = algorithms.available()
    assert list(avail) == ALGOS
    assert algorithms.unavailable() == {}
    from synthid_watermark import TournamentWatermark
    from unigram_watermark import UnigramWatermark
    assert isinstance(avail["unigram"].build(defaults("unigram"), 1000), UnigramWatermark)
    assert isinstance(avail["synthid"].build(defaults("synthid"), 1000), TournamentWatermark)


@pytest.mark.parametrize("aid", ALGOS)
def test_spec_is_complete(aid):
    spec = algorithms.get(aid).spec
    for field in ("name", "description", "paper", "embedding", "detection"):
        assert getattr(spec, field)
    for field in ("principle", "inputs", "formats", "limitations", "operations", "metrics", "not_applicable", "params"):
        assert len(getattr(spec, field)) > 0
    assert spec.validate({}) == spec.defaults()


def test_defaults_match_repository_demos():
    """Wartości domyślne muszą odpowiadać argumentom demo.py i demo_synthid.py."""
    import demo
    import demo_synthid
    import sys
    u = defaults("unigram")
    argv, sys.argv = sys.argv, ["demo.py"]
    try:
        du, ds = demo.parse_args(), demo_synthid.parse_args()
    finally:
        sys.argv = argv
    assert (u["key"], u["gamma"], u["delta"], u["tau"], u["top_p"], u["temperature"]) == \
           (du.key, du.gamma, du.delta, du.tau, du.top_p, du.temperature)
    s = defaults("synthid")
    assert (s["key"], s["context_size"], s["num_layers"], s["threshold"], s["top_k"], s["temperature"]) == \
           (ds.key, ds.context_size, ds.num_layers, ds.threshold, ds.top_k, ds.temperature)


@pytest.mark.parametrize("aid,bad", [
    ("unigram", {"gamma": 0}), ("unigram", {"gamma": 1.0}), ("unigram", {"top_p": 0}),
    ("unigram", {"delta": -1}), ("unigram", {"key": "abc"}), ("unigram", {"key": 1.5}),
    ("unigram", {"unique_alpha": 0}), ("unigram", {"nonexistent": 1}),
    ("synthid", {"key": "   "}), ("synthid", {"context_size": 0}), ("synthid", {"num_layers": 11}),
    ("synthid", {"temperature": 0}), ("synthid", {"top_k": 0}), ("synthid", {"threshold": float("nan")}),
])
def test_invalid_parameters_are_rejected_with_message(aid, bad):
    with pytest.raises(ParameterError) as e:
        algorithms.get(aid).spec.validate(bad)
    assert e.value.message


def test_unigram_rejects_degenerate_green_list():
    with pytest.raises(ParameterError):
        algorithms.get("unigram").build({"gamma": 0.001}, 500)  # ⌊0.001·500⌋ = 0 zielonych tokenów


# ------------------------------------------------------------------ model syntetyczny
def test_synthetic_tokenizer_is_invertible():
    for v in (100, 5000, 100000):
        tok = models.SyntheticTokenizer(v)
        ids = list(range(0, v, max(1, v // 2000)))
        assert tok.encode(tok.decode(ids)) == ids


def test_synthetic_model_is_deterministic_and_validated(synthetic_lm):
    a = synthetic_lm.model.context_logits([1, 2])
    b = synthetic_lm.model.context_logits([9, 1, 2])  # kontekst modelu = 2 ostatnie tokeny
    assert np.array_equal(a, b)
    with pytest.raises(ModelError):
        models.make_synthetic_model(vocab_size=10)
    with pytest.raises(ModelError):
        models.make_synthetic_model(spread=0)


# ------------------------------------------------------------------ round-trip
@pytest.mark.parametrize("aid", ALGOS)
def test_demo_round_trip(aid, synthetic_lm):
    r = experiments.run_demo(synthetic_lm, aid, defaults(aid), "Why is the sky blue?", max_new_tokens=100, seed=1)
    wm, plain = r["watermarked"], r["plain"]
    assert wm["n_generated"] == 100
    assert wm["detection"]["watermarked"], wm["detection"]
    assert not plain["detection"]["watermarked"]
    assert not wm["wrong_key_detection"]["watermarked"]
    # model syntetyczny ma odwracalny tokenizer → retokenizacja = tokeny z generacji
    assert wm["tokens"] == wm["generated_tokens"]
    assert wm["detection"]["z"] == pytest.approx(wm["detection_on_generated_tokens"]["z"])
    assert len(wm["pieces"]) == len(wm["annotation"]) == len(wm["tokens"])
    assert wm["perplexity"] > 1 and plain["perplexity"] > 1


@pytest.mark.parametrize("aid", ALGOS)
def test_series_round_trip(aid, synthetic_lm):
    s = {"prompts": experiments.builtin_prompts()[:8], "max_new_tokens": 100, "compute_perplexity": False}
    r = experiments.run_test(synthetic_lm, aid, defaults(aid), s)
    summ = r["summary"]
    assert summ["tpr"]["rate"] == 1.0
    assert summ["fpr"]["rate"] == 0.0
    assert summ["wrong_key_fpr"]["rate"] == 0.0
    assert summ["auc"] == 1.0
    # z-score bez znaku ~ N(0, 1): średnia z 8 tekstów blisko 0
    assert abs(summ["z_plain"]["mean"]) < 1.5
    # z rośnie z długością tekstu (≈ √n) – krzywa monotoniczna dla tekstów ze znakiem
    curve = [row["mean_z_watermarked"] for row in r["length_curve"]]
    assert all(b > a for a, b in zip(curve, curve[1:]))
    # więcej edycji → niższy z
    zs = [e["mean_z"] for e in r["edits"]]
    assert zs[0] > zs[-1]


def test_delta_zero_means_no_watermark(synthetic_lm):
    """Kontrola: δ = 0 wyłącza znak Unigram – detekcja musi przestać działać.
    To potwierdza, że wykrycia w pozostałych testach wynikają z algorytmu, a nie z artefaktu."""
    p = dict(defaults("unigram"), delta=0.0)
    s = {"prompts": experiments.builtin_prompts()[:8], "max_new_tokens": 100, "compute_perplexity": False}
    summ = experiments.run_test(synthetic_lm, "unigram", p, s)["summary"]
    assert summ["tpr"]["rate"] == 0.0
    assert abs(summ["z_watermarked"]["mean"]) < 1.5


def test_lower_entropy_weakens_synthid():
    """Własność z pracy: przy rozkładzie bliskim jednopunktowemu turniej rzadko zmienia wybór."""
    s = {"prompts": experiments.builtin_prompts()[:5], "max_new_tokens": 80, "compute_perplexity": False,
         "edit_fractions": [0.0]}
    high = experiments.run_test(models.make_synthetic_model(spread=2.0), "synthid", defaults("synthid"), s)
    low = experiments.run_test(models.make_synthetic_model(spread=12.0), "synthid", defaults("synthid"), s)
    assert high["summary"]["z_watermarked"]["mean"] > low["summary"]["z_watermarked"]["mean"] + 2


def test_detect_text_and_annotations(synthetic_lm):
    demo = experiments.run_demo(synthetic_lm, "unigram", defaults("unigram"), "Hello", 60, 3)
    det = experiments.detect_text(synthetic_lm, "unigram", defaults("unigram"), demo["watermarked"]["text"])
    assert det["detection"]["z"] == pytest.approx(demo["watermarked"]["detection"]["z"])
    ann = det["annotation"]
    assert sum(ann) / len(ann) == pytest.approx(det["detection"]["green_frac"])

    demo2 = experiments.run_demo(synthetic_lm, "synthid", defaults("synthid"), "Hello", 60, 3)
    d2 = demo2["watermarked"]
    scored = [a for a in d2["annotation"] if a is not None]
    assert len(scored) == d2["detection"]["n_scored"]
    assert np.mean(scored) == pytest.approx(d2["detection"]["mean_g"])


def test_random_edit_text_changes_text(synthetic_lm):
    demo = experiments.run_demo(synthetic_lm, "unigram", defaults("unigram"), "Hi", 50, 0)
    text = demo["watermarked"]["text"]
    assert experiments.random_edit_text(synthetic_lm, text, 0.0) == text
    assert experiments.random_edit_text(synthetic_lm, text, 0.5, seed=1) != text
    with pytest.raises(InputError):
        experiments.random_edit_text(synthetic_lm, text, 1.5)


def test_comparison_records_conditions(synthetic_lm):
    s = {"prompts": experiments.builtin_prompts()[:3], "max_new_tokens": 40, "compute_perplexity": False}
    r = experiments.run_comparison(synthetic_lm, [("unigram", defaults("unigram")), ("synthid", defaults("synthid"))], s)
    assert [x["algorithm"] for x in r["runs"]] == ALGOS
    assert all(x["settings"]["prompts"] == r["settings"]["prompts"] for x in r["runs"])
    notes = " ".join(r["conditions"]["notes"])
    assert "progi detekcji różnią się" in notes and "różne ustawienia próbkowania" in notes
    with pytest.raises(InputError):
        experiments.run_comparison(synthetic_lm, [("unigram", defaults("unigram"))], s)


def test_cancellation_stops_between_texts(synthetic_lm):
    calls = {"n": 0}

    def stop():
        calls["n"] += 1
        return calls["n"] > 3

    s = {"prompts": experiments.builtin_prompts()[:10], "max_new_tokens": 20}
    with pytest.raises(ExperimentCancelled) as e:
        experiments.run_test(synthetic_lm, "unigram", defaults("unigram"), s, should_stop=stop)
    assert e.value.completed == 1


def test_progress_is_reported_and_monotonic(synthetic_lm):
    seen = []
    s = {"prompts": experiments.builtin_prompts()[:3], "max_new_tokens": 20, "compute_perplexity": False}
    experiments.run_test(synthetic_lm, "synthid", defaults("synthid"), s, progress=lambda f, m: seen.append(f))
    assert seen[-1] == pytest.approx(1.0)
    assert all(b >= a for a, b in zip(seen, seen[1:]))


# ------------------------------------------------------------------ dane wejściowe
def test_input_validation(tmp_path, synthetic_lm):
    with pytest.raises(InputError):
        experiments.read_prompts_file(tmp_path / "brak.txt")
    empty = tmp_path / "pusty.txt"
    empty.write_text("\n  \n", encoding="utf-8")
    with pytest.raises(InputError):
        experiments.read_prompts_file(empty)
    binary = tmp_path / "obraz.txt"
    binary.write_bytes(b"\x89PNG\x00\x00\x00")
    with pytest.raises(InputError):
        experiments.read_text_file(binary)
    cp = tmp_path / "cp1250.txt"
    cp.write_bytes("Zażółć gęślą jaźń\nDrugie polecenie".encode("cp1250"))
    assert experiments.read_prompts_file(cp) == ["Zażółć gęślą jaźń", "Drugie polecenie"]
    with pytest.raises(InputError):
        experiments.read_text_file(tmp_path)
    with pytest.raises(InputError):
        experiments.normalise_settings({"prompts": []})
    with pytest.raises(InputError):
        experiments.normalise_settings({"prompts": ["a"], "max_new_tokens": 0})
    with pytest.raises(InputError):
        experiments.normalise_settings({"prompts": ["a"], "edit_fractions": [2.0]})
    with pytest.raises(InputError):
        experiments.run_demo(synthetic_lm, "unigram", defaults("unigram"), "   ")
    with pytest.raises(InputError):
        experiments.detect_text(synthetic_lm, "unigram", defaults("unigram"), "")


def test_hf_loader_reports_bad_model():
    with pytest.raises(ModelError) as e:
        models.load_hf_model("/nie/istnieje/model-xyz")
    assert e.value.hint
    with pytest.raises(ModelError):
        models.load_hf_model("  ")


# ------------------------------------------------------------------ metryki
def test_wilson_interval_known_values():
    lo, hi = metrics.wilson_interval(0, 10)
    assert lo == 0.0 and hi == pytest.approx(0.2775, abs=1e-3)
    lo, hi = metrics.wilson_interval(10, 10)
    assert hi == 1.0 and lo == pytest.approx(0.7225, abs=1e-3)
    assert metrics.wilson_interval(0, 0) == (None, None)


def test_auc_and_tpr_at_fpr():
    assert metrics.auc([3, 4, 5], [0, 1, 2]) == 1.0
    assert metrics.auc([0, 1], [0, 1]) == 0.5
    assert metrics.auc([], [1]) is None
    t = metrics.empirical_tpr_at_fpr([5, 6, 7, 0], list(range(10)), 0.10)
    assert t["reliable"] and t["tpr"] == 0.0  # próg = 90. percentyl {0..9} = 8.1
    assert not metrics.empirical_tpr_at_fpr([1], [0, 1, 2], 0.01)["reliable"]


def test_perplexity_matches_independent_computation(synthetic_lm):
    """Perplexity z demo_synthid.py porównana z ręcznym obliczeniem na znanym rozkładzie."""
    prompt = "abc def"
    gen = [5, 17, 4000, 42]
    ppl = metrics.perplexity(synthetic_lm, prompt, gen)
    ctx = synthetic_lm.tokenizer.encode(prompt)
    nll = []
    for tok in gen:
        logits = synthetic_lm.model.context_logits(ctx)
        logp = logits - logits.max() - np.log(np.exp(logits - logits.max()).sum())
        nll.append(-logp[tok])
        ctx.append(tok)
    assert ppl == pytest.approx(math.exp(np.mean(nll)), rel=1e-4)
    assert metrics.perplexity(synthetic_lm, prompt, []) is None


def test_unigram_z_score_formula(synthetic_lm):
    """Niezależne sprawdzenie Eq. (2) dla wyniku adaptera."""
    ad = algorithms.get("unigram")
    wm = ad.build(defaults("unigram"), synthetic_lm.vocab_size)
    tokens = list(np.random.default_rng(0).integers(0, synthetic_lm.vocab_size, 300))
    d = ad.detect(wm, tokens, defaults("unigram"))
    g, n = wm.gamma_eff, len(tokens)
    green = sum(bool(wm.green_mask[t]) for t in tokens)
    assert d["z"] == pytest.approx((green - g * n) / math.sqrt(n * g * (1 - g)))
    assert d["p_value"] == pytest.approx(0.5 * math.erfc(d["z"] / math.sqrt(2)))


# ------------------------------------------------------------------ historia
def test_history_roundtrip_and_corrupt_file(data_dir):
    rec = history.new_record("test", "Próba", ["unigram"], {"x": float("nan")})
    rec["status"] = "ok"
    history.save(rec)
    assert history.load(rec["id"])["params"]["x"] is None  # NaN → null (poprawny JSON)
    (data_dir / "experiments" / "zly.json").write_text("{nie-json", encoding="utf-8")
    recs = history.list_records()
    assert any(r.get("corrupt") for r in recs) and any(r["id"] == rec["id"] for r in recs)
    history.delete(rec["id"])
    assert not any(r["id"] == rec["id"] for r in history.list_records())
