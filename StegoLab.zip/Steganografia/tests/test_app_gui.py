"""Testy GUI (pytest-qt, platforma offscreen).

Sprawdzają m.in., że obliczenia działają w wątku roboczym, a pętla zdarzeń GUI w tym czasie
obsługuje zdarzenia (interfejs się nie blokuje), oraz że błędy kończą się komunikatem, a nie
zamknięciem aplikacji.
"""
import time

import pytest

pytest.importorskip("pytestqt")
from PySide6.QtCore import QTimer  # noqa: E402

from stegolab import history  # noqa: E402
from stegolab.gui import theme  # noqa: E402
from stegolab.gui.main_window import NAV, MainWindow  # noqa: E402
from stegolab.gui.state import AppState  # noqa: E402


@pytest.fixture
def errors(monkeypatch):
    """Przechwytuje okna błędów (show_error) zamiast wyświetlać modalne dialogi."""
    seen = []
    import stegolab.gui.pages.documents_page as dp
    import stegolab.gui.pages.experiments_pages as ep
    import stegolab.gui.results as res
    import stegolab.gui.widgets as w
    fake = lambda parent, exc, tb=None, title="": seen.append(exc)  # noqa: E731
    for mod in (w, ep, res, dp):
        monkeypatch.setattr(mod, "show_error", fake)
    return seen


@pytest.fixture
def window(qtbot, qapp, data_dir, synthetic_lm):
    theme.apply(qapp)
    state = AppState()
    state.set_model(synthetic_lm)
    win = MainWindow(state)
    qtbot.addWidget(win)
    win.show()
    return win


def wait_idle(qtbot, win, timeout=120_000):
    qtbot.waitUntil(lambda: win.state.job is None, timeout=timeout)


def test_all_pages_open(window):
    for key, _ in NAV:
        window.go(key)
        assert window.stack.currentWidget() is window.pages[key]
    assert window.pages["algorithms"].list.count() == 2


def test_navigation_signal_selects_algorithm(window):
    window.state.navigate.emit("test", "synthid")
    assert window.stack.currentWidget() is window.pages["test"]
    assert window.pages["test"].algo.currentData() == "synthid"


def test_demo_runs_in_background_and_is_saved(window, qtbot, errors):
    page = window.pages["demo"]
    window.go("demo")
    page.max_tokens.setValue(60)
    page.run_demo()
    assert window.state.job is not None and not page.run_btn.isEnabled()  # przycisk zablokowany w trakcie
    wait_idle(qtbot, window)
    assert not errors
    assert page.result_view.isVisible() and page.run_btn.isEnabled()
    recs = history.list_records()
    assert recs[0]["kind"] == "demo" and recs[0]["status"] == "ok"
    # ponowna detekcja zmodyfikowanego tekstu
    page.edit_frac.setValue(0.3)
    page._random_edit()
    page._redetect()
    wait_idle(qtbot, window)
    assert "Po zmianach" in page.edit_result.text()


def test_gui_stays_responsive_during_test(window, qtbot, errors):
    page = window.pages["test"]
    page.settings.count.setValue(12)
    page.settings.max_tokens.setValue(120)
    page.select("synthid")
    ticks = []
    timer = QTimer()
    timer.timeout.connect(lambda: ticks.append(time.perf_counter()))
    timer.start(20)
    page.run()
    wait_idle(qtbot, window)
    timer.stop()
    assert not errors
    gaps = [b - a for a, b in zip(ticks, ticks[1:])]
    assert len(ticks) > 10, "pętla zdarzeń nie działała w trakcie obliczeń"
    assert max(gaps) < 1.0, f"GUI zablokowane na {max(gaps):.2f} s"
    assert not page.view.isHidden()
    assert history.list_records()[0]["status"] == "ok"


def test_cancel_marks_experiment_cancelled(window, qtbot, errors):
    page = window.pages["test"]
    page.settings.count.setValue(20)
    page.settings.max_tokens.setValue(200)
    page.select("synthid")
    page.run()
    qtbot.waitUntil(lambda: page.progress.bar.value() > 0, timeout=30_000)
    page.progress.cancel.click()
    wait_idle(qtbot, window)
    rec = history.list_records()[0]
    assert rec["status"] == "cancelled"
    assert "Przerwany" in page.notice.text() or "przerwany" in page.notice.text()


def test_invalid_input_shows_error_without_crash(window, qtbot, errors, tmp_path):
    page = window.pages["test"]
    page.settings.source.setCurrentIndex(1)
    page.settings.file_edit.setText(str(tmp_path / "brak.txt"))
    page.run()
    assert errors and "nie istnieje" in errors[-1].message
    assert window.state.job is None
    demo = window.pages["demo"]
    demo.params.current("synthid").inputs["key"].setText("   ")
    demo.select("synthid")
    demo.run_demo()
    assert "pusty" in errors[-1].message


def test_comparison_and_history_view(window, qtbot, errors):
    page = window.pages["compare"]
    page.settings.count.setValue(3)
    page.settings.max_tokens.setValue(40)
    page.run()
    wait_idle(qtbot, window)
    assert not errors and not page.view.isHidden()
    hp = window.pages["history"]
    hp.refresh()
    hp.table.selectRow(0)
    assert hp.current is not None and hp.current["kind"] == "comparison"
    assert hp.result_holder.count() == 1  # wyniki ponownie wyświetlone


def test_export_from_gui(window, qtbot, errors, tmp_path, monkeypatch):
    demo = window.pages["demo"]
    demo.max_tokens.setValue(30)
    demo.run_demo()
    wait_idle(qtbot, window)
    target = tmp_path / "raport.pdf"
    import stegolab.gui.results as res
    monkeypatch.setattr(res.QFileDialog, "getSaveFileName", lambda *a, **k: (str(target), ""))
    demo.export.export("pdf")
    wait_idle(qtbot, window)
    assert not errors and target.exists() and target.stat().st_size > 10_000


def test_documents_page(window, qtbot, errors, text_pdf, scanned_pdf):
    from stegolab import documents
    page = window.pages["documents"]
    doc = documents.import_pdf(text_pdf)
    page.refresh(select_id=doc["id"])
    assert page.pdf is not None and page.page_label.pixmap() is not None
    page.query.setText("z-score")
    page.search()
    assert len(page.hits) == 3
    page.a_algo.setCurrentIndex(page.a_algo.findData("unigram"))
    page.assign()
    assert documents.documents_for("unigram")[0][0]["id"] == doc["id"]
    scan = documents.import_pdf(scanned_pdf)
    page.refresh(select_id=scan["id"])
    assert "warstwy tekstowej" in page.banner.text()
    assert not errors
