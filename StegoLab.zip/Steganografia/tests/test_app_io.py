"""Testy obsługi PDF, biblioteki dokumentów i eksportu raportów."""
import csv
import json

import pymupdf
import pytest

from stegolab import algorithms, documents, experiments, history, reports
from stegolab.errors import InputError, PdfError
from stegolab.pdf_reader import PdfDocument


# ------------------------------------------------------------------ PDF
def test_pdf_info_text_search_render(text_pdf):
    with PdfDocument(text_pdf) as pdf:
        info = pdf.info()
        assert info["pages"] == 3 and info["title"] == "Publikacja testowa" and info["author"] == "Autor Testowy"
        assert info["has_text"] and not info["likely_scanned"]
        assert "z-score" in pdf.page_text(1)
        hits = pdf.search("z-score")
        assert [h.page for h in hits] == [0, 1, 2] and all(h.rects for h in hits)
        assert "z-score" in hits[0].snippet
        assert pdf.search("") == [] and pdf.search("nieistniejąca fraza") == []
        w, h, data = pdf.render_page(0, 1.0)
        assert len(data) == w * h * 3
        w2, h2, data2 = pdf.render_page(0, 1.0, highlights=hits[0].rects)
        assert (w2, h2) == (w, h) and data2 != data  # podświetlenie zmienia piksele
        with pytest.raises(PdfError):
            pdf.render_page(10)


def test_scanned_pdf_is_reported(scanned_pdf):
    with PdfDocument(scanned_pdf) as pdf:
        info = pdf.info()
        assert not info["has_text"] and info["likely_scanned"]
        assert pdf.search("cokolwiek") == []


@pytest.mark.parametrize("content", [b"", b"to nie jest pdf", b"%PDF-1.4\n%%%uszkodzony"])
def test_corrupt_pdf_raises_readable_error(tmp_path, content):
    p = tmp_path / "zly.pdf"
    p.write_bytes(content)
    with pytest.raises(PdfError) as e:
        PdfDocument(p)
    assert e.value.hint or "pusty" in e.value.message


def test_encrypted_pdf(tmp_path):
    p = tmp_path / "haslo.pdf"
    doc = pymupdf.open()
    doc.new_page().insert_text((72, 72), "tajne")
    doc.save(str(p), encryption=pymupdf.PDF_ENCRYPT_AES_256, user_pw="abc", owner_pw="abc")
    with pytest.raises(PdfError) as e:
        PdfDocument(p)
    assert "hasłem" in e.value.message


# ------------------------------------------------------------------ biblioteka dokumentów
def test_document_library_flow(data_dir, text_pdf, scanned_pdf):
    doc = documents.import_pdf(text_pdf)
    assert doc["pages"] == 3 and doc["has_text"] and documents.stored_path(doc).exists()
    with pytest.raises(InputError):
        documents.import_pdf(text_pdf)  # duplikat (ten sam SHA-256)
    scan = documents.import_pdf(scanned_pdf)
    assert not scan["has_text"]
    documents.assign(doc["id"], "unigram", documents.ROLES[0], "3-5", "Alg. 1 i 2")
    documents.assign(doc["id"], "synthid", documents.ROLES[2])
    documents.assign(doc["id"], "unigram", documents.ROLES[1])  # ponowne przypisanie nadpisuje
    pairs = documents.documents_for("unigram")
    assert len(pairs) == 1 and pairs[0][1]["role"] == documents.ROLES[1]
    documents.unassign(doc["id"], "synthid")
    assert documents.documents_for("synthid") == []
    documents.update(doc["id"], title="Nowy tytuł")
    assert documents.get(doc["id"])["title"] == "Nowy tytuł"
    with documents.open_document(documents.get(doc["id"])) as pdf:
        assert pdf.page_count == 3
    stored = documents.stored_path(doc)
    documents.remove(doc["id"])
    assert not stored.exists() and text_pdf.exists()  # usuwana jest tylko kopia
    assert len(documents.load_library()["documents"]) == 1


def test_document_import_rejects_non_pdf(data_dir, tmp_path):
    p = tmp_path / "notatki.txt"
    p.write_text("x")
    with pytest.raises(InputError):
        documents.import_pdf(p)


def test_corrupt_library_is_backed_up(data_dir):
    lib = data_dir / "documents" / "library.json"
    lib.parent.mkdir(parents=True, exist_ok=True)
    lib.write_text("{zepsute", encoding="utf-8")
    data = documents.load_library()
    assert data["documents"] == [] and "warning" in data
    assert (data_dir / "documents" / "library.corrupt.json").exists()


# ------------------------------------------------------------------ eksport
@pytest.fixture(scope="module")
def results(synthetic_lm):
    d = algorithms.get("unigram").spec.defaults()
    s = {"prompts": experiments.builtin_prompts()[:4], "max_new_tokens": 40}
    test = experiments.run_test(synthetic_lm, "unigram", d, s)
    comp = experiments.run_comparison(synthetic_lm, [("unigram", d), ("synthid", algorithms.get("synthid").spec.defaults())], s)
    demo = experiments.run_demo(synthetic_lm, "synthid", algorithms.get("synthid").spec.defaults(), "Q?", 40, 1)
    det = experiments.detect_text(synthetic_lm, "unigram", d, demo["watermarked"]["text"])
    return {"test": test, "comparison": comp, "demo": demo, "detect": det}


@pytest.mark.parametrize("kind", ["test", "comparison", "demo", "detect"])
def test_exports(kind, results, tmp_path, data_dir):
    rec = history.new_record(kind, f"Raport {kind}", ["unigram"], files=["polecenia.txt"])
    rec.update(status="ok", duration_s=1.5, result=results[kind])
    history.save(rec)

    j = reports.export_json(rec, tmp_path / "r.json")
    payload = json.loads(j.read_text(encoding="utf-8"))
    assert payload["experiment"]["result"]["kind"] == kind

    c = reports.export_csv(rec, tmp_path / "r.csv")
    rows = list(csv.DictReader(open(c, encoding="utf-8-sig")))
    expected = {"test": 8, "comparison": 16, "demo": 2, "detect": 1}[kind]
    assert len(rows) == expected
    assert all(r["z"] != "" for r in rows)
    if kind in ("test", "comparison"):
        assert (tmp_path / "r_podsumowanie.csv").exists()

    p = reports.export_pdf(rec, tmp_path / "r.pdf")
    with pymupdf.open(str(p)) as pdf:
        text = "".join(page.get_text() for page in pdf)
        pages = pdf.page_count
    assert "Wnioski" in text and "Parametry" in text
    assert "Model syntetyczny" in text  # pochodzenie wyników jest zawsze jawne
    if kind in ("test", "comparison"):
        assert pages >= 2


def test_export_without_result_is_refused(tmp_path):
    rec = history.new_record("test", "x", ["unigram"])
    rec["status"] = "error"
    with pytest.raises(InputError):
        reports.export_pdf(rec, tmp_path / "x.pdf")
    with pytest.raises(InputError):
        reports.export_csv(rec, tmp_path / "x.csv")


def test_conclusions_only_state_measured_numbers(results):
    concl = reports.conclusions(results["test"])
    s = results["test"]["summary"]
    assert f"{s['tpr']['k']} z {s['n_texts']}" in concl[0]
    assert any("syntetyczn" in c.lower() for c in concl)
    assert any("Próba liczy" in c for c in concl)  # ostrzeżenie o małej próbie
