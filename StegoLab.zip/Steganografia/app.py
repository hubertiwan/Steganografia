"""StegoLab – uruchomienie aplikacji okienkowej.

    python app.py
"""
import sys

if sys.version_info < (3, 10):
    sys.exit("StegoLab wymaga Pythona 3.10 lub nowszego.")

try:
    from stegolab.gui.app import main
except ImportError as exc:
    sys.exit(f"Brak zależności ({exc.name}). Zainstaluj je poleceniem:\n    pip install -r requirements-app.txt")

if __name__ == "__main__":
    sys.exit(main())
