"""StegoLab – aplikacja do demonstracji, testowania i analizy algorytmów
znakowania wodnego tekstu (steganografii lingwistycznej) z repozytorium Steganografia.

Warstwy:
    stegolab.algorithms   – specyfikacje i adaptery oryginalnych algorytmów (bez zmian ich logiki)
    stegolab.models       – backend modeli językowych (Hugging Face lub model syntetyczny)
    stegolab.metrics      – metryki oceny
    stegolab.experiments  – przebiegi eksperymentów (demo, test, porównanie, detekcja)
    stegolab.history      – zapis historii eksperymentów
    stegolab.pdf_reader   – odczyt dokumentów PDF (PyMuPDF)
    stegolab.documents    – biblioteka dokumentów źródłowych i przypisania do algorytmów
    stegolab.reports      – eksport JSON / CSV / PDF
    stegolab.gui          – interfejs PySide6 (jedyna warstwa zależna od Qt)
"""
__version__ = "1.0.0"
APP_NAME = "StegoLab"
