"""Wykresy wyników (matplotlib, bez pyplot) – wspólne dla GUI i raportów PDF.

Kolor zawsze oznacza algorytm (Unigram = niebieski, SynthID = pomarańczowy); linia bazowa
bez znaku jest neutralnie szara i dodatkowo kreskowana / przerywana, więc tożsamość serii
nie zależy wyłącznie od koloru. Każdy wykres z ≥ 2 seriami ma legendę.
"""
import numpy as np
from matplotlib.figure import Figure

SURFACE = "#fcfcfb"
TEXT = "#0b0b0b"
TEXT_2 = "#52514e"
GRID = "#e4e3df"
BASELINE = "#8a8984"
ALGO_COLORS = {"unigram": "#2a78d6", "synthid": "#eb6834"}
FALLBACK = ["#2a78d6", "#eb6834", "#1baf7a"]


def algo_color(algo_id, index=0):
    return ALGO_COLORS.get(algo_id, FALLBACK[index % len(FALLBACK)])


def _figure(w=6.4, h=3.6):
    fig = Figure(figsize=(w, h), dpi=100, facecolor=SURFACE, layout="constrained")
    return fig


def _style(ax, title=None, xlabel=None, ylabel=None):
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=TEXT_2, labelsize=8.5, length=0)
    ax.grid(True, axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    if title:
        ax.set_title(title, loc="left", fontsize=10.5, color=TEXT, fontweight="bold", pad=8)
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=9, color=TEXT_2)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=9, color=TEXT_2)


def _legend(ax, loc="best"):
    leg = ax.legend(loc=loc, fontsize=8.5, frameon=False, labelcolor=TEXT_2)
    return leg


def _threshold(ax, value, label, vertical=True):
    if value is None:
        return
    if vertical:
        ax.axvline(value, color=TEXT, lw=1, ls=(0, (4, 3)), label=label)
    else:
        ax.axhline(value, color=TEXT, lw=1, ls=(0, (4, 3)), label=label)


# ------------------------------------------------------------------ test
def z_histogram(result, ax=None):
    fig = None
    if ax is None:
        fig = _figure()
        ax = fig.add_subplot()
    color = algo_color(result["algorithm"])
    zw = [s["watermarked"]["detection"]["z"] for s in result["samples"]]
    zp = [s["plain"]["detection"]["z"] for s in result["samples"]]
    allz = zw + zp
    lo, hi = min(allz + [0]), max(allz + [result["summary"]["threshold"] or 0])
    bins = np.linspace(np.floor(lo) - 0.5, np.ceil(hi) + 0.5, min(30, max(8, len(allz) // 2 + 6)))
    ax.hist(zp, bins=bins, color=BASELINE, alpha=0.85, edgecolor=SURFACE, linewidth=1.5,
            hatch="///", label=f"bez znaku (n={len(zp)})")
    ax.hist(zw, bins=bins, color=color, alpha=0.9, edgecolor=SURFACE, linewidth=1.5,
            label=f"ze znakiem (n={len(zw)})")
    _threshold(ax, result["summary"]["threshold"], f"próg z = {result['summary']['threshold']:g}")
    _style(ax, "Rozkład z-score", "z-score", "liczba tekstów")
    ax.yaxis.get_major_locator().set_params(integer=True)
    _legend(ax)
    return fig


def edits_chart(result, ax=None):
    fig = None
    if ax is None:
        fig = _figure()
        ax = fig.add_subplot()
    rows = [r for r in result["edits"] if r["mean_z"] is not None]
    color = algo_color(result["algorithm"])
    x = [100 * r["fraction"] for r in rows]
    ax.plot(x, [r["mean_z"] for r in rows], "-o", color=color, lw=2, ms=6,
            markeredgecolor=SURFACE, markeredgewidth=1.5, label="średni z-score tekstów ze znakiem")
    for xi, r in zip(x, rows):
        det = r["detected"]["rate"]
        if det is not None:
            ax.annotate(f"{det:.0%}", (xi, r["mean_z"]), textcoords="offset points", xytext=(0, 8),
                        ha="center", fontsize=7.5, color=TEXT_2)
    _threshold(ax, result["summary"]["threshold"], "próg detekcji", vertical=False)
    lo, hi = ax.get_ylim()
    ax.set_ylim(min(lo, 0), hi + 0.15 * (hi - lo))  # miejsce na etykiety nad punktami
    _style(ax, "Odporność na losowe edycje (etykiety: odsetek wykryć)", "edytowane tokeny [%]", "średni z-score")
    _legend(ax)
    return fig


def length_chart(result, ax=None):
    fig = None
    if ax is None:
        fig = _figure()
        ax = fig.add_subplot()
    rows = result["length_curve"]
    color = algo_color(result["algorithm"])
    n = [r["n"] for r in rows]
    ax.plot(n, [r["mean_z_watermarked"] for r in rows], "-o", color=color, lw=2, ms=6,
            markeredgecolor=SURFACE, markeredgewidth=1.5, label="ze znakiem")
    ax.plot(n, [r["mean_z_plain"] for r in rows], "--s", color=BASELINE, lw=2, ms=6,
            markeredgecolor=SURFACE, markeredgewidth=1.5, label="bez znaku")
    _threshold(ax, result["summary"]["threshold"], "próg detekcji", vertical=False)
    _style(ax, "z-score a długość tekstu", "liczba tokenów (prefiks)", "średni z-score")
    _legend(ax)
    return fig


def test_figures(result):
    return [("z_hist", z_histogram(result)), ("edits", edits_chart(result)), ("length", length_chart(result))]


# ------------------------------------------------------------------ porównanie
def comparison_quality_chart(result, ax=None):
    """AUC, TPR przy progu i FPR przy progu – słupki pogrupowane według metryki."""
    fig = None
    if ax is None:
        fig = _figure(6.4, 3.4)
        ax = fig.add_subplot()
    runs = result["runs"]
    metrics_ = [("AUC", lambda s: s["auc"]), ("TPR (próg)", lambda s: s["tpr"]["rate"]),
                ("FPR (próg)", lambda s: s["fpr"]["rate"]),
                ("TPR @ FPR 10%", lambda s: (s["tpr_at_fpr"][1] or {}).get("tpr"))]
    x = np.arange(len(metrics_))
    width = 0.8 / len(runs)
    for j, r in enumerate(runs):
        vals = [f(r["summary"]) for _, f in metrics_]
        vals = [v if v is not None else 0 for v in vals]
        pos = x - 0.4 + width * (j + 0.5)
        bars = ax.bar(pos, vals, width * 0.9, color=algo_color(r["algorithm"], j), label=_run_label(r, j))
        for b, v in zip(bars, vals):
            ax.annotate(f"{v:.2f}", (b.get_x() + b.get_width() / 2, v), textcoords="offset points",
                        xytext=(0, 3), ha="center", fontsize=7.5, color=TEXT_2)
    ax.set_xticks(x, [m for m, _ in metrics_])
    ax.set_ylim(0, 1.32)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    _style(ax, "Skuteczność detekcji", None, "wartość")
    ax.legend(loc="upper center", ncol=len(runs), fontsize=8.5, frameon=False, labelcolor=TEXT_2)
    return fig


def comparison_edits_chart(result, ax=None):
    fig = None
    if ax is None:
        fig = _figure(6.4, 3.4)
        ax = fig.add_subplot()
    for j, r in enumerate(result["runs"]):
        rows = [e for e in r["edits"] if e["detected"]["rate"] is not None]
        ax.plot([100 * e["fraction"] for e in rows], [e["detected"]["rate"] for e in rows], "-o",
                color=algo_color(r["algorithm"], j), lw=2, ms=6, markeredgecolor=SURFACE,
                markeredgewidth=1.5, label=_run_label(r, j))
    ax.set_ylim(-0.03, 1.05)
    _style(ax, "Odsetek wykryć po losowych edycjach (każdy przy własnym progu)",
           "edytowane tokeny [%]", "odsetek wykryć")
    _legend(ax)
    return fig


def comparison_cost_chart(result, ax=None):
    """Koszty względem WŁASNEJ linii bazowej: perplexity ze znakiem / bez i narzut czasu generacji."""
    fig = None
    if ax is None:
        fig = _figure(6.4, 3.2)
        ax = fig.add_subplot()
    labels = ["perplexity: ze znakiem / bez znaku", "czas na token: ze znakiem / bez znaku"]
    x = np.arange(2)
    width = 0.8 / len(result["runs"])
    for j, r in enumerate(result["runs"]):
        s = r["summary"]
        vals = [s.get("perplexity_median_ratio") or 0, s.get("gen_overhead_ratio") or 0]
        pos = x - 0.4 + width * (j + 0.5)
        bars = ax.bar(pos, vals, width * 0.9, color=algo_color(r["algorithm"], j), label=_run_label(r, j))
        for b, v in zip(bars, vals):
            ax.annotate(f"{v:.2f}×" if v else "b.d.", (b.get_x() + b.get_width() / 2, v),
                        textcoords="offset points", xytext=(0, 3), ha="center", fontsize=7.5, color=TEXT_2)
    ax.axhline(1.0, color=TEXT, lw=1, ls=(0, (4, 3)), label="brak zmiany (1×)")
    ax.set_xticks(x, labels)
    _style(ax, "Koszt znakowania względem własnej linii bazowej", None, "stosunek")
    _legend(ax, "upper left")
    return fig


def comparison_figures(result):
    return [("quality", comparison_quality_chart(result)), ("edits", comparison_edits_chart(result)),
            ("cost", comparison_cost_chart(result))]


def _run_label(run, j):
    return run["algorithm_name"].split(" (")[0]


# ------------------------------------------------------------------ demo / detekcja
def demo_chart(result):
    fig = _figure(6.4, 2.8)
    ax = fig.add_subplot()
    color = algo_color(result["algorithm"])
    names = ["ze znakiem", "bez znaku", "ze znakiem,\nbłędny klucz"]
    vals = [result["watermarked"]["detection"]["z"], result["plain"]["detection"]["z"],
            result["watermarked"]["wrong_key_detection"]["z"]]
    bars = ax.barh(names, vals, color=[color, BASELINE, BASELINE], height=0.55)
    bars[1].set_hatch("///")
    bars[2].set_hatch("..")
    for b, v in zip(bars, vals):
        ax.annotate(f"z = {v:.2f}", (v, b.get_y() + b.get_height() / 2), textcoords="offset points",
                    xytext=(4 if v >= 0 else -4, 0), ha="left" if v >= 0 else "right", va="center",
                    fontsize=8, color=TEXT_2)
    ax.invert_yaxis()
    ax.axvline(result["watermarked"]["detection"]["threshold"], color=TEXT, lw=1, ls=(0, (4, 3)),
               label=f"próg z = {result['watermarked']['detection']['threshold']:g}")
    _style(ax, "Wynik detekcji", "z-score", None)
    ax.grid(True, axis="x", color=GRID)
    ax.grid(False, axis="y")
    _legend(ax, "lower right")
    return fig


def figure_png(fig, dpi=160) -> bytes:
    import io
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    FigureCanvasAgg(fig)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, facecolor=fig.get_facecolor())
    return buf.getvalue()
