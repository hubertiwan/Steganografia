"""Przebiegi eksperymentów – warstwa niezależna od GUI.

Każda funkcja zwraca słownik gotowy do zapisu w JSON (historia, raporty). Funkcje długie
przyjmują ``progress(frac, message)`` oraz ``should_stop()`` – GUI uruchamia je w osobnym
wątku i może je przerwać (sprawdzane między kolejnymi generacjami tekstu).

Terminologia „kodowanie/dekodowanie” w kontekście tych algorytmów:
  kodowanie  = generacja tekstu przez model ze znakiem wodnym (osadzenie 1 bitu),
  dekodowanie = detekcja znaku w tekście (test statystyczny z kluczem).
"""
import time
from pathlib import Path

import numpy as np

from . import algorithms, metrics
from .errors import ExperimentCancelled, InputError
from .paths import ensure_repo_on_path

ensure_repo_on_path()

PLAIN_SEED_OFFSET = 10_000      # jak w demo.py: teksty bez znaku mają ziarna 10 000 + i
DEFAULT_EDIT_FRACTIONS = [0.0, 0.1, 0.2, 0.3, 0.5]
DEFAULT_EDIT_SEED = 123          # jak w demo.py / demo_synthid.py
MAX_TEXT_FILE_BYTES = 5 * 1024 * 1024


def builtin_prompts():
    """20 poleceń z oryginalnego demo.py."""
    from demo import PROMPTS
    return list(PROMPTS)


# ------------------------------------------------------------------ wejście z plików
def read_text_file(path) -> str:
    p = Path(path)
    if not str(path).strip():
        raise InputError("Nie wskazano pliku.", "Wybierz plik .txt przyciskiem „Wczytaj z pliku…”.")
    if not p.exists():
        raise InputError(f"Plik nie istnieje: {p}", "Sprawdź ścieżkę lub wybierz plik ponownie.")
    if p.is_dir():
        raise InputError(f"Wskazana ścieżka jest katalogiem: {p}", "Wybierz plik tekstowy.")
    if p.stat().st_size > MAX_TEXT_FILE_BYTES:
        raise InputError(f"Plik jest zbyt duży ({p.stat().st_size / 1e6:.1f} MB).",
                         "Maksymalny rozmiar pliku tekstowego to 5 MB.")
    raw = p.read_bytes()
    if b"\x00" in raw[:4096]:
        raise InputError(f"Plik {p.name} wygląda na binarny, a nie tekstowy.",
                         "Obsługiwane są pliki tekstowe UTF-8 (.txt).")
    for enc in ("utf-8-sig", "cp1250"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise InputError(f"Nie udało się odczytać pliku {p.name} jako tekstu.", "Zapisz plik w kodowaniu UTF-8.")


def read_prompts_file(path) -> list[str]:
    prompts = [line.strip() for line in read_text_file(path).splitlines() if line.strip()]
    if not prompts:
        raise InputError(f"Plik {Path(path).name} nie zawiera żadnych poleceń.",
                         "Umieść jedno polecenie (prompt) w każdym wierszu.")
    return prompts


# ------------------------------------------------------------------ pomocnicze
def _check(should_stop, done=None):
    if should_stop is not None and should_stop():
        exc = ExperimentCancelled()
        exc.completed = done
        raise exc


def _token_pieces(lm, tokens):
    """Tekst każdego tokenu do kolorowania. Tokeny HF niosą własne spacje; pseudosłowa modelu
    syntetycznego są rozdzielane spacją przy dekodowaniu, więc trzeba ją tu dodać."""
    pieces = [lm.tokenizer.decode([int(t)]) for t in tokens]
    if lm.kind == "synthetic":
        pieces = [(" " if i else "") + p for i, p in enumerate(pieces)]
    return pieces


def _detect_tokens(lm, text, gen_tokens, detect_on):
    return lm.tokenize(text) if detect_on == "text" else list(gen_tokens)


def _validate_generation(max_new_tokens, prompt=None):
    if not isinstance(max_new_tokens, int) or not 1 <= max_new_tokens <= 2000:
        raise InputError(f"Nieprawidłowa liczba nowych tokenów: {max_new_tokens}.", "Podaj wartość od 1 do 2000.")
    if prompt is not None and not str(prompt).strip():
        raise InputError("Polecenie (prompt) jest puste.", "Wpisz polecenie dla modelu językowego.")


def _generate_timed(adapter, lm, prompt, wm, params, max_new_tokens, seed):
    t0 = time.perf_counter()
    tokens, text = adapter.generate(lm, prompt, wm, params, max_new_tokens, seed)
    dt = time.perf_counter() - t0
    return list(tokens), text, dt


# ------------------------------------------------------------------ demo
def run_demo(lm, algo_id, params, prompt, max_new_tokens=100, seed=1, progress=None, should_stop=None):
    """Jedno polecenie: tekst ze znakiem i bez znaku, detekcja obu (oraz z błędnym kluczem)."""
    adapter = algorithms.get(algo_id)
    params = adapter.spec.validate(params)
    _validate_generation(max_new_tokens, prompt)
    wm = adapter.build(params, lm.vocab_size)
    wrong_params = adapter.wrong_key_params(params)
    wm_wrong = adapter.build(wrong_params, lm.vocab_size)
    progress = progress or (lambda *_: None)

    out = {"kind": "demo", "algorithm": algo_id, "algorithm_name": adapter.spec.name,
           "params": params, "model": lm.describe(), "prompt": prompt,
           "settings": {"max_new_tokens": max_new_tokens, "seed": seed,
                        "plain_seed": seed + PLAIN_SEED_OFFSET, "detect_on": "text"}}
    for role, w, s, frac in (("watermarked", wm, seed, 0.0), ("plain", None, seed + PLAIN_SEED_OFFSET, 0.45)):
        _check(should_stop)
        progress(frac, "Generacja tekstu " + ("ze znakiem wodnym…" if w else "bez znaku (linia bazowa)…"))
        tokens, text, gen_time = _generate_timed(adapter, lm, prompt, w, params, max_new_tokens, s)
        t0 = time.perf_counter()
        det_tokens = lm.tokenize(text)
        detection = adapter.detect(wm, det_tokens, params)
        det_time = time.perf_counter() - t0
        out[role] = {
            "text": text, "n_generated": len(tokens), "gen_time_s": gen_time,
            "tokens_per_s": len(tokens) / gen_time if gen_time > 0 else None,
            "detection": detection, "detection_on_generated_tokens": adapter.detect(wm, tokens, params),
            "det_time_s": det_time,
            "wrong_key_detection": adapter.detect(wm_wrong, det_tokens, wrong_params),
            "tokens": det_tokens, "pieces": _token_pieces(lm, det_tokens),
            "annotation": adapter.annotate(wm, det_tokens),
            "generated_tokens": tokens,
        }
    progress(0.9, "Obliczanie perplexity…")
    for role in ("watermarked", "plain"):
        gen = out[role]
        try:
            # oceniane są tokeny z generacji (jak w demo_synthid.py), nie retokenizowany tekst
            gen["perplexity"] = metrics.perplexity(lm, prompt, gen["generated_tokens"])
        except Exception as exc:  # perplexity jest pomocnicza – błąd nie przerywa demo, ale jest raportowany
            gen["perplexity"] = None
            gen["perplexity_error"] = f"{type(exc).__name__}: {exc}"
    progress(1.0, "Gotowe")
    return out


def detect_text(lm, algo_id, params, text):
    """Detekcja znaku w dowolnym tekście (np. wklejonym albo zmodyfikowanym przez użytkownika)."""
    adapter = algorithms.get(algo_id)
    params = adapter.spec.validate(params)
    if not text or not text.strip():
        raise InputError("Tekst do detekcji jest pusty.", "Wklej tekst lub wczytaj go z pliku .txt.")
    wm = adapter.build(params, lm.vocab_size)
    t0 = time.perf_counter()
    tokens = lm.tokenize(text)
    detection = adapter.detect(wm, tokens, params)
    det_time = time.perf_counter() - t0
    return {"kind": "detect", "algorithm": algo_id, "algorithm_name": adapter.spec.name,
            "params": params, "model": lm.describe(), "text": text,
            "detection": detection, "det_time_s": det_time, "tokens": tokens,
            "pieces": _token_pieces(lm, tokens), "annotation": adapter.annotate(wm, tokens)}


def random_edit_text(lm, text, fraction, seed=0):
    """Losowe edycje (wstawienie/usunięcie/zamiana) ułamka tokenów – funkcja random_edits z repozytorium."""
    if not 0 <= fraction <= 1:
        raise InputError("Ułamek edycji musi być w przedziale [0, 1].", "")
    tokens = lm.tokenize(text)
    if not tokens:
        raise InputError("Brak tokenów do edycji.", "Najpierw wygeneruj lub wklej tekst.")
    edited = metrics.random_edits(tokens, fraction, lm.vocab_size, np.random.default_rng(seed))
    return lm.tokenizer.decode(edited, skip_special_tokens=True)


# ------------------------------------------------------------------ test
def normalise_settings(settings: dict) -> dict:
    s = dict(settings)
    prompts = [p for p in s.get("prompts", []) if str(p).strip()]
    if not prompts:
        raise InputError("Lista poleceń jest pusta.", "Wybierz wbudowany zestaw poleceń albo wczytaj plik .txt.")
    s["prompts"] = prompts
    s["max_new_tokens"] = int(s.get("max_new_tokens", 100))
    _validate_generation(s["max_new_tokens"])
    s["base_seed"] = int(s.get("base_seed", 0))
    s["detect_on"] = s.get("detect_on", "text")
    if s["detect_on"] not in ("text", "tokens"):
        raise InputError(f"Nieznany tryb detekcji: {s['detect_on']}", "Wybierz „text” lub „tokens”.")
    fr = sorted(set(float(f) for f in s.get("edit_fractions", DEFAULT_EDIT_FRACTIONS)))
    if any(not 0 <= f <= 1 for f in fr):
        raise InputError("Ułamki edycji muszą należeć do [0, 1].", "Popraw listę ułamków edycji.")
    s["edit_fractions"] = fr
    s["edit_seed"] = int(s.get("edit_seed", DEFAULT_EDIT_SEED))
    s["compute_perplexity"] = bool(s.get("compute_perplexity", True))
    s["wrong_key_control"] = bool(s.get("wrong_key_control", True))
    return s


def run_test(lm, algo_id, params, settings, progress=None, should_stop=None, _span=(0.0, 1.0)):
    """Seria N poleceń: N tekstów ze znakiem i N bez znaku, ta sama metodologia co demo.py/demo_synthid.py."""
    adapter = algorithms.get(algo_id)
    params = adapter.spec.validate(params)
    s = normalise_settings(settings)
    wm = adapter.build(params, lm.vocab_size)
    wrong_params = adapter.wrong_key_params(params)
    wm_wrong = adapter.build(wrong_params, lm.vocab_size) if s["wrong_key_control"] else None
    progress = progress or (lambda *_: None)
    a, b = _span
    prompts = s["prompts"]
    total_steps = 2 * len(prompts) + 1
    started = time.perf_counter()

    def report(step, msg):
        progress(a + (b - a) * step / total_steps, msg)

    samples, gen_wm, gen_plain = [], [], []
    for i, prompt in enumerate(prompts):
        sample = {"index": i, "prompt": prompt}
        for role, w, seed in (("watermarked", wm, s["base_seed"] + i),
                              ("plain", None, s["base_seed"] + PLAIN_SEED_OFFSET + i)):
            _check(should_stop, i)
            step = 2 * i + (0 if w else 1)
            report(step, f"{adapter.spec.name}: tekst {i + 1}/{len(prompts)} "
                         f"{'ze znakiem' if w else 'bez znaku'}")
            tokens, text, gen_time = _generate_timed(adapter, lm, prompt, w, params, s["max_new_tokens"], seed)
            t0 = time.perf_counter()
            det_tokens = _detect_tokens(lm, text, tokens, s["detect_on"])
            det = adapter.detect(wm, det_tokens, params)
            det_time = time.perf_counter() - t0
            rec = {"seed": seed, "text": text, "n_generated": len(tokens), "n_detect_tokens": len(det_tokens),
                   "gen_time_s": gen_time, "det_time_s": det_time, "detection": det}
            if s["compute_perplexity"]:
                try:
                    rec["perplexity"] = metrics.perplexity(lm, prompt, tokens)
                except Exception as exc:
                    rec["perplexity"] = None
                    rec["perplexity_error"] = f"{type(exc).__name__}: {exc}"
            if w is not None and wm_wrong is not None:
                rec["wrong_key_detection"] = adapter.detect(wm_wrong, det_tokens, wrong_params)
            sample[role] = rec
            (gen_wm if w else gen_plain).append(tokens)
        samples.append(sample)

    report(total_steps - 1, "Analiza wyników (edycje, długość tekstu)…")
    result = {
        "kind": "test", "algorithm": algo_id, "algorithm_name": adapter.spec.name,
        "params": params, "model": lm.describe(), "settings": s, "samples": samples,
        "summary": _summarise(adapter, samples, s, params),
        "edits": _edit_robustness(adapter, wm, params, gen_wm, s, lm.vocab_size),
        "length_curve": _length_curve(adapter, wm, gen_wm, gen_plain, s["max_new_tokens"]),
        "duration_s": time.perf_counter() - started,
    }
    report(total_steps, "Gotowe")
    return result


def _summarise(adapter, samples, s, params):
    wm_recs = [x["watermarked"] for x in samples]
    pl_recs = [x["plain"] for x in samples]
    z_wm = [r["detection"]["z"] for r in wm_recs]
    z_pl = [r["detection"]["z"] for r in pl_recs]
    threshold = wm_recs[0]["detection"]["threshold"] if wm_recs else None
    gen_t_wm = sum(r["gen_time_s"] for r in wm_recs)
    gen_t_pl = sum(r["gen_time_s"] for r in pl_recs)
    n_wm = sum(r["n_generated"] for r in wm_recs)
    n_pl = sum(r["n_generated"] for r in pl_recs)
    summary = {
        "n_texts": len(samples),
        "threshold": threshold,
        "tpr": metrics.rate(r["detection"]["watermarked"] for r in wm_recs),
        "fpr": metrics.rate(r["detection"]["watermarked"] for r in pl_recs),
        "auc": metrics.auc(z_wm, z_pl),
        "tpr_at_fpr": [metrics.empirical_tpr_at_fpr(z_wm, z_pl, f) for f in (0.01, 0.10)],
        "z_watermarked": metrics.describe(z_wm),
        "z_plain": metrics.describe(z_pl),
        "p_value_watermarked_median": metrics.describe([r["detection"]["p_value"] for r in wm_recs])["median"],
        "tokens_watermarked": metrics.describe([r["n_generated"] for r in wm_recs]),
        "tokens_plain": metrics.describe([r["n_generated"] for r in pl_recs]),
        "scored_tokens_watermarked": metrics.describe([r["detection"]["n_scored"] for r in wm_recs]),
        "gen_speed_watermarked": n_wm / gen_t_wm if gen_t_wm > 0 else None,
        "gen_speed_plain": n_pl / gen_t_pl if gen_t_pl > 0 else None,
        "gen_time_per_token_ms_watermarked": 1000 * gen_t_wm / n_wm if n_wm else None,
        "gen_time_per_token_ms_plain": 1000 * gen_t_pl / n_pl if n_pl else None,
        "det_time_ms": metrics.describe([1000 * r["det_time_s"] for r in wm_recs + pl_recs]),
    }
    if summary["gen_time_per_token_ms_watermarked"] and summary["gen_time_per_token_ms_plain"]:
        summary["gen_overhead_ratio"] = (summary["gen_time_per_token_ms_watermarked"]
                                         / summary["gen_time_per_token_ms_plain"])
    if s["compute_perplexity"]:
        ppl_wm = metrics.describe([r.get("perplexity") for r in wm_recs])
        ppl_pl = metrics.describe([r.get("perplexity") for r in pl_recs])
        summary["perplexity_watermarked"] = ppl_wm
        summary["perplexity_plain"] = ppl_pl
        if ppl_wm["median"] and ppl_pl["median"]:
            summary["perplexity_median_ratio"] = ppl_wm["median"] / ppl_pl["median"]
    if s["wrong_key_control"]:
        summary["wrong_key_fpr"] = metrics.rate(r["wrong_key_detection"]["watermarked"] for r in wm_recs)
        summary["z_wrong_key"] = metrics.describe([r["wrong_key_detection"]["z"] for r in wm_recs])
    if adapter.spec.id == "unigram":
        summary["green_frac_watermarked"] = metrics.describe([r["detection"]["green_frac"] for r in wm_recs])
        summary["green_frac_plain"] = metrics.describe([r["detection"]["green_frac"] for r in pl_recs])
        summary["unique_tpr"] = metrics.rate(r["detection"]["unique_watermarked"] for r in wm_recs)
        summary["unique_fpr"] = metrics.rate(r["detection"]["unique_watermarked"] for r in pl_recs)
    if adapter.spec.id == "synthid":
        summary["mean_g_watermarked"] = metrics.describe([r["detection"]["mean_g"] for r in wm_recs])
        summary["mean_g_plain"] = metrics.describe([r["detection"]["mean_g"] for r in pl_recs])
    return summary


def _edit_robustness(adapter, wm, params, gen_wm, s, vocab_size):
    """Jak w demo.py: losowe edycje na identyfikatorach tokenów tekstów ze znakiem."""
    rng = np.random.default_rng(s["edit_seed"])
    rows = []
    for frac in s["edit_fractions"]:
        dets = [adapter.detect(wm, metrics.random_edits(t, frac, vocab_size, rng), params) for t in gen_wm if t]
        zs = [d["z"] for d in dets]
        rows.append({"fraction": frac, "mean_z": float(np.mean(zs)) if zs else None,
                     "detected": metrics.rate(d["watermarked"] for d in dets)})
    return rows


def _length_curve(adapter, wm, gen_wm, gen_plain, max_new_tokens):
    """Średni z-score prefiksów długości n (jak drugi wykres w demo.py)."""
    lengths = sorted({n for n in (10, 25, 50, 100, 150, 200, 300, 500) if n <= max_new_tokens} | {max_new_tokens})
    rows = []
    for n in lengths:
        # jak w demo.py: prefiks t[:n] każdego tekstu (krótszy tekst wchodzi w całości)
        zw = [adapter.z_only(wm, t[:n]) for t in gen_wm]
        zp = [adapter.z_only(wm, t[:n]) for t in gen_plain]
        rows.append({"n": n, "mean_z_watermarked": float(np.mean(zw)) if zw else None,
                     "mean_z_plain": float(np.mean(zp)) if zp else None})
    return rows


# ------------------------------------------------------------------ porównanie
def run_comparison(lm, configs, settings, progress=None, should_stop=None):
    """configs: lista (algo_id, params). Wszystkie algorytmy dostają ten sam model, te same
    polecenia, te same ziarna, tę samą długość tekstu i ten sam tryb detekcji."""
    if len(configs) < 2:
        raise InputError("Do porównania potrzebne są co najmniej dwie konfiguracje.",
                         "Zaznacz co najmniej dwa algorytmy (lub dwa zestawy parametrów).")
    s = normalise_settings(settings)
    runs = []
    k = len(configs)
    for j, (algo_id, params) in enumerate(configs):
        runs.append(run_test(lm, algo_id, params, s, progress, should_stop, _span=(j / k, (j + 1) / k)))
    return {"kind": "comparison", "model": lm.describe(), "settings": s, "runs": runs,
            "conditions": comparison_conditions(runs, s, lm)}


def comparison_conditions(runs, s, lm):
    """Jawny opis warunków eksperymentu i tego, co jest (a co nie jest) bezpośrednio porównywalne."""
    common = {"model": lm.label, "liczba poleceń": len(s["prompts"]), "maks. nowych tokenów": s["max_new_tokens"],
              "ziarno bazowe": s["base_seed"], "detekcja na": "tekście po retokenizacji" if s["detect_on"] == "text"
              else "tokenach z generacji", "ułamki edycji": ", ".join(f"{f:g}" for f in s["edit_fractions"]),
              "ziarno edycji": s["edit_seed"]}
    per_run = []
    for r in runs:
        spec = algorithms.get(r["algorithm"]).spec
        sampling = {p.label: r["params"][p.name] for p in spec.params if p.group == "sampling"}
        per_run.append({"algorithm": r["algorithm_name"], "threshold": r["summary"]["threshold"],
                        "sampling": sampling})
    notes = [
        "Wszystkie konfiguracje użyły tego samego modelu, poleceń, ziaren, długości tekstu i trybu detekcji.",
        "Każdy algorytm porównywany jest z WŁASNĄ linią bazową bez znaku, generowaną tym samym sposobem "
        "próbkowania co tekst ze znakiem (jak w demo.py i demo_synthid.py).",
    ]
    samplings = {tuple(sorted(x["sampling"].items())) for x in per_run}
    if len(samplings) > 1:
        notes.append("UWAGA: algorytmy mają różne ustawienia próbkowania (np. top-p vs top-k, temperatura). "
                     "Bezwzględne perplexity i szybkość nie są bezpośrednio porównywalne – porównuj stosunek "
                     "do własnej linii bazowej (perplexity ze znakiem / bez znaku, narzut czasu).")
    if len({x["threshold"] for x in per_run}) > 1:
        notes.append("UWAGA: progi detekcji różnią się (np. τ = 6 vs 2.326), więc TPR/FPR przy progu nie są "
                     "porównywalne wprost. Do porównania skuteczności użyj AUC oraz TPR przy tym samym "
                     "empirycznym FPR. Statystyki z obu detektorów mają rozkład ≈ N(0, 1) bez znaku.")
    notes.append("Przy małej liczbie tekstów TPR/FPR mają szerokie przedziały ufności (podane w tabeli); "
                 "różnice mieszczące się w przedziałach nie są rozstrzygające.")
    return {"common": common, "per_run": per_run, "notes": notes}
