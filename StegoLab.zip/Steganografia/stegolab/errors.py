"""Wyjątki z komunikatem dla użytkownika i podpowiedzią, jak rozwiązać problem."""


class StegoLabError(Exception):
    """Błąd, który GUI pokazuje użytkownikowi w czytelnej formie."""

    def __init__(self, message: str, hint: str = ""):
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self):
        return f"{self.message}\n{self.hint}" if self.hint else self.message


class ParameterError(StegoLabError):
    pass


class InputError(StegoLabError):
    pass


class ModelError(StegoLabError):
    pass


class PdfError(StegoLabError):
    pass


class ExperimentCancelled(StegoLabError):
    def __init__(self, message="Eksperyment przerwany przez użytkownika.", hint=""):
        super().__init__(message, hint)
