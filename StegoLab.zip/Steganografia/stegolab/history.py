"""Historia eksperymentów: jeden plik JSON na eksperyment w stegolab_data/experiments/.

Zapisywane są także eksperymenty przerwane i zakończone błędem (status + komunikat),
żeby historia odzwierciedlała rzeczywisty przebieg pracy.
"""
import json
import math
import uuid
from datetime import datetime
from pathlib import Path

from .paths import experiments_dir

STATUS_LABELS = {"ok": "Zakończony", "error": "Błąd", "cancelled": "Przerwany"}
KIND_LABELS = {"demo": "Demonstracja", "test": "Test", "comparison": "Porównanie", "detect": "Detekcja tekstu"}


def _clean(obj):
    """JSON nie obsługuje NaN/inf ani typów numpy – zamiana na typy wbudowane."""
    if isinstance(obj, dict):
        return {str(k): _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if hasattr(obj, "item") and callable(obj.item):  # skalary numpy
        obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


def new_record(kind, title, algorithms, params=None, files=None, model=None):
    return {"id": datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6],
            "created": datetime.now().isoformat(timespec="seconds"),
            "kind": kind, "title": title, "algorithms": list(algorithms),
            "params": params or {}, "files": files or [], "model": model or {},
            "status": "running", "duration_s": None, "result": None, "error": None}


def save(record) -> Path:
    path = experiments_dir() / f"{record['id']}.json"
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(_clean(record), ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)  # zapis atomowy – przerwanie aplikacji nie uszkodzi pliku
    return path


def load(record_id):
    path = experiments_dir() / f"{record_id}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def list_records(limit=None):
    """Najnowsze najpierw. Uszkodzone pliki są pomijane, ale zgłaszane w polu 'corrupt'."""
    records = []
    for path in sorted(experiments_dir().glob("*.json"), reverse=True):
        try:
            rec = json.loads(path.read_text(encoding="utf-8"))
            rec.pop("result", None)  # lista nie potrzebuje pełnych wyników
            records.append(rec)
        except (OSError, json.JSONDecodeError):
            records.append({"id": path.stem, "created": "", "kind": "?", "title": f"Uszkodzony plik {path.name}",
                            "algorithms": [], "status": "error", "corrupt": True})
        if limit and len(records) >= limit:
            break
    return records


def delete(record_id):
    path = experiments_dir() / f"{record_id}.json"
    if path.exists():
        path.unlink()
