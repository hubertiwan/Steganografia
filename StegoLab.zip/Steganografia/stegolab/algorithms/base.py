"""Wspólny opis algorytmów i ich parametrów.

Adapter NIE zawiera logiki znakowania – woła wyłącznie funkcje z oryginalnych pakietów
repozytorium (unigram_watermark, synthid_watermark). Jego zadaniem jest:
  * opis algorytmu dla GUI (nazwa, zasada działania, ograniczenia, metryki),
  * walidacja parametrów,
  * ujednolicony interfejs: build → generate → detect → annotate.
"""
from dataclasses import dataclass, field
from typing import Any

from ..errors import ParameterError


@dataclass(frozen=True)
class ParamSpec:
    name: str
    label: str
    kind: str                 # "int", "float", "str"
    default: Any
    help: str
    minimum: float | None = None
    maximum: float | None = None
    step: float | None = None
    decimals: int = 3
    group: str = "watermark"  # "watermark" | "detection" | "sampling"
    exclusive_min: bool = False

    def coerce(self, value):
        """Zamienia wartość z GUI/JSON na właściwy typ i sprawdza zakres."""
        try:
            if self.kind == "int":
                if isinstance(value, float) and not value.is_integer():
                    raise ValueError
                value = int(value)
            elif self.kind == "float":
                value = float(value)
            else:
                value = str(value)
        except (TypeError, ValueError):
            raise ParameterError(
                f"Parametr „{self.label}” ma nieprawidłową wartość: {value!r}.",
                f"Podaj wartość typu {'całkowitego' if self.kind == 'int' else 'liczbowego' if self.kind == 'float' else 'tekstowego'}.")
        if self.kind in ("int", "float"):
            if value != value:  # NaN
                raise ParameterError(f"Parametr „{self.label}” nie może być NaN.", "Podaj liczbę.")
            low_bad = self.minimum is not None and (value <= self.minimum if self.exclusive_min else value < self.minimum)
            high_bad = self.maximum is not None and value > self.maximum
            if low_bad or high_bad:
                low = "(" if self.exclusive_min else "["
                raise ParameterError(
                    f"Parametr „{self.label}” = {value} jest poza zakresem "
                    f"{low}{self.minimum if self.minimum is not None else '-∞'}, "
                    f"{self.maximum if self.maximum is not None else '∞'}].",
                    self.help)
        elif not value.strip():
            raise ParameterError(f"Parametr „{self.label}” nie może być pusty.", self.help)
        return value


@dataclass(frozen=True)
class AlgorithmSpec:
    id: str
    name: str
    short: str
    paper: str
    source_package: str
    description: str
    principle: list[str]
    embedding: str             # „kodowanie” – osadzanie znaku
    detection: str             # „dekodowanie” – detekcja znaku
    inputs: list[str]
    formats: list[str]
    limitations: list[str]
    operations: list[str]
    metrics: list[str]
    not_applicable: list[str]
    params: list[ParamSpec] = field(default_factory=list)
    color: str = "#4f46e5"

    def param(self, name) -> ParamSpec:
        for p in self.params:
            if p.name == name:
                return p
        raise KeyError(name)

    def defaults(self) -> dict:
        return {p.name: p.default for p in self.params}

    def validate(self, params: dict) -> dict:
        """Uzupełnia brakujące parametry domyślnymi i sprawdza typy/zakresy."""
        out = {}
        unknown = set(params) - {p.name for p in self.params}
        if unknown:
            raise ParameterError(f"Nieznane parametry dla {self.name}: {', '.join(sorted(unknown))}.",
                                 "Usuń je z konfiguracji eksperymentu.")
        for p in self.params:
            out[p.name] = p.coerce(params.get(p.name, p.default))
        return out


class AlgorithmAdapter:
    """Interfejs wspólny dla adapterów."""

    spec: AlgorithmSpec

    def build(self, params: dict, vocab_size: int):
        """Tworzy obiekt znaku wodnego z oryginalnego pakietu."""
        raise NotImplementedError

    def generate(self, lm, prompt: str, wm, params: dict, max_new_tokens: int, seed: int):
        """wm=None → generacja bez znaku (linia bazowa). Zwraca (token_ids, text)."""
        raise NotImplementedError

    def detect(self, wm, tokens, params: dict) -> dict:
        """Zwraca słownik o wspólnych kluczach: z, p_value, n_scored, watermarked, threshold
        oraz pola specyficzne dla algorytmu."""
        raise NotImplementedError

    def annotate(self, wm, tokens) -> list:
        """Ocena każdego tokenu do kolorowania (None = token nieoceniany)."""
        raise NotImplementedError

    def wrong_key_params(self, params: dict) -> dict:
        """Parametry z innym kluczem – próba kontrolna (detekcja nie powinna zadziałać)."""
        raise NotImplementedError

    def z_only(self, wm, tokens) -> float:
        return self.detect(wm, tokens, self.spec.defaults())["z"]
