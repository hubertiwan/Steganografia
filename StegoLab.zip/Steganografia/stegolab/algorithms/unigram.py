"""Adapter Unigram-Watermark (pakiet ``unigram_watermark`` z repozytorium)."""
from .base import AlgorithmAdapter, AlgorithmSpec, ParamSpec
from ..errors import ParameterError
from ..paths import ensure_repo_on_path

ensure_repo_on_path()
from unigram_watermark import UnigramWatermark  # noqa: E402  (oryginalna implementacja)
from unigram_watermark import generate as unigram_generate  # noqa: E402

SPEC = AlgorithmSpec(
    id="unigram",
    name="Unigram-Watermark",
    short="Stała zielona lista słownika + bonus δ do logitów",
    paper=("Xuandong Zhao, Prabhanjan Ananth, Lei Li, Yu-Xiang Wang. Provable Robust Watermarking "
           "for AI-Generated Text. arXiv:2306.17439 (ICLR 2024)."),
    source_package="unigram_watermark (core.py: UnigramWatermark, generation.py: generate)",
    description=(
        "Znak wodny osadzany w tekście generowanym przez model językowy. Tajny klucz dzieli słownik "
        "modelu na listę „zieloną” (ułamek γ tokenów) i „czerwoną”. Podział jest stały dla całego "
        "tekstu (stąd „unigram”). Podczas generacji logity zielonych tokenów są zwiększane o δ, "
        "więc model nieco częściej wybiera zielone tokeny. Detektor zna klucz, liczy zielone tokeny "
        "i wykonuje jednostronny test z."),
    principle=[
        "Klucz → SHA-256 → ziarno generatora → losowa permutacja słownika; pierwsze ⌊γ·|V|⌋ tokenów to lista zielona G.",
        "Algorytm 1 (znakowanie): l̂[v] = l[v] + δ·1(v ∈ G); potem temperatura i próbkowanie nucleus (top-p).",
        "Algorytm 2 (detekcja): z = (|y|_G − γn) / √(nγ(1−γ)); tekst oznaczony, gdy z > τ (w pracy τ = 6).",
        "Algorytm 4 („Unique”): ten sam test na tekście bez powtórzeń tokenów, próg z równania (9) "
        "dla zadanego poziomu fałszywych alarmów α.",
    ],
    embedding=("Generacja tekstu przez model językowy z modyfikacją logitów (funkcja generate() "
               "z unigram_watermark.generation). Ukrywana informacja to jeden bit: „tekst pochodzi "
               "z modelu ze znakiem o kluczu K”."),
    detection=("Tokenizacja tekstu i test statystyczny (UnigramWatermark.detect – Alg. 2 oraz "
               "UnigramWatermark.detect_unique – Alg. 4). Detektor potrzebuje tylko klucza i tokenizera, "
               "bez modelu."),
    inputs=["Polecenie (prompt) dla modelu językowego – tekst lub plik .txt (jedno polecenie w wierszu)",
            "Tajny klucz (liczba całkowita)",
            "Do detekcji: dowolny tekst (wklejony lub z pliku .txt)"],
    formats=["Tekst UTF-8 (.txt) – polecenia i teksty do detekcji",
             "Model językowy Hugging Face (np. Qwen/Qwen2.5-0.5B-Instruct, facebook/opt-1.3b) lub lokalny katalog modelu",
             "Model syntetyczny (wbudowany, do szybkich eksperymentów statystycznych)"],
    limitations=[
        "Znak zerobitowy: nie przenosi wiadomości, tylko informację o obecności znaku → brak sensu liczenia BER i pojemności w bitach.",
        "Siła detekcji rośnie ~√n: krótkie teksty (kilkadziesiąt tokenów) są wykrywane słabo.",
        "Teksty o niskiej entropii (np. wyliczanki, kod) słabo przenoszą znak – model i tak wybiera ten sam token.",
        "Stała lista zielona może zostać odtworzona z wielu tekstów (atak statystyczny) – repozytorium tego nie bada.",
        "Detekcja wymaga tego samego tokenizera i rozmiaru słownika co przy generacji.",
        "Nieodtworzone w repozytorium: ataki parafrazą (ChatGPT, DIPPER, BART) i porównanie z Kirchenbauer i in. (2023).",
    ],
    operations=["Generacja tekstu ze znakiem i bez znaku (linia bazowa)",
                "Detekcja Alg. 2 i Alg. 4 (Unique)",
                "Kolorowanie tokenów (zielone/czerwone)",
                "Test odporności na losowe edycje tokenów",
                "Kontrola z błędnym kluczem"],
    metrics=["z-score i p-value (Alg. 2), decyzja z > τ",
             "Odsetek zielonych tokenów",
             "z-score i próg Alg. 4 (Unique)",
             "TPR / FPR przy progu τ (z przedziałem Wilsona 95%)",
             "TPR przy empirycznym FPR 1% i 10%, AUC",
             "Perplexity (miara jakości tekstu)",
             "Czas generacji (kodowania) i detekcji (dekodowania), narzut znakowania",
             "Średni z-score po losowych edycjach i odsetek wykryć"],
    not_applicable=["PSNR, MSE, MAE, SSIM – nośnikiem jest tekst, nie obraz",
                    "BER – znak zerobitowy nie przenosi ciągu bitów wiadomości",
                    "Pojemność steganograficzna w bitach – algorytm osadza wyłącznie 1 bit (obecność znaku)"],
    params=[
        ParamSpec("key", "Klucz tajny", "int", 15485863,
                  "Liczba całkowita wyznaczająca podział słownika (domyślna z demo.py).",
                  minimum=0, maximum=2**63 - 1),
        ParamSpec("gamma", "γ – ułamek listy zielonej", "float", 0.5,
                  "Ułamek słownika na liście zielonej, przedział (0, 1). W pracy γ = 0.5.",
                  minimum=0.0, maximum=0.999, step=0.05, exclusive_min=True),
        ParamSpec("delta", "δ – siła znaku", "float", 2.0,
                  "Bonus dodawany do logitów zielonych tokenów. W pracy δ = 2.0. δ = 0 wyłącza znak.",
                  minimum=0.0, maximum=20.0, step=0.5),
        ParamSpec("tau", "τ – próg detekcji (z)", "float", 6.0,
                  "Próg z-score dla Alg. 2. W pracy τ = 6 (Rys. 1a).",
                  minimum=0.0, maximum=50.0, step=0.5, group="detection"),
        ParamSpec("unique_alpha", "α – poziom FPR (Alg. 4)", "float", 0.01,
                  "Docelowy odsetek fałszywych alarmów detektora Unique, przedział (0, 0.5].",
                  minimum=0.0, maximum=0.5, step=0.01, decimals=4, group="detection", exclusive_min=True),
        ParamSpec("temperature", "Temperatura", "float", 1.0,
                  "Temperatura próbkowania (w pracy 1.0).",
                  minimum=0.0, maximum=5.0, step=0.1, group="sampling", exclusive_min=True),
        ParamSpec("top_p", "top-p (nucleus)", "float", 0.9,
                  "Masa prawdopodobieństwa próbkowania nucleus, przedział (0, 1]. W pracy 0.9.",
                  minimum=0.0, maximum=1.0, step=0.05, group="sampling", exclusive_min=True),
    ],
    color="#2a78d6",
)


class UnigramAdapter(AlgorithmAdapter):
    spec = SPEC

    def build(self, params, vocab_size):
        p = self.spec.validate(params)
        wm = UnigramWatermark(key=p["key"], vocab_size=vocab_size, gamma=p["gamma"], delta=p["delta"])
        if wm.green_size == 0 or wm.green_size == wm.vocab_size:
            # z-score dzieliłby przez zero (γ_eff ∈ {0, 1})
            raise ParameterError(
                f"Dla słownika {vocab_size} tokenów i γ = {p['gamma']} lista zielona ma {wm.green_size} tokenów.",
                "Wybierz γ tak, aby lista zielona i czerwona były niepuste.")
        return wm

    def generate(self, lm, prompt, wm, params, max_new_tokens, seed):
        p = self.spec.validate(params)
        return unigram_generate(lm.model, lm.tokenizer, prompt, wm=wm, max_new_tokens=max_new_tokens,
                                temperature=p["temperature"], top_p=p["top_p"], seed=seed,
                                use_chat_template=lm.use_chat_template)

    def detect(self, wm, tokens, params):
        p = self.spec.validate(params)
        tokens = [int(t) for t in tokens]
        base = wm.detect(tokens, tau=p["tau"])
        uniq = wm.detect_unique(tokens, alpha=p["unique_alpha"])
        return {
            "z": base["z"],
            "p_value": base["p_value"],
            "n_scored": base["n"],
            "watermarked": bool(base["watermarked"]),
            "threshold": p["tau"],
            "green": base["green"],
            "green_frac": base["green_frac"],
            "expected_green_frac": wm.gamma_eff,
            "unique_m": uniq["m"],
            "unique_z": uniq["z"],
            "unique_tau": uniq["tau"],
            "unique_watermarked": bool(uniq["watermarked"]),
        }

    def annotate(self, wm, tokens):
        # 1.0 = token z listy zielonej, 0.0 = z czerwonej
        return [1.0 if wm.green_mask[int(t)] else 0.0 for t in tokens]

    def wrong_key_params(self, params):
        p = dict(self.spec.validate(params))
        p["key"] = (p["key"] + 1) % (2**63 - 1)
        return p
