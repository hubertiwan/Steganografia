"""Rejestr algorytmów.

Lista jest budowana z RZECZYWIŚCIE importowalnych pakietów repozytorium. Jeśli któryś pakiet
nie daje się zaimportować (np. brak PyTorch), algorytm trafia na listę niedostępnych wraz
z przyczyną, a GUI ją pokazuje zamiast go ukrywać.
"""
import importlib
import traceback

_ADAPTER_MODULES = [
    ("unigram", "stegolab.algorithms.unigram", "UnigramAdapter", "unigram_watermark"),
    ("synthid", "stegolab.algorithms.synthid", "SynthIDAdapter", "synthid_watermark"),
]

_registry = None
_unavailable = {}


def _load():
    global _registry
    if _registry is not None:
        return
    _registry = {}
    for algo_id, module, cls, package in _ADAPTER_MODULES:
        try:
            adapter = getattr(importlib.import_module(module), cls)()
            _registry[algo_id] = adapter
        except Exception as exc:  # pokazujemy przyczynę w GUI, nie ukrywamy błędu
            _unavailable[algo_id] = (package, f"{type(exc).__name__}: {exc}", traceback.format_exc())


def available():
    """Słownik id → adapter, w kolejności z repozytorium."""
    _load()
    return dict(_registry)


def unavailable():
    """Słownik id → (pakiet, krótki opis błędu, traceback)."""
    _load()
    return dict(_unavailable)


def get(algo_id):
    _load()
    if algo_id not in _registry:
        from ..errors import StegoLabError
        reason = _unavailable.get(algo_id, (None, "nieznany identyfikator", ""))[1]
        raise StegoLabError(f"Algorytm „{algo_id}” jest niedostępny ({reason}).",
                            "Sprawdź instalację zależności (pip install -r requirements-app.txt).")
    return _registry[algo_id]
