"""Adapter SynthID-Text / Tournament sampling (pakiet ``synthid_watermark`` z repozytorium)."""
from math import sqrt

from .base import AlgorithmAdapter, AlgorithmSpec, ParamSpec
from ..paths import ensure_repo_on_path

ensure_repo_on_path()
from synthid_watermark import TournamentWatermark  # noqa: E402  (oryginalna implementacja)
from synthid_watermark import generate as synthid_generate  # noqa: E402

SPEC = AlgorithmSpec(
    id="synthid",
    name="SynthID-Text (Tournament sampling)",
    short="Turniej 2^m kandydatów rozstrzygany pseudolosowymi g-wartościami",
    paper=("Sumanth Dathathri et al. Scalable watermarking for identifying large language model "
           "outputs. Nature 634 (2024)."),
    source_package="synthid_watermark (core.py: TournamentWatermark, generation.py: generate)",
    description=(
        "Znak wodny wprowadzany przez sposób losowania kolejnego tokenu. Z ostatnich H tokenów i klucza "
        "liczony jest skrót (ziarno r_t). Model losuje 2^m kandydatów, którzy rozgrywają m rund turnieju "
        "pucharowego: w rundzie l wygrywa token o większej pseudolosowej g-wartości g_l(x, r_t) ∈ {0, 1}. "
        "Rozkład modelu nie jest zniekształcany w sposób jawny, ale zwycięzcy mają częściej g = 1. "
        "Detektor zna klucz, oblicza g-wartości tekstu i wykonuje test z."),
    principle=[
        "Ziarno: r_t = h(x_{t−H}, …, x_{t−1}, klucz) – skrót blake2b z okna H ostatnich tokenów.",
        "g-wartości: g_l(x, r_t) = najmłodszy bit skrótu (klucz, r_t, token, warstwa l), l = 1…m.",
        "Algorytm 1 (Tournament sampling): 2^m kandydatów i.i.d. z rozkładu modelu (temperatura + top-k), "
        "m rund parami; remis rozstrzyga rzut monetą. Powtórzony kontekst → zwykłe próbkowanie.",
        "Detekcja: bez znaku suma g-wartości ~ Binomial(n·m, ½); z = (Σg − nm/2)/√(nm/4); "
        "tekst oznaczony, gdy z > 2.326 (FPR 1%). Pierwsze H tokenów i powtórzone konteksty są pomijane.",
    ],
    embedding=("Generacja tekstu z próbkowaniem turniejowym (funkcja generate() z "
               "synthid_watermark.generation). Ukrywana informacja to jeden bit: obecność znaku dla klucza K."),
    detection=("Tokenizacja tekstu, obliczenie g-wartości dla każdego nowego kontekstu i test z "
               "(TournamentWatermark.detect). Detektor nie potrzebuje modelu, tylko klucza i tokenizera."),
    inputs=["Polecenie (prompt) dla modelu językowego – tekst lub plik .txt (jedno polecenie w wierszu)",
            "Tajny klucz (dowolny tekst)",
            "Do detekcji: dowolny tekst (wklejony lub z pliku .txt)"],
    formats=["Tekst UTF-8 (.txt) – polecenia i teksty do detekcji",
             "Model językowy Hugging Face (np. Qwen/Qwen2.5-0.5B-Instruct) lub lokalny katalog modelu",
             "Model syntetyczny (wbudowany, do szybkich eksperymentów statystycznych)"],
    limitations=[
        "Znak zerobitowy: nie przenosi wiadomości → BER i pojemność w bitach nie mają zastosowania.",
        "Skuteczność zależy od entropii rozkładu modelu: przy rozkładzie bliskim jednopunktowemu turniej nie zmienia wyboru.",
        "Koszt obliczeniowy rośnie z liczbą kandydatów 2^m (implementacja w czystym Pythonie).",
        "Edycje niszczą okna kontekstu H tokenów – każda zmiana wpływa na ocenę do H+1 tokenów.",
        "Zaimplementowano detektor średniej g-wartości; detektor bayesowski (uczony) i integracja "
        "ze speculative sampling z pracy nie są odtworzone.",
        "Perplexity liczona tym samym modelem, który generował tekst – to tylko zgrubna ocena jakości.",
    ],
    operations=["Generacja tekstu ze znakiem i bez znaku (linia bazowa)",
                "Detekcja testem z sumy g-wartości",
                "Mapa średnich g-wartości tokenów",
                "Test odporności na losowe edycje tokenów",
                "Kontrola z błędnym kluczem"],
    metrics=["z-score i p-value, decyzja z > próg",
             "Średnia g-wartość ocenianych tokenów (oczekiwana 0.5 bez znaku)",
             "Liczba ocenianych tokenów (bez pierwszych H i powtórzonych kontekstów)",
             "TPR / FPR przy progu (z przedziałem Wilsona 95%)",
             "TPR przy empirycznym FPR 1% i 10%, AUC",
             "Perplexity (miara jakości tekstu)",
             "Czas generacji (kodowania) i detekcji (dekodowania), narzut znakowania",
             "Średni z-score po losowych edycjach i odsetek wykryć"],
    not_applicable=["PSNR, MSE, MAE, SSIM – nośnikiem jest tekst, nie obraz",
                    "BER – znak zerobitowy nie przenosi ciągu bitów wiadomości",
                    "Pojemność steganograficzna w bitach – algorytm osadza wyłącznie 1 bit (obecność znaku)"],
    params=[
        ParamSpec("key", "Klucz tajny", "str", "secret-watermark-key",
                  "Dowolny niepusty tekst (domyślny z demo_synthid.py)."),
        ParamSpec("context_size", "H – okno kontekstu", "int", 4,
                  "Liczba poprzednich tokenów użytych do ziarna r_t (w pracy H = 4).",
                  minimum=1, maximum=16, step=1),
        ParamSpec("num_layers", "m – liczba rund turnieju", "int", 8,
                  "Turniej ma 2^m kandydatów (w pracy m = 8, 256 kandydatów). Limit 10 ze względu na czas.",
                  minimum=1, maximum=10, step=1),
        ParamSpec("threshold", "Próg detekcji (z)", "float", 2.326,
                  "Próg z-score; 2.326 odpowiada jednostronnemu FPR = 1%.",
                  minimum=0.0, maximum=50.0, step=0.1, group="detection"),
        ParamSpec("temperature", "Temperatura", "float", 0.7,
                  "Temperatura rozkładu modelu przed turniejem (domyślnie 0.7).",
                  minimum=0.0, maximum=5.0, step=0.1, group="sampling", exclusive_min=True),
        ParamSpec("top_k", "top-k", "int", 100,
                  "Liczba najbardziej prawdopodobnych tokenów, z których losowani są kandydaci.",
                  minimum=1, maximum=100000, step=10, group="sampling"),
    ],
    color="#eb6834",
)


class SynthIDAdapter(AlgorithmAdapter):
    spec = SPEC

    def build(self, params, vocab_size):
        p = self.spec.validate(params)
        return TournamentWatermark(key=p["key"], context_size=p["context_size"], num_layers=p["num_layers"])

    def generate(self, lm, prompt, wm, params, max_new_tokens, seed):
        p = self.spec.validate(params)
        return synthid_generate(lm.model, lm.tokenizer, prompt, wm=wm, max_new_tokens=max_new_tokens,
                                temperature=p["temperature"], top_k=p["top_k"], seed=seed,
                                use_chat_template=lm.use_chat_template)

    def detect(self, wm, tokens, params):
        p = self.spec.validate(params)
        tokens = [int(t) for t in tokens]
        d = wm.detect(tokens, threshold=p["threshold"])
        n = d["n"]
        # Średnia g-wartość wynika wprost z definicji z-score w TournamentWatermark.z_score:
        # z = (Σg − nm/2)/√(nm/4)  ⇒  mean_g = ½ + z/(2√(nm)).
        mean_g = 0.5 + d["z"] / (2 * sqrt(n * wm.num_layers)) if n else None
        return {
            "z": d["z"],
            "p_value": d["p_value"],
            "n_scored": n,
            "watermarked": bool(d["watermarked"]),
            "threshold": p["threshold"],
            "mean_g": mean_g,
            "n_tokens": len(tokens),
        }

    def annotate(self, wm, tokens):
        """Średnia g-wartość tokenu po m warstwach, wg tych samych reguł co z_score()
        (pierwsze H tokenów i powtórzone konteksty → None). Używa wm.seed i wm.g_value."""
        tokens = [int(t) for t in tokens]
        out = [None] * len(tokens)
        seen = set()
        for t in range(wm.context_size, len(tokens)):
            context = tuple(tokens[t - wm.context_size:t])
            if context in seen:
                continue
            seen.add(context)
            seed = wm.seed(context)
            out[t] = sum(wm.g_value(tokens[t], layer, seed) for layer in range(1, wm.num_layers + 1)) / wm.num_layers
        return out

    def wrong_key_params(self, params):
        p = dict(self.spec.validate(params))
        p["key"] = p["key"] + "-inny-klucz"
        return p
