"""Eksport wyników: JSON (pełne dane), CSV (wiersz na tekst + podsumowanie), PDF (raport).

Wnioski w raporcie są generowane regułowo WYŁĄCZNIE z liczb danego eksperymentu
(z jawnie podaną liczebnością próby i przedziałami ufności) – bez interpretacji spoza danych.
"""
import csv
import json
from datetime import datetime
from pathlib import Path

from . import APP_NAME, __version__, charts
from .errors import InputError
from .history import KIND_LABELS, STATUS_LABELS, _clean


# ------------------------------------------------------------------ formatowanie
def fmt(v, digits=3):
    if v is None:
        return "–"
    if isinstance(v, bool):
        return "tak" if v else "nie"
    if isinstance(v, float):
        if digits <= 2:  # średnie, czasy, z-score – stała notacja (p-value zachowują notację naukową)
            return f"{v:.{digits}f}"
        if abs(v) >= 1e4 or (0 < abs(v) < 1e-3):
            return f"{v:.3e}"
        return f"{v:.{digits}f}"
    return str(v)


def fmt_rate(r):
    if not r or r.get("rate") is None:
        return "–"
    return f"{r['rate']:.2f} ({r['k']}/{r['n']}; 95% CI {r['ci_low']:.2f}–{r['ci_high']:.2f})"


def pct(v):
    return "–" if v is None else f"{100 * v:.0f}%"


# ------------------------------------------------------------------ tabele wyników
def test_summary_rows(result):
    """(metryka, wartość) – ta sama tabela w GUI i w raportach."""
    s = result["summary"]
    rows = [
        ("Liczba tekstów (ze znakiem / bez znaku)", f"{s['n_texts']} / {s['n_texts']}"),
        ("Próg detekcji z", fmt(s["threshold"])),
        ("TPR przy progu", fmt_rate(s["tpr"])),
        ("FPR przy progu", fmt_rate(s["fpr"])),
    ]
    if "wrong_key_fpr" in s:
        rows.append(("Wykrycia z błędnym kluczem (teksty ze znakiem)", fmt_rate(s["wrong_key_fpr"])))
    rows.append(("AUC", fmt(s["auc"])))
    for t in s["tpr_at_fpr"]:
        if t:
            note = "" if t["reliable"] else "  (za mało tekstów bez znaku – szacunek orientacyjny)"
            rows.append((f"TPR przy empirycznym FPR {pct(t['fpr'])}",
                         f"{t['tpr']:.2f} (próg z = {t['threshold']:.2f}){note}"))
    rows += [
        ("z-score ze znakiem: średnia ± SD", f"{fmt(s['z_watermarked']['mean'], 2)} ± {fmt(s['z_watermarked']['std'], 2)}"),
        ("z-score bez znaku: średnia ± SD", f"{fmt(s['z_plain']['mean'], 2)} ± {fmt(s['z_plain']['std'], 2)}"),
        ("Mediana p-value (ze znakiem)", fmt(s["p_value_watermarked_median"])),
        ("Średnia liczba wygenerowanych tokenów (ze znakiem)", fmt(s["tokens_watermarked"]["mean"], 1)),
        ("Średnia liczba ocenianych tokenów (ze znakiem)", fmt(s["scored_tokens_watermarked"]["mean"], 1)),
    ]
    if "z_wrong_key" in s:
        rows.append(("z-score z błędnym kluczem: średnia ± SD",
                     f"{fmt(s['z_wrong_key']['mean'], 2)} ± {fmt(s['z_wrong_key']['std'], 2)}"))
    if "green_frac_watermarked" in s:
        rows += [("Odsetek zielonych tokenów: ze znakiem / bez znaku",
                  f"{fmt(s['green_frac_watermarked']['mean'])} / {fmt(s['green_frac_plain']['mean'])} "
                  f"(γ = {result['params']['gamma']})"),
                 ("TPR detektora Unique (Alg. 4)", fmt_rate(s["unique_tpr"])),
                 ("FPR detektora Unique (Alg. 4)", fmt_rate(s["unique_fpr"]))]
    if "mean_g_watermarked" in s:
        rows.append(("Średnia g-wartość: ze znakiem / bez znaku (oczekiwana bez znaku 0.5)",
                     f"{fmt(s['mean_g_watermarked']['mean'])} / {fmt(s['mean_g_plain']['mean'])}"))
    if "perplexity_watermarked" in s:
        rows.append(("Mediana perplexity: ze znakiem / bez znaku",
                     f"{fmt(s['perplexity_watermarked']['median'], 2)} / {fmt(s['perplexity_plain']['median'], 2)}"))
        rows.append(("Stosunek median perplexity (ze znakiem / bez)", fmt(s.get("perplexity_median_ratio"), 3)))
    rows += [
        ("Kodowanie (generacja) – czas na token ze znakiem / bez [ms]",
         f"{fmt(s['gen_time_per_token_ms_watermarked'], 2)} / {fmt(s['gen_time_per_token_ms_plain'], 2)}"),
        ("Narzut czasu generacji (ze znakiem / bez)", fmt(s.get("gen_overhead_ratio"), 2) + "×"),
        ("Dekodowanie (detekcja) – średni czas na tekst [ms]", fmt(s["det_time_ms"]["mean"], 2)),
    ]
    return rows


def edits_rows(result):
    return [(f"{100 * e['fraction']:.0f}%", fmt(e["mean_z"], 2), fmt_rate(e["detected"])) for e in result["edits"]]


def comparison_rows(result):
    """Tabela porównawcza – jedna kolumna na konfigurację."""
    runs = result["runs"]
    header = ["Metryka"] + [r["algorithm_name"] for r in runs]

    def row(label, f):
        return [label] + [f(r) for r in runs]

    s = lambda r: r["summary"]  # noqa: E731
    rows = [
        row("Próg detekcji z", lambda r: fmt(s(r)["threshold"])),
        row("AUC", lambda r: fmt(s(r)["auc"])),
        row("TPR @ empiryczny FPR 10%", lambda r: fmt((s(r)["tpr_at_fpr"][1] or {}).get("tpr"), 2)),
        row("TPR przy progu", lambda r: fmt_rate(s(r)["tpr"])),
        row("FPR przy progu", lambda r: fmt_rate(s(r)["fpr"])),
        row("Średni z ze znakiem / bez", lambda r: f"{fmt(s(r)['z_watermarked']['mean'], 2)} / {fmt(s(r)['z_plain']['mean'], 2)}"),
        row("Perplexity ze znakiem / bez (stosunek median)", lambda r: fmt(s(r).get("perplexity_median_ratio"), 3)),
        row("Narzut czasu generacji", lambda r: fmt(s(r).get("gen_overhead_ratio"), 2) + "×"),
        row("Czas detekcji na tekst [ms]", lambda r: fmt(s(r)["det_time_ms"]["mean"], 2)),
    ]
    fracs = [e["fraction"] for e in runs[0]["edits"]]
    for k, f in enumerate(fracs):
        if f > 0:
            rows.append(row(f"Odsetek wykryć po {100 * f:.0f}% edycji",
                            lambda r, k=k: pct(r["edits"][k]["detected"]["rate"])))
    return header, rows


# ------------------------------------------------------------------ wnioski
def conclusions(result) -> list[str]:
    kind = result.get("kind")
    if kind == "test":
        return _test_conclusions(result)
    if kind == "comparison":
        out = []
        for r in result["runs"]:
            out += [f"{r['algorithm_name']}: {c}" for c in _test_conclusions(r)[:3]]
        aucs = [(r["summary"]["auc"], r["algorithm_name"]) for r in result["runs"] if r["summary"]["auc"] is not None]
        if len(aucs) >= 2:
            aucs.sort(reverse=True)
            if aucs[0][0] == aucs[1][0]:
                out.append(f"AUC obu konfiguracji jest równe ({aucs[0][0]:.3f}) – na tej próbie detekcja nie "
                           "rozróżnia algorytmów; do rozróżnienia potrzebne są trudniejsze warunki (krótsze "
                           "teksty, edycje) lub większa próba.")
            else:
                out.append(f"Najwyższe AUC uzyskał {aucs[0][1]} ({aucs[0][0]:.3f} vs {aucs[1][0]:.3f}).")
        out += result.get("conditions", {}).get("notes", [])[2:]
        return out
    if kind == "demo":
        w, p = result["watermarked"], result["plain"]
        thr = w["detection"]["threshold"]
        return [
            f"Tekst ze znakiem: z = {w['detection']['z']:.2f} przy {w['detection']['n_scored']} ocenianych tokenach "
            f"→ {'wykryty' if w['detection']['watermarked'] else 'NIE wykryty'} (próg {thr:g}).",
            f"Tekst bez znaku: z = {p['detection']['z']:.2f} → {'fałszywy alarm' if p['detection']['watermarked'] else 'poprawnie nie wykryty'}.",
            f"Detekcja tekstu ze znakiem z błędnym kluczem: z = {w['wrong_key_detection']['z']:.2f} → "
            f"{'wykryty (nieoczekiwane)' if w['wrong_key_detection']['watermarked'] else 'nie wykryty (oczekiwane)'}.",
            "To pojedyncza próba – wnioski o skuteczności wymagają trybu testowego na wielu tekstach.",
        ]
    if kind == "detect":
        d = result["detection"]
        return [f"z = {d['z']:.2f}, p = {fmt(d['p_value'])} przy {d['n_scored']} ocenianych tokenach → "
                f"{'znak wykryty' if d['watermarked'] else 'znak nie wykryty'} (próg {d['threshold']:g})."]
    return []


def _test_conclusions(result):
    s = result["summary"]
    n = s["n_texts"]
    out = [f"Przy progu z = {s['threshold']:g} wykryto {s['tpr']['k']} z {n} tekstów ze znakiem "
           f"(TPR {s['tpr']['rate']:.2f}, 95% CI {s['tpr']['ci_low']:.2f}–{s['tpr']['ci_high']:.2f}) i "
           f"{s['fpr']['k']} z {n} tekstów bez znaku (FPR {s['fpr']['rate']:.2f})."]
    if s["auc"] is not None:
        out.append(f"AUC = {s['auc']:.3f}: z-score {'całkowicie' if s['auc'] == 1 else 'częściowo'} rozdziela "
                   "teksty ze znakiem i bez znaku w tej próbie.")
    if "wrong_key_fpr" in s:
        out.append(f"Z błędnym kluczem wykryto {s['wrong_key_fpr']['k']} z {n} tekstów ze znakiem "
                   f"(średni z = {s['z_wrong_key']['mean']:.2f}).")
    if s.get("perplexity_median_ratio"):
        out.append(f"Mediana perplexity tekstów ze znakiem stanowi {s['perplexity_median_ratio']:.2f}× mediany "
                   "dla tekstów bez znaku (ten sam model ocenia własne teksty – miara zgrubna).")
    if s.get("gen_overhead_ratio"):
        out.append(f"Generacja ze znakiem trwała {s['gen_overhead_ratio']:.2f}× dłużej na token niż bez znaku.")
    edits = [e for e in result["edits"] if e["fraction"] > 0 and e["detected"]["rate"] is not None]
    if edits:
        last = edits[-1]
        out.append(f"Po losowej edycji {100 * last['fraction']:.0f}% tokenów odsetek wykryć wyniósł "
                   f"{last['detected']['rate']:.2f} (średni z = {last['mean_z']:.2f}).")
    if n < 30:
        out.append(f"Próba liczy {n} par tekstów – przedziały ufności są szerokie; do pracy zaleca się ≥ 50 poleceń.")
    if result["model"].get("kind") == "synthetic":
        out.append("Wyniki uzyskano na modelu syntetycznym (rozkład testowy, nie język naturalny) – "
                   "nie należy ich przenosić wprost na rzeczywiste modele językowe.")
    return out


# ------------------------------------------------------------------ JSON / CSV
def export_json(record: dict, path):
    path = Path(path)
    payload = {"exported_by": f"{APP_NAME} {__version__}",
               "exported": datetime.now().isoformat(timespec="seconds"), "experiment": record}
    path.write_text(json.dumps(_clean(payload), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _test_csv_rows(result, prefix=None):
    rows = []
    for smp in result["samples"]:
        for role in ("watermarked", "plain"):
            rec = smp[role]
            d = rec["detection"]
            row = {"algorithm": result["algorithm"], "index": smp["index"], "role": role, "seed": rec["seed"],
                   "prompt": smp["prompt"], "n_generated": rec["n_generated"], "n_scored": d["n_scored"],
                   "z": d["z"], "p_value": d["p_value"], "detected": d["watermarked"], "threshold": d["threshold"],
                   "perplexity": rec.get("perplexity"), "gen_time_s": rec["gen_time_s"], "det_time_s": rec["det_time_s"],
                   "green_frac": d.get("green_frac"), "unique_detected": d.get("unique_watermarked"),
                   "mean_g": d.get("mean_g"),
                   "wrong_key_z": (rec.get("wrong_key_detection") or {}).get("z"),
                   "text": rec["text"]}
            rows.append(row)
    return rows


def export_csv(record: dict, path):
    """Wiersz na każdy wygenerowany tekst; dla demo/detekcji – tabela metryk."""
    path = Path(path)
    result = record.get("result")
    if not result:
        raise InputError("Eksperyment nie ma wyników do eksportu.", f"Status: {record.get('status')}.")
    if result["kind"] == "test":
        rows = _test_csv_rows(result)
    elif result["kind"] == "comparison":
        rows = [r for run in result["runs"] for r in _test_csv_rows(run)]
    elif result["kind"] == "demo":
        rows = []
        for role in ("watermarked", "plain"):
            g = result[role]
            rows.append({"algorithm": result["algorithm"], "role": role, "n_generated": g["n_generated"],
                         "n_scored": g["detection"]["n_scored"], "z": g["detection"]["z"],
                         "p_value": g["detection"]["p_value"], "detected": g["detection"]["watermarked"],
                         "wrong_key_z": g["wrong_key_detection"]["z"], "perplexity": g.get("perplexity"),
                         "gen_time_s": g["gen_time_s"], "det_time_s": g["det_time_s"], "text": g["text"]})
    else:
        d = result["detection"]
        rows = [{"algorithm": result["algorithm"], "n_tokens": len(result["tokens"]), **{
            k: v for k, v in d.items()}, "det_time_s": result["det_time_s"], "text": result["text"]}]
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="", encoding="utf-8-sig") as f:  # BOM → Excel poprawnie czyta polskie znaki
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if v is None else v) for k, v in _clean(r).items()})
    if result["kind"] in ("test", "comparison"):  # podsumowanie w osobnym pliku obok
        summary_path = path.with_name(path.stem + "_podsumowanie.csv")
        with open(summary_path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            if result["kind"] == "test":
                w.writerow(["metryka", "wartość"])
                w.writerows(test_summary_rows(result))
                w.writerow([])
                w.writerow(["edycje", "średni z", "odsetek wykryć"])
                w.writerows(edits_rows(result))
            else:
                header, rows_ = comparison_rows(result)
                w.writerow(header)
                w.writerows(rows_)
    return path


# ------------------------------------------------------------------ PDF
def _register_fonts():
    """Czcionka z polskimi znakami – DejaVu Sans dostarczana razem z matplotlib."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    import matplotlib
    base = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
    if "DejaVu" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("DejaVu", str(base / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", str(base / "DejaVuSans-Bold.ttf")))
        pdfmetrics.registerFont(TTFont("DejaVuMono", str(base / "DejaVuSansMono.ttf")))
        from reportlab.lib.fonts import addMapping
        addMapping("DejaVu", 0, 0, "DejaVu")
        addMapping("DejaVu", 1, 0, "DejaVu-Bold")


def export_pdf(record: dict, path):
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                        Table, TableStyle)
    except ImportError as exc:
        raise InputError("Brak biblioteki reportlab do tworzenia raportów PDF.",
                         "Zainstaluj zależności: pip install -r requirements-app.txt") from exc
    from xml.sax.saxutils import escape

    result = record.get("result")
    if not result:
        raise InputError("Eksperyment nie ma wyników do raportu.", f"Status: {record.get('status')}.")
    _register_fonts()
    path = Path(path)
    ink, muted, line = colors.HexColor("#0b0b0b"), colors.HexColor("#52514e"), colors.HexColor("#d9d8d3")
    st = {
        "h1": ParagraphStyle("h1", fontName="DejaVu-Bold", fontSize=17, leading=21, textColor=ink, spaceAfter=4),
        "h2": ParagraphStyle("h2", fontName="DejaVu-Bold", fontSize=12, leading=15, textColor=ink,
                             spaceBefore=12, spaceAfter=5),
        "p": ParagraphStyle("p", fontName="DejaVu", fontSize=9, leading=12.5, textColor=ink),
        "small": ParagraphStyle("s", fontName="DejaVu", fontSize=7.8, leading=10, textColor=muted),
        "cell": ParagraphStyle("c", fontName="DejaVu", fontSize=8, leading=10, textColor=ink),
        "cellb": ParagraphStyle("cb", fontName="DejaVu-Bold", fontSize=8, leading=10, textColor=ink),
        "mono": ParagraphStyle("m", fontName="DejaVuMono", fontSize=7.5, leading=9.5, textColor=ink),
    }
    P = lambda t, s="p": Paragraph(escape(str(t)).replace("\n", "<br/>"), st[s])  # noqa: E731

    def table(rows, widths, header=True):
        data = [[P(c, "cellb" if (header and i == 0) or j == 0 else "cell") for j, c in enumerate(r)]
                for i, r in enumerate(rows)]
        t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
        style = [("LINEBELOW", (0, 0), (-1, -1), 0.4, line), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                 ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
        if header:
            style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f1f0ec")))
        t.setStyle(TableStyle(style))
        return t

    def fig(f, width=16.5 * cm):
        png = charts.figure_png(f)
        import io
        w_in, h_in = f.get_size_inches()
        return Image(io.BytesIO(png), width=width, height=width * h_in / w_in)

    story = [P(f"Raport eksperymentu – {KIND_LABELS.get(record['kind'], record['kind'])}", "h1"),
             P(record["title"], "p"),
             P(f"Wygenerowano: {datetime.now():%Y-%m-%d %H:%M} · {APP_NAME} {__version__} · "
               f"identyfikator eksperymentu {record['id']}", "small"), Spacer(1, 8)]

    meta = [["Pole", "Wartość"],
            ["Data wykonania", record["created"].replace("T", " ")],
            ["Status", STATUS_LABELS.get(record["status"], record["status"])],
            ["Czas trwania", f"{record['duration_s']:.1f} s" if record.get("duration_s") else "–"],
            ["Model językowy", _model_text(result.get("model", record.get("model", {})))]]
    if record.get("files"):
        meta.append(["Pliki wejściowe", "\n".join(record["files"])])
    story += [P("Opis eksperymentu", "h2"), P(_description(result)), Spacer(1, 6), table(meta, [4.5 * cm, 12 * cm])]

    def params_block(res):
        from . import algorithms
        spec = algorithms.get(res["algorithm"]).spec
        rows = [["Parametr", "Wartość", "Opis"]]
        rows += [[p.label, fmt(res["params"][p.name]), p.help] for p in spec.params]
        return [P(f"Parametry – {spec.name}", "h2"), P(spec.paper, "small"), Spacer(1, 4),
                table(rows, [4.3 * cm, 3.2 * cm, 9 * cm])]

    def settings_block(s):
        rows = [["Ustawienie", "Wartość"],
                ["Liczba poleceń (par tekstów)", str(len(s["prompts"]))],
                ["Maks. liczba nowych tokenów", str(s["max_new_tokens"])],
                ["Ziarna generacji", f"ze znakiem: {s['base_seed']}+i; bez znaku: {s['base_seed'] + 10000}+i"],
                ["Detekcja na", "tekście po ponownej tokenizacji" if s["detect_on"] == "text" else "tokenach z generacji"],
                ["Edycje (ułamki / ziarno)", f"{', '.join(f'{f:g}' for f in s['edit_fractions'])} / {s['edit_seed']}"],
                ["Perplexity", "liczona" if s["compute_perplexity"] else "pominięta"]]
        return [P("Ustawienia eksperymentu", "h2"), table(rows, [5.5 * cm, 11 * cm])]

    kind = result["kind"]
    if kind == "test":
        story += params_block(result) + settings_block(result["settings"])
        story += [P("Wyniki", "h2"), table([["Metryka", "Wartość"]] + test_summary_rows(result), [7.5 * cm, 9 * cm])]
        story += [P("Odporność na losowe edycje tokenów", "h2"),
                  table([["Edytowane tokeny", "Średni z", "Odsetek wykryć"]] + edits_rows(result),
                        [4 * cm, 3 * cm, 9.5 * cm])]
        story += [PageBreak(), P("Wykresy", "h2")] + [KeepTogether([fig(f), Spacer(1, 6)])
                                                       for _, f in charts.test_figures(result)]
        story += _samples_block(result, P, table, cm)
    elif kind == "comparison":
        c = result["conditions"]
        story += [P("Warunki porównania", "h2"),
                  table([["Warunek", "Wartość"]] + [[k, fmt(v)] for k, v in c["common"].items()], [5.5 * cm, 11 * cm])]
        story += [Spacer(1, 4)] + [P("• " + n, "small") for n in c["notes"]]
        for r in result["runs"]:
            story += params_block(r)
        header, rows = comparison_rows(result)
        w = 16.5 * cm / (len(header) + 1)
        story += [P("Wyniki porównania", "h2"), table([header] + rows, [2 * w] + [w] * (len(header) - 1))]
        story += [PageBreak(), P("Wykresy", "h2")] + [KeepTogether([fig(f), Spacer(1, 6)])
                                                       for _, f in charts.comparison_figures(result)]
    elif kind == "demo":
        story += params_block(result)
        story += [P("Polecenie (prompt)", "h2"), P(result["prompt"])]
        rows = [["", "Ze znakiem", "Bez znaku"]]
        w, pl = result["watermarked"], result["plain"]
        rows += [["z-score", fmt(w["detection"]["z"], 2), fmt(pl["detection"]["z"], 2)],
                 ["p-value", fmt(w["detection"]["p_value"]), fmt(pl["detection"]["p_value"])],
                 ["Decyzja detektora", fmt(w["detection"]["watermarked"]), fmt(pl["detection"]["watermarked"])],
                 ["Ocenione tokeny", fmt(w["detection"]["n_scored"]), fmt(pl["detection"]["n_scored"])],
                 ["z-score z błędnym kluczem", fmt(w["wrong_key_detection"]["z"], 2), fmt(pl["wrong_key_detection"]["z"], 2)],
                 ["Perplexity", fmt(w.get("perplexity"), 2), fmt(pl.get("perplexity"), 2)],
                 ["Czas generacji [s]", fmt(w["gen_time_s"], 3), fmt(pl["gen_time_s"], 3)],
                 ["Czas detekcji [ms]", fmt(1000 * w["det_time_s"], 2), fmt(1000 * pl["det_time_s"], 2)]]
        story += [P("Wyniki", "h2"), table(rows, [5.5 * cm, 5.5 * cm, 5.5 * cm]), Spacer(1, 6),
                  fig(charts.demo_chart(result))]
        story += [P("Tekst ze znakiem", "h2"), P(w["text"], "mono"), P("Tekst bez znaku", "h2"), P(pl["text"], "mono")]
    else:
        story += params_block(result)
        d = result["detection"]
        story += [P("Wynik detekcji", "h2"),
                  table([["Metryka", "Wartość"]] + [[k, fmt(v)] for k, v in d.items()], [6 * cm, 10.5 * cm]),
                  P("Analizowany tekst", "h2"), P(result["text"][:6000], "mono")]

    story += [P("Wnioski (wyłącznie na podstawie uzyskanych danych)", "h2")]
    story += [P("• " + c) for c in conclusions(result)]

    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=2.2 * cm, rightMargin=2.2 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm, title=record["title"],
                            author=APP_NAME, subject="Raport eksperymentu znakowania wodnego tekstu")

    def footer(canvas, _doc):
        canvas.saveState()
        canvas.setFont("DejaVu", 7.5)
        canvas.setFillColor(muted)
        canvas.drawString(2.2 * cm, 1.2 * cm, f"{APP_NAME} · {record['title'][:90]}")
        canvas.drawRightString(A4[0] - 2.2 * cm, 1.2 * cm, f"strona {canvas.getPageNumber()}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return path


def _samples_block(result, P, table, cm, limit=12):
    rows = [["#", "Polecenie", "z (ze znakiem)", "z (bez znaku)", "Wykryto (ze / bez)"]]
    for smp in result["samples"][:limit]:
        w, p = smp["watermarked"]["detection"], smp["plain"]["detection"]
        rows.append([str(smp["index"] + 1), smp["prompt"][:70], fmt(w["z"], 2), fmt(p["z"], 2),
                     f"{fmt(w['watermarked'])} / {fmt(p['watermarked'])}"])
    out = [P("Wyniki dla poszczególnych tekstów", "h2"),
           table(rows, [0.8 * cm, 7.2 * cm, 2.6 * cm, 2.6 * cm, 3.3 * cm])]
    if len(result["samples"]) > limit:
        out.append(P(f"Pokazano {limit} z {len(result['samples'])} tekstów – pełne dane w eksporcie CSV/JSON.", "small"))
    first = result["samples"][0]
    out += [P("Przykładowy tekst ze znakiem (polecenie 1)", "h2"), P(first["watermarked"]["text"][:2500], "mono")]
    return out


def _model_text(m):
    if not m:
        return "–"
    if m.get("kind") == "synthetic":
        return (f"Model syntetyczny (rozkład testowy, nie język naturalny): |V| = {m['vocab_size']}, "
                f"rozrzut logitów s = {m.get('spread')}, kontekst modelu = {m.get('model_context')}, "
                f"ziarno = {m.get('model_seed')}")
    return f"{m.get('name')} · |V| = {m.get('vocab_size')} · urządzenie {m.get('device')} · " \
           f"szablon czatu: {'tak' if m.get('use_chat_template') else 'nie'}"


def _description(result):
    kind = result["kind"]
    if kind == "test":
        s = result["settings"]
        return (f"Test algorytmu {result['algorithm_name']}: dla {len(s['prompts'])} poleceń wygenerowano tekst ze "
                f"znakiem wodnym i tekst bez znaku (linia bazowa) tym samym sposobem próbkowania, a następnie "
                f"przeprowadzono detekcję kluczem właściwym i błędnym, pomiar perplexity, czasu generacji i "
                f"detekcji oraz test odporności na losowe edycje tokenów (metodologia jak w demo.py i demo_synthid.py "
                f"z repozytorium).")
    if kind == "comparison":
        names = ", ".join(r["algorithm_name"] for r in result["runs"])
        return (f"Porównanie algorytmów: {names}. Każdy algorytm przetestowano na tych samych poleceniach, "
                f"z tym samym modelem, ziarnami i długością tekstu.")
    if kind == "demo":
        return (f"Demonstracja algorytmu {result['algorithm_name']} dla jednego polecenia: tekst ze znakiem, tekst "
                f"bez znaku i detekcja (również z błędnym kluczem).")
    return f"Detekcja znaku algorytmu {result['algorithm_name']} w tekście podanym przez użytkownika."
