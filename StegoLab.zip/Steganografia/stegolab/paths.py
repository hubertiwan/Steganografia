"""Lokalizacje plików aplikacji.

Domyślnie dane (historia, dokumenty PDF) trafiają do katalogu ``stegolab_data`` obok
repozytorium, żeby całość dało się przenieść na inny komputer np. przed prezentacją.
Zmienna środowiskowa STEGOLAB_DATA pozwala wskazać inny katalog (używają jej testy).
"""
import os
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def ensure_repo_on_path():
    """Oryginalne pakiety (unigram_watermark, synthid_watermark, demo*.py) leżą w katalogu
    głównym repozytorium – muszą być importowalne niezależnie od katalogu roboczego."""
    root = str(REPO_ROOT)
    if root not in sys.path:
        sys.path.insert(0, root)


def data_dir() -> Path:
    path = Path(os.environ.get("STEGOLAB_DATA", REPO_ROOT / "stegolab_data"))
    path.mkdir(parents=True, exist_ok=True)
    return path


def experiments_dir() -> Path:
    path = data_dir() / "experiments"
    path.mkdir(parents=True, exist_ok=True)
    return path


def documents_dir() -> Path:
    path = data_dir() / "documents"
    path.mkdir(parents=True, exist_ok=True)
    return path
