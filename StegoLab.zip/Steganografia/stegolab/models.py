"""Backend modeli językowych.

Oba algorytmy z repozytorium osadzają znak PODCZAS GENERACJI tekstu przez model językowy,
więc każdy eksperyment wymaga modelu. Dostępne są dwa rodzaje:

1. Model Hugging Face (zalecany do wyników do pracy) – ładowany funkcją ``load_model``
   z oryginalnego ``demo.py`` (te same ustawienia: GPU/fp16 lub CPU/fp32).

2. Model syntetyczny – mały ``torch.nn.Module`` z interfejsem zgodnym z HF (forward z
   past_key_values, logits, loss), dzięki czemu działa z ORYGINALNYMI funkcjami generate()
   obu pakietów bez żadnych zmian. Rozkład następnego tokenu to softmax(s·N(0, 1)), gdzie
   szum jest deterministyczny względem ostatnich k tokenów – podobnie jak w testach
   repozytorium (tests/test_core.py używa rng.normal(size=V)*3). Tekst składa się z
   pseudosłów (jedno pseudosłowo = jeden token), więc nie ma sensu językowego. Model służy
   do szybkich, powtarzalnych eksperymentów statystycznych bez pobierania sieci neuronowej
   i jest wyraźnie oznaczany w wynikach.
"""
import hashlib
import math
from dataclasses import dataclass, field
from types import SimpleNamespace

import numpy as np

from .errors import ModelError
from .paths import ensure_repo_on_path

ensure_repo_on_path()

DEFAULT_HF_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"  # domyślny model z demo.py / demo_synthid.py


@dataclass
class LanguageModel:
    kind: str                    # "hf" | "synthetic"
    name: str
    model: object
    tokenizer: object
    vocab_size: int
    device: str
    use_chat_template: bool
    settings: dict = field(default_factory=dict)

    def describe(self) -> dict:
        """Opis modelu zapisywany w historii i raportach."""
        return {"kind": self.kind, "name": self.name, "vocab_size": self.vocab_size,
                "device": self.device, "use_chat_template": self.use_chat_template, **self.settings}

    @property
    def label(self) -> str:
        if self.kind == "synthetic":
            return f"Model syntetyczny (|V| = {self.vocab_size}, s = {self.settings.get('spread')})"
        return f"{self.name} ({self.device})"

    def tokenize(self, text: str) -> list[int]:
        """Tokenizacja tekstu do detekcji – tak jak w demo_synthid.text_z_score()."""
        return list(self.tokenizer(text, add_special_tokens=False).input_ids)


# ------------------------------------------------------------------ Hugging Face
def load_hf_model(name: str, use_chat_template: bool = True) -> LanguageModel:
    name = (name or "").strip()
    if not name:
        raise ModelError("Nie podano nazwy modelu.", f"Wpisz np. {DEFAULT_HF_MODEL} albo ścieżkę do lokalnego katalogu modelu.")
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
    except ImportError as exc:
        raise ModelError(f"Brak biblioteki: {exc.name}.",
                         "Zainstaluj zależności: pip install -r requirements-app.txt") from exc
    from demo import load_model  # funkcja z oryginalnego repozytorium

    try:
        model, tokenizer, device = load_model(name)
    except OSError as exc:
        raise ModelError(
            f"Nie udało się wczytać modelu „{name}”.",
            "Sprawdź nazwę modelu i połączenie z internetem (pierwsze uruchomienie pobiera model z "
            "huggingface.co) albo wskaż lokalny katalog z modelem.\nSzczegóły: " + str(exc).splitlines()[0]) from exc
    except Exception as exc:
        raise ModelError(f"Błąd podczas ładowania modelu „{name}”: {type(exc).__name__}: {exc}",
                         "Spróbuj mniejszego modelu lub sprawdź ilość wolnej pamięci RAM/VRAM.") from exc
    vocab = int(model.get_output_embeddings().weight.shape[0])  # jak w demo.py
    has_template = bool(getattr(tokenizer, "chat_template", None))
    return LanguageModel("hf", name, model, tokenizer, vocab, str(device),
                         use_chat_template and has_template,
                         {"chat_template_available": has_template})


# ------------------------------------------------------------------ model syntetyczny
_SYLLABLES = [c + v for c in "bdfgklmnprstwz" for v in "aeiou"]  # 70 sylab
_SYL_INDEX = {s: i for i, s in enumerate(_SYLLABLES)}


class SyntheticTokenizer:
    """Tokenizer odwracalny dla pseudosłów: id ↔ ciąg sylab zapisany w systemie o podstawie 70.
    Słowa spoza tego alfabetu (np. polecenie wpisane przez użytkownika) są mapowane skrótem."""

    chat_template = None
    eos_token_id = None  # model syntetyczny nie kończy tekstu wcześniej

    def __init__(self, vocab_size: int):
        self.vocab_size = vocab_size
        self.width = max(2, math.ceil(math.log(vocab_size, len(_SYLLABLES))))

    def id_to_word(self, i: int) -> str:
        """Zapis id w systemie o podstawie 70, najmłodsza „cyfra” (sylaba) pierwsza, bez końcowych
        zer, min. 2 sylaby. Słowa rozdziela spacja, więc różna długość nie psuje odwracalności."""
        digits = []
        i = int(i)
        while i or len(digits) < 2:
            i, r = divmod(i, len(_SYLLABLES))
            digits.append(_SYLLABLES[r])
        return "".join(digits)

    def word_to_id(self, word: str) -> int:
        w = word.lower()
        if 4 <= len(w) <= 2 * self.width and len(w) % 2 == 0 and all(w[k:k + 2] in _SYL_INDEX
                                                                   for k in range(0, len(w), 2)):
            value = 0
            for k in reversed(range(0, len(w), 2)):
                value = value * len(_SYLLABLES) + _SYL_INDEX[w[k:k + 2]]
            if value < self.vocab_size:
                return value
        digest = hashlib.blake2b(w.encode("utf-8"), digest_size=8).digest()
        return int.from_bytes(digest, "little") % self.vocab_size

    def encode(self, text: str) -> list[int]:
        return [self.word_to_id(w) for w in text.split()]

    def decode(self, ids, skip_special_tokens=True):
        return " ".join(self.id_to_word(i) for i in ids)

    def __call__(self, text, return_tensors=None, add_special_tokens=True):
        ids = self.encode(text)
        if return_tensors == "pt":
            import torch
            ids = ids or [0]  # model potrzebuje co najmniej jednego tokenu wejścia
            return SimpleNamespace(input_ids=torch.tensor([ids], dtype=torch.long))
        return SimpleNamespace(input_ids=ids)

    def __len__(self):
        return self.vocab_size


def _make_synthetic_module(vocab_size, spread, context_size, seed):
    import torch

    class SyntheticLanguageModel(torch.nn.Module):
        """Logity następnego tokenu = spread · N(0, 1), deterministyczne względem
        (ziarno modelu, ostatnie context_size tokenów)."""

        def __init__(self):
            super().__init__()
            # parametr-atrapa: generate() z repozytorium pobiera urządzenie z next(model.parameters())
            self._anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
            self.vocab_size = vocab_size
            self.spread = float(spread)
            self.context_size = int(context_size)
            self.model_seed = int(seed)

        @property
        def device(self):
            return self._anchor.device

        def context_logits(self, context):
            data = ",".join(str(int(t)) for t in context[-self.context_size:])
            h = hashlib.blake2b(f"{self.model_seed}|{data}".encode(), digest_size=8).digest()
            rng = np.random.default_rng(int.from_bytes(h, "little"))
            return rng.standard_normal(self.vocab_size) * self.spread

        def forward(self, input_ids=None, past_key_values=None, use_cache=True, labels=None, **_):
            history = list(past_key_values or [])
            rows = []
            for tok in input_ids[0].tolist():
                history.append(int(tok))
                rows.append(self.context_logits(history))
            logits = torch.tensor(np.stack(rows), dtype=torch.float32)[None]
            loss = None
            if labels is not None:  # jak w HF: token t przewidywany z logitów pozycji t-1
                shift_logits = logits[:, :-1, :].reshape(-1, self.vocab_size)
                shift_labels = labels[:, 1:].reshape(-1).to(torch.long)
                loss = torch.nn.functional.cross_entropy(shift_logits, shift_labels, ignore_index=-100)
            return SimpleNamespace(logits=logits, past_key_values=history, loss=loss)

        def get_output_embeddings(self):
            return SimpleNamespace(weight=SimpleNamespace(shape=(self.vocab_size, 1)))

    return SyntheticLanguageModel().eval()


def make_synthetic_model(vocab_size: int = 5000, spread: float = 3.0, context_size: int = 2,
                         seed: int = 0) -> LanguageModel:
    if not 100 <= int(vocab_size) <= 100_000:
        raise ModelError(f"Rozmiar słownika {vocab_size} poza zakresem.", "Podaj wartość od 100 do 100 000.")
    if not 0 < float(spread) <= 20:
        raise ModelError(f"Rozrzut logitów {spread} poza zakresem.", "Podaj wartość z przedziału (0, 20].")
    if not 1 <= int(context_size) <= 8:
        raise ModelError(f"Kontekst modelu {context_size} poza zakresem.", "Podaj wartość od 1 do 8.")
    try:
        module = _make_synthetic_module(int(vocab_size), float(spread), int(context_size), int(seed))
    except ImportError as exc:
        raise ModelError("Brak biblioteki PyTorch wymaganej przez funkcje generate() z repozytorium.",
                         "Zainstaluj zależności: pip install -r requirements-app.txt") from exc
    return LanguageModel("synthetic", "synthetic", module, SyntheticTokenizer(int(vocab_size)),
                         int(vocab_size), "cpu", False,
                         {"spread": float(spread), "model_context": int(context_size), "model_seed": int(seed)})


def synthetic_entropy_estimate(lm: LanguageModel, samples: int = 200) -> float:
    """Średnia entropia (w natach) rozkładu następnego tokenu modelu syntetycznego –
    pomaga zinterpretować siłę detekcji (niska entropia → słabszy znak)."""
    rng = np.random.default_rng(0)
    ent = []
    for _ in range(samples):
        logits = lm.model.context_logits(list(rng.integers(lm.vocab_size, size=lm.model.context_size)))
        p = np.exp(logits - logits.max())
        p /= p.sum()
        ent.append(float(-(p[p > 0] * np.log(p[p > 0])).sum()))
    return float(np.mean(ent))
