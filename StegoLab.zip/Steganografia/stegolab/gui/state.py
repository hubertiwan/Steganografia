"""Stan aplikacji współdzielony przez strony: bieżący model, zadanie w tle, odświeżanie list.

W danej chwili działa najwyżej jedno zadanie obliczeniowe – ten sam model nie jest używany
równolegle z dwóch wątków, a przyciski „Uruchom” na wszystkich stronach są wyłączane.
"""
from PySide6.QtCore import QObject, Signal

from .. import history, models
from .workers import Job


class AppState(QObject):
    model_changed = Signal(object)
    busy_changed = Signal(bool)
    history_changed = Signal()
    documents_changed = Signal()
    navigate = Signal(str, object)   # (strona, argument), np. ("demo", "unigram")

    def __init__(self):
        super().__init__()
        self.model = None
        self.job = None

    def set_model(self, lm):
        self.model = lm
        self.model_changed.emit(lm)

    def load_default_model(self):
        """Na starcie: model syntetyczny (natychmiastowy, bez pobierania). Model Hugging Face
        użytkownik wczytuje świadomie – pierwsze pobranie Qwen2.5-0.5B to ~1 GB."""
        self.set_model(models.make_synthetic_model())

    @property
    def busy(self):
        return self.job is not None

    def start_job(self, name, fn):
        """Zwraca Job albo None, gdy inne zadanie wciąż trwa."""
        if self.job is not None:
            return None
        job = Job(name, fn, self)
        self.job = job
        job.finished.connect(self._job_finished)
        self.busy_changed.emit(True)
        job.start()
        return job

    def _job_finished(self):
        self.job = None
        self.busy_changed.emit(False)

    def cancel_job(self):
        if self.job is not None:
            self.job.cancel()

    def save_record(self, record):
        history.save(record)
        self.history_changed.emit()
