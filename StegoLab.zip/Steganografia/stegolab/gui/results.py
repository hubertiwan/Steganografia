"""Widoki wyników – te same dla stron eksperymentów i dla historii (ponowne wyświetlenie)."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QFileDialog, QGridLayout, QHBoxLayout, QHeaderView,
                               QLabel, QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QTableWidget,
                               QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from .. import charts, reports
from ..reports import fmt
from .widgets import (Banner, Card, ChartView, clear_layout, MetricTable, Pill, TokenView, label, show_error, token_legend)


def _scroll(widget):
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setWidget(widget)
    return sa


def test_verdict(summary):
    """Komunikat o wyniku testu round-trip (osadzenie → detekcja)."""
    tpr, fpr = summary["tpr"], summary["fpr"]
    msg = (f"Znak wykryty w {tpr['k']}/{tpr['n']} tekstach ze znakiem, fałszywe alarmy w "
           f"{fpr['k']}/{fpr['n']} tekstach bez znaku")
    wk = summary.get("wrong_key_fpr")
    if wk:
        msg += f", wykrycia z błędnym kluczem: {wk['k']}/{wk['n']}"
    if tpr["k"] == tpr["n"] and fpr["k"] == 0 and (not wk or wk["k"] == 0):
        return "ok", "✓ Test zakończony powodzeniem. " + msg + "."
    if tpr["rate"] >= 0.5 and fpr["rate"] <= 0.1:
        return "warn", "⚠ Detekcja częściowo skuteczna. " + msg + ". Zobacz rozkład z-score i wpływ długości tekstu."
    return "error", "✗ Detekcja nieskuteczna w tych warunkach. " + msg + "."


# ------------------------------------------------------------------ test
class TestResultView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.banner = Banner()
        lay.addWidget(self.banner)
        self.tiles = QHBoxLayout()
        lay.addLayout(self.tiles)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        # podsumowanie
        summary = QWidget()
        sl = QHBoxLayout(summary)
        self.table = MetricTable()
        sl.addWidget(self.table, 3)
        right = QVBoxLayout()
        right.addWidget(label("Odporność na losowe edycje tokenów", "H3"))
        self.edits = MetricTable(("Edycje", "Średni z", "Odsetek wykryć (95% CI)"))
        right.addWidget(self.edits, 1)
        right.addWidget(label("Wnioski z danych", "H3"))
        self.conclusions = QLabel()
        self.conclusions.setWordWrap(True)
        self.conclusions.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.conclusions.setAlignment(Qt.AlignTop)
        right.addWidget(_scroll(self.conclusions), 1)
        sl.addLayout(right, 2)
        self.tabs.addTab(summary, "Podsumowanie")

        # wykresy
        charts_w = QWidget()
        cg = QGridLayout(charts_w)
        self.chart_views = [ChartView(min_height=280) for _ in range(3)]
        cg.addWidget(self.chart_views[0], 0, 0)
        cg.addWidget(self.chart_views[1], 0, 1)
        cg.addWidget(self.chart_views[2], 1, 0)
        self.tabs.addTab(_scroll(charts_w), "Wykresy")

        # teksty
        texts = QSplitter(Qt.Vertical)
        self.samples = QTableWidget(0, 7)
        self.samples.setHorizontalHeaderLabels(["#", "Polecenie", "z ze znakiem", "Wykryto", "z bez znaku",
                                                "Fałszywy alarm", "Perplexity (ze / bez)"])
        self.samples.verticalHeader().setVisible(False)
        self.samples.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.samples.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.samples.setSelectionMode(QAbstractItemView.SingleSelection)
        self.samples.setAlternatingRowColors(True)
        self.samples.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.samples.itemSelectionChanged.connect(self._show_sample)
        texts.addWidget(self.samples)
        pair = QWidget()
        pl = QHBoxLayout(pair)
        pl.setContentsMargins(0, 6, 0, 0)
        self.text_wm = QPlainTextEdit(readOnly=True)
        self.text_pl = QPlainTextEdit(readOnly=True)
        for title, w in (("Tekst ze znakiem", self.text_wm), ("Tekst bez znaku", self.text_pl)):
            col = QVBoxLayout()
            col.addWidget(label(title, "H3"))
            col.addWidget(w)
            pl.addLayout(col)
        texts.addWidget(pair)
        self.tabs.addTab(texts, "Teksty")
        self.result = None

    def _tile(self, title, value, note=""):
        c = Card()
        c.body.setSpacing(2)
        c.body.addWidget(label(title, "Small"))
        c.body.addWidget(label(value, "BigNumber"))
        if note:
            c.body.addWidget(label(note, "Small"))
        return c

    def set_result(self, result):
        self.result = result
        s = result["summary"]
        level, text = test_verdict(s)
        if result["model"].get("kind") == "synthetic":
            text += "  Wyniki z modelu syntetycznego (rozkład testowy, nie język naturalny)."
        self.banner.set(level, text)
        clear_layout(self.tiles)
        self.tiles.addWidget(self._tile("TPR przy progu", fmt(s["tpr"]["rate"], 2),
                                        f"95% CI {fmt(s['tpr']['ci_low'], 2)}–{fmt(s['tpr']['ci_high'], 2)}"))
        self.tiles.addWidget(self._tile("FPR przy progu", fmt(s["fpr"]["rate"], 2),
                                        f"95% CI {fmt(s['fpr']['ci_low'], 2)}–{fmt(s['fpr']['ci_high'], 2)}"))
        self.tiles.addWidget(self._tile("AUC", fmt(s["auc"], 3), f"{s['n_texts']} + {s['n_texts']} tekstów"))
        self.tiles.addWidget(self._tile("Średni z (ze / bez znaku)",
                                        f"{fmt(s['z_watermarked']['mean'], 2)} / {fmt(s['z_plain']['mean'], 2)}",
                                        f"próg z = {fmt(s['threshold'])}"))
        if s.get("gen_overhead_ratio"):
            self.tiles.addWidget(self._tile("Narzut generacji", f"{s['gen_overhead_ratio']:.2f}×",
                                            "czas na token: ze znakiem / bez"))
        self.table.set_rows(reports.test_summary_rows(result))
        self.edits.set_rows(reports.edits_rows(result))
        self.conclusions.setText("\n\n".join("• " + c for c in reports.conclusions(result)))
        for view, (_, fig) in zip(self.chart_views, charts.test_figures(result)):
            view.replace(fig)
        self.samples.setRowCount(len(result["samples"]))
        for r, smp in enumerate(result["samples"]):
            w, p = smp["watermarked"], smp["plain"]
            vals = [str(smp["index"] + 1), smp["prompt"], fmt(w["detection"]["z"], 2),
                    "tak" if w["detection"]["watermarked"] else "NIE", fmt(p["detection"]["z"], 2),
                    "TAK" if p["detection"]["watermarked"] else "nie",
                    f"{fmt(w.get('perplexity'), 2)} / {fmt(p.get('perplexity'), 2)}"]
            for c, v in enumerate(vals):
                self.samples.setItem(r, c, QTableWidgetItem(v))
        self.samples.resizeColumnsToContents()
        self.samples.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        if result["samples"]:
            self.samples.selectRow(0)

    def _show_sample(self):
        rows = self.samples.selectionModel().selectedRows()
        if not rows or not self.result:
            return
        smp = self.result["samples"][rows[0].row()]
        self.text_wm.setPlainText(smp["watermarked"]["text"])
        self.text_pl.setPlainText(smp["plain"]["text"])


# ------------------------------------------------------------------ porównanie
class ComparisonResultView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs)
        top = QWidget()
        tl = QVBoxLayout(top)
        tl.addWidget(label("Warunki eksperymentu", "H3"))
        self.conditions = MetricTable(("Warunek", "Wartość"))
        self.conditions.setMaximumHeight(240)
        tl.addWidget(self.conditions)
        self.notes = Banner(level="info")
        tl.addWidget(self.notes)
        tl.addWidget(label("Wyniki", "H3"))
        self.table = MetricTable(("Metryka",))
        tl.addWidget(self.table, 1)
        tl.addWidget(label("Wnioski z danych", "H3"))
        self.conclusions = label("", selectable=True)
        tl.addWidget(self.conclusions)
        self.tabs.addTab(_scroll(top), "Tabela i warunki")
        charts_w = QWidget()
        cg = QGridLayout(charts_w)
        self.chart_views = [ChartView(min_height=300) for _ in range(3)]
        cg.addWidget(self.chart_views[0], 0, 0)
        cg.addWidget(self.chart_views[1], 0, 1)
        cg.addWidget(self.chart_views[2], 1, 0)
        self.tabs.addTab(_scroll(charts_w), "Wykresy")
        self.detail_tabs = QTabWidget()
        self.tabs.addTab(self.detail_tabs, "Szczegóły algorytmów")

    def set_result(self, result):
        c = result["conditions"]
        rows = [(k, fmt(v)) for k, v in c["common"].items()]
        for pr in c["per_run"]:
            samp = ", ".join(f"{k} = {fmt(v)}" for k, v in pr["sampling"].items())
            rows.append((f"{pr['algorithm']} – próbkowanie / próg", f"{samp}; próg z = {fmt(pr['threshold'])}"))
        self.conditions.set_rows(rows)
        self.notes.set("info", "\n".join("• " + n for n in c["notes"]))
        header, rows = reports.comparison_rows(result)
        self.table.setColumnCount(len(header))
        self.table.setHorizontalHeaderLabels(header)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for col in range(1, len(header)):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.Stretch)
        self.table.set_rows(rows)
        self.table.setMinimumHeight(min(80 + 34 * len(rows), 520))
        self.conclusions.setText("\n".join("• " + x for x in reports.conclusions(result)))
        for view, (_, fig) in zip(self.chart_views, charts.comparison_figures(result)):
            view.replace(fig)
        self.detail_tabs.clear()
        for run in result["runs"]:
            v = TestResultView()
            v.set_result(run)
            self.detail_tabs.addTab(v, run["algorithm_name"])


# ------------------------------------------------------------------ demo
class GenerationPanel(QWidget):
    """Jeden tekst w demo: kolorowane tokeny + wynik detekcji."""

    def __init__(self, title, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        head = QHBoxLayout()
        head.addWidget(label(title, "H3"))
        head.addStretch(1)
        self.pill = Pill("–")
        head.addWidget(self.pill)
        lay.addLayout(head)
        self.view = TokenView()
        lay.addWidget(self.view, 1)
        self.stats = label("", "Small", selectable=True)
        lay.addWidget(self.stats)

    def display(self, gen, algo_id):
        d = gen["detection"]
        self.view.show_tokens(gen["pieces"], gen["annotation"], algo_id, gen["text"])
        self.pill.set("ok" if d["watermarked"] else "neutral",
                      "znak wykryty" if d["watermarked"] else "znak nie wykryty")
        extra = ""
        if "green_frac" in d:
            extra = f" · zielone: {d['green']}/{d['n_scored']} ({d['green_frac']:.0%}, oczekiwane bez znaku {d['expected_green_frac']:.0%}) · Alg. 4: z = {d['unique_z']:.2f}, próg {d['unique_tau']:.2f} → {'wykryty' if d['unique_watermarked'] else 'nie'}"
        if d.get("mean_g") is not None:
            extra = f" · średnia g = {d['mean_g']:.3f} (bez znaku ≈ 0.5)"
        ppl = f" · perplexity = {gen['perplexity']:.2f}" if gen.get("perplexity") else ""
        timing = ""
        if "gen_time_s" in gen:
            timing = f" · generacja {gen['gen_time_s']:.2f} s ({gen['n_generated']} tok.), detekcja {1000 * gen['det_time_s']:.1f} ms"
        self.stats.setText(f"z = {d['z']:.2f} (próg {d['threshold']:g}) · p = {fmt(d['p_value'])} · "
                           f"ocenione tokeny: {d['n_scored']}{extra}{ppl}{timing}")


class DemoResultView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.banner = Banner()
        lay.addWidget(self.banner)
        bar = QHBoxLayout()
        self.legend_holder = QHBoxLayout()
        bar.addLayout(self.legend_holder)
        bar.addStretch(1)
        self.color_toggle = QCheckBox("Koloruj tokeny")
        self.color_toggle.setChecked(True)
        bar.addWidget(self.color_toggle)
        lay.addLayout(bar)
        split = QSplitter(Qt.Horizontal)
        self.wm = GenerationPanel("Tekst ze znakiem wodnym")
        self.plain = GenerationPanel("Tekst bez znaku")
        split.addWidget(self.wm)
        split.addWidget(self.plain)
        lay.addWidget(split, 3)
        self.chart = ChartView(min_height=200)
        lay.addWidget(self.chart, 2)
        self.color_toggle.toggled.connect(lambda on: (self.wm.view.set_colored(on), self.plain.view.set_colored(on)))

    def set_result(self, result):
        algo = result["algorithm"]
        clear_layout(self.legend_holder)
        self.legend_holder.addWidget(token_legend(algo))
        self.wm.display(result["watermarked"], algo)
        self.plain.display(result["plain"], algo)
        concl = reports.conclusions(result)
        ok = (result["watermarked"]["detection"]["watermarked"] and not result["plain"]["detection"]["watermarked"]
              and not result["watermarked"]["wrong_key_detection"]["watermarked"])
        self.banner.set("ok" if ok else "warn", "  ".join(concl[:3]))
        self.chart.replace(charts.demo_chart(result))


class DetectResultView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.banner = Banner()
        lay.addWidget(self.banner)
        self.legend_holder = QHBoxLayout()
        lay.addLayout(self.legend_holder)
        self.view = TokenView()
        lay.addWidget(self.view, 1)
        self.table = MetricTable()
        self.table.setMaximumHeight(260)
        lay.addWidget(self.table)

    def set_result(self, result):
        d = result["detection"]
        clear_layout(self.legend_holder)
        self.legend_holder.addWidget(token_legend(result["algorithm"]))
        self.banner.set("ok" if d["watermarked"] else "info", reports.conclusions(result)[0])
        self.view.show_tokens(result["pieces"], result["annotation"], result["algorithm"], result["text"])
        names = {"z": "z-score", "p_value": "p-value", "n_scored": "Ocenione tokeny", "watermarked": "Znak wykryty",
                 "threshold": "Próg z", "green": "Zielone tokeny", "green_frac": "Odsetek zielonych",
                 "expected_green_frac": "Oczekiwany odsetek zielonych bez znaku (γ)", "unique_m": "Alg. 4: unikalne tokeny",
                 "unique_z": "Alg. 4: z-score", "unique_tau": "Alg. 4: próg", "unique_watermarked": "Alg. 4: znak wykryty",
                 "mean_g": "Średnia g-wartość", "n_tokens": "Tokeny w tekście"}
        rows = [(names.get(k, k), fmt(v)) for k, v in d.items()]
        rows.append(("Czas detekcji [ms]", fmt(1000 * result["det_time_s"], 2)))
        self.table.set_rows(rows)


def view_for(result):
    view = {"test": TestResultView, "comparison": ComparisonResultView, "demo": DemoResultView,
            "detect": DetectResultView}[result["kind"]]()
    view.setMinimumHeight({"test": 720, "comparison": 760, "demo": 620, "detect": 480}[result["kind"]])
    view.set_result(result)
    return view


# ------------------------------------------------------------------ eksport
class ExportBar(QWidget):
    """Przyciski eksportu rekordu historii do JSON / CSV / PDF."""

    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.record = None
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(label("Eksport:", "Small"))
        self.buttons = []
        for fmt_name, ext in (("PDF", "pdf"), ("CSV", "csv"), ("JSON", "json")):
            b = QPushButton(f"{fmt_name}")
            b.setToolTip(f"Zapisz raport eksperymentu jako {fmt_name}")
            b.clicked.connect(lambda _=False, e=ext: self.export(e))
            lay.addWidget(b)
            self.buttons.append(b)
        self.status = label("", "Small")
        lay.addWidget(self.status, 1)
        self.set_record(None)

    def set_record(self, record):
        self.record = record
        ok = bool(record and record.get("result"))
        for b in self.buttons:
            b.setEnabled(ok)
        self.status.setText("")

    def export(self, ext):
        if not self.record:
            return
        default = f"stegolab_{self.record['kind']}_{self.record['id']}.{ext}"
        filters = {"pdf": "Raport PDF (*.pdf)", "csv": "CSV (*.csv)", "json": "JSON (*.json)"}
        path, _ = QFileDialog.getSaveFileName(self, "Zapisz raport", str(Path.home() / default), filters[ext])
        if not path:
            return
        if not path.lower().endswith("." + ext):
            path += "." + ext
        fn = {"pdf": reports.export_pdf, "csv": reports.export_csv, "json": reports.export_json}[ext]
        record = self.record
        job = self.state.start_job("export", lambda progress, stop: fn(record, path))
        if job is None:
            self.status.setText("Trwa inne zadanie – spróbuj za chwilę.")
            return
        self.status.setText(f"Zapisywanie {Path(path).name}…")
        job.succeeded.connect(lambda p: self.status.setText(f"Zapisano: {p}"))
        job.failed.connect(lambda exc, tb: (self.status.setText("Eksport nieudany."), show_error(self, exc, tb)))
