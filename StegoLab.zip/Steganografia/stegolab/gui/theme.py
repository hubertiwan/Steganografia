"""Styl aplikacji: ciemny pasek nawigacji, jasna, ciepła powierzchnia robocza, białe karty.

Kolory danych pochodzą z stegolab.charts (algorytm = kolor), kolory interfejsu są neutralne,
żeby nie konkurowały z kolorami serii na wykresach.
"""
from PySide6.QtGui import QColor, QFont, QPalette

INK = "#16181d"
INK_2 = "#2a2d35"
SURFACE = "#f6f5f2"
CARD = "#ffffff"
BORDER = "#e4e3df"
TEXT = "#16181d"
TEXT_2 = "#55534e"
MUTED = "#8a8984"
OK = "#15803d"
OK_BG = "#ecfdf3"
WARN = "#a16207"
WARN_BG = "#fef9e7"
ERR = "#b91c1c"
ERR_BG = "#fef2f2"
INFO_BG = "#eef3fb"
GREEN_TOKEN_BG = "#d7f5e1"
GREEN_TOKEN_FG = "#14532d"
RED_TOKEN_BG = "#fde0de"
RED_TOKEN_FG = "#7f1d1d"

QSS = f"""
QWidget {{ color: {TEXT}; font-size: 10pt; }}
QMainWindow, #Content {{ background: {SURFACE}; }}
QToolTip {{ background: {INK}; color: white; border: none; padding: 6px 8px; }}

#Sidebar {{ background: {INK}; }}
#Brand {{ color: white; font-size: 15pt; font-weight: 700; padding: 0 0 0 4px; }}
#BrandSub {{ color: #9a9ca4; font-size: 8.5pt; padding: 0 0 0 4px; }}
#NavButton {{ background: transparent; color: #c9cbd2; border: none; text-align: left;
             padding: 9px 14px; border-radius: 8px; font-size: 10pt; }}
#NavButton:hover {{ background: {INK_2}; color: white; }}
#NavButton:checked {{ background: #2f3340; color: white; font-weight: 600; }}
#SideLabel {{ color: #8b8e98; font-size: 8pt; letter-spacing: 1px; padding: 10px 4px 2px 4px; }}
#ModelChip {{ background: {INK_2}; color: #e6e7eb; border-radius: 8px; padding: 8px 10px; font-size: 8.5pt; }}
#ModelChip[synthetic="true"] {{ border-left: 3px solid #eda100; }}
#ModelChip[synthetic="false"] {{ border-left: 3px solid #1baf7a; }}
#SideButton {{ background: transparent; color: #c9cbd2; border: 1px solid #3a3e4a; border-radius: 7px; padding: 6px; }}
#SideButton:hover {{ background: {INK_2}; color: white; }}

#PageTitle {{ font-size: 18pt; font-weight: 700; color: {TEXT}; }}
#PageSubtitle {{ font-size: 10pt; color: {TEXT_2}; }}
#H2 {{ font-size: 12pt; font-weight: 700; color: {TEXT}; }}
#H3 {{ font-size: 10.5pt; font-weight: 600; color: {TEXT}; }}
#Muted {{ color: {TEXT_2}; }}
#Small {{ color: {TEXT_2}; font-size: 8.5pt; }}
#BigNumber {{ font-size: 20pt; font-weight: 700; }}

#Card {{ background: {CARD}; border: 1px solid {BORDER}; border-radius: 10px; }}
QGroupBox {{ background: {CARD}; border: 1px solid {BORDER}; border-radius: 10px; margin-top: 14px;
            padding: 14px 10px 8px 10px; font-weight: 600; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 4px; color: {TEXT_2}; }}

QPushButton {{ background: {CARD}; border: 1px solid #cfcdc7; border-radius: 7px; padding: 6px 14px; }}
QPushButton:hover {{ background: #f0efeb; }}
QPushButton:pressed {{ background: #e6e5e0; }}
QPushButton:disabled {{ color: #a8a6a0; background: #f3f2ee; border-color: {BORDER}; }}
QPushButton#Primary {{ background: {INK}; color: white; border: 1px solid {INK}; font-weight: 600; padding: 7px 18px; }}
QPushButton#Primary:hover {{ background: #2c3039; }}
QPushButton#Primary:disabled {{ background: #9c9ea5; border-color: #9c9ea5; color: #eceef2; }}
QPushButton#Danger {{ color: {ERR}; }}
QPushButton#Link {{ border: none; background: transparent; color: #1f4fd1; padding: 2px 4px; text-align: left; }}
QPushButton#Link:hover {{ text-decoration: underline; }}

QLineEdit, QPlainTextEdit, QTextEdit, QTextBrowser, QSpinBox, QDoubleSpinBox, QComboBox {{
    background: {CARD}; border: 1px solid #d3d1cb; border-radius: 6px; padding: 4px 6px;
    selection-background-color: #c7d7fb; selection-color: {TEXT}; }}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1px solid #5b6b8c; }}
QComboBox QAbstractItemView {{ background: {CARD}; selection-background-color: #e7ecf6; selection-color: {TEXT}; }}

QTabWidget::pane {{ border: 1px solid {BORDER}; border-radius: 10px; background: {CARD}; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 7px 14px; color: {TEXT_2}; border: none;
               border-bottom: 2px solid transparent; margin-right: 4px; }}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {INK}; font-weight: 600; }}
QTabBar::tab:hover {{ color: {TEXT}; }}

QTableWidget, QTableView, QListWidget, QTreeWidget {{ background: {CARD}; border: 1px solid {BORDER};
    border-radius: 8px; gridline-color: #efeee9; alternate-background-color: #faf9f7; }}
QTableWidget::item:selected, QListWidget::item:selected, QTreeWidget::item:selected {{
    background: #e7ecf6; color: {TEXT}; }}
QListWidget::item {{ padding: 7px 6px; border-bottom: 1px solid #f0efeb; }}
QHeaderView::section {{ background: #f3f2ee; border: none; border-bottom: 1px solid {BORDER};
    padding: 6px; font-weight: 600; color: {TEXT_2}; }}

QProgressBar {{ background: #ebeae5; border: none; border-radius: 4px; height: 8px; text-align: center;
               color: transparent; max-height: 8px; }}
QProgressBar::chunk {{ background: {INK}; border-radius: 4px; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #cfcdc7; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #cfcdc7; border-radius: 4px; min-width: 30px; }}
QSplitter::handle {{ background: transparent; }}

#Banner {{ border-radius: 8px; padding: 9px 12px; }}
#Banner[level="ok"] {{ background: {OK_BG}; color: {OK}; border: 1px solid #b7e4c7; }}
#Banner[level="warn"] {{ background: {WARN_BG}; color: {WARN}; border: 1px solid #f1dd9b; }}
#Banner[level="error"] {{ background: {ERR_BG}; color: {ERR}; border: 1px solid #f5c2c0; }}
#Banner[level="info"] {{ background: {INFO_BG}; color: #27406f; border: 1px solid #cfdcf3; }}
#Pill {{ border-radius: 9px; padding: 2px 9px; font-size: 8.5pt; font-weight: 600; }}
#Pill[level="ok"] {{ background: {OK_BG}; color: {OK}; }}
#Pill[level="error"] {{ background: {ERR_BG}; color: {ERR}; }}
#Pill[level="neutral"] {{ background: #efeee9; color: {TEXT_2}; }}
QAbstractSpinBox {{ padding-right: 20px; }}
QAbstractSpinBox::up-button {{ subcontrol-origin: border; subcontrol-position: top right; width: 18px;
    border-left: 1px solid {BORDER}; border-top-right-radius: 6px; background: #f6f5f2; }}
QAbstractSpinBox::down-button {{ subcontrol-origin: border; subcontrol-position: bottom right; width: 18px;
    border-left: 1px solid {BORDER}; border-bottom-right-radius: 6px; background: #f6f5f2; }}
QAbstractSpinBox::up-button:hover, QAbstractSpinBox::down-button:hover {{ background: #ebeae5; }}
QAbstractSpinBox::up-arrow {{ image: url(ASSETS/up.svg); width: 9px; height: 6px; }}
QAbstractSpinBox::down-arrow {{ image: url(ASSETS/down.svg); width: 9px; height: 6px; }}
QComboBox {{ padding-right: 24px; }}
QComboBox::drop-down {{ subcontrol-origin: padding; subcontrol-position: top right; width: 22px; border: none; }}
QComboBox::down-arrow {{ image: url(ASSETS/down.svg); width: 10px; height: 6px; }}
"""


def apply(app):
    font = QFont()
    font.setFamilies(["Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Noto Sans", "DejaVu Sans", "Arial"])
    font.setPointSizeF(10)
    app.setFont(font)
    app.setStyle("Fusion")
    pal = app.palette()
    pal.setColor(QPalette.Window, QColor(SURFACE))
    pal.setColor(QPalette.Base, QColor(CARD))
    pal.setColor(QPalette.Text, QColor(TEXT))
    pal.setColor(QPalette.WindowText, QColor(TEXT))
    pal.setColor(QPalette.Highlight, QColor("#c7d7fb"))
    pal.setColor(QPalette.HighlightedText, QColor(TEXT))
    app.setPalette(pal)
    from pathlib import Path
    assets = (Path(__file__).parent / "assets").as_posix()
    app.setStyleSheet(QSS.replace("ASSETS", assets))
