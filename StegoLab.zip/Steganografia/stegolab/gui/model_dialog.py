"""Okno wyboru i ładowania modelu językowego (ładowanie w tle)."""
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QFormLayout,
                               QGroupBox, QHBoxLayout, QPushButton, QRadioButton, QSpinBox, QVBoxLayout)

from .. import models
from .widgets import Banner, ProgressPanel, label, primary_button, show_error

HF_SUGGESTIONS = [models.DEFAULT_HF_MODEL, "Qwen/Qwen2.5-1.5B-Instruct", "facebook/opt-1.3b", "gpt2"]


class ModelDialog(QDialog):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        self.state = state
        self.job = None
        self.setWindowTitle("Model językowy")
        self.setMinimumWidth(620)
        lay = QVBoxLayout(self)
        lay.setSpacing(10)
        lay.addWidget(label("Wybór modelu językowego", "H2"))
        lay.addWidget(label("Oba algorytmy z repozytorium osadzają znak wodny podczas generacji tekstu, dlatego każdy "
                            "eksperyment wymaga modelu językowego. Detekcja potrzebuje tylko jego tokenizera.", "Muted"))

        self.kind = QButtonGroup(self)
        self.rb_hf = QRadioButton("Model Hugging Face (rzeczywisty LLM – do wyników w pracy)")
        self.rb_syn = QRadioButton("Model syntetyczny (szybkie eksperymenty statystyczne, bez pobierania)")
        self.kind.addButton(self.rb_hf)
        self.kind.addButton(self.rb_syn)

        hf = QGroupBox("Hugging Face")
        hf_form = QFormLayout(hf)
        row = QHBoxLayout()
        self.hf_name = QComboBox()
        self.hf_name.setEditable(True)
        self.hf_name.addItems(HF_SUGGESTIONS)
        browse = QPushButton("Katalog lokalny…")
        browse.clicked.connect(self._browse)
        row.addWidget(self.hf_name, 1)
        row.addWidget(browse)
        hf_form.addRow("Nazwa lub ścieżka", row)
        self.chat = QCheckBox("Używaj szablonu czatu (wyłącz dla modeli bazowych, np. OPT, GPT-2)")
        self.chat.setChecked(True)
        hf_form.addRow("", self.chat)
        hf_form.addRow("", label("Pierwsze użycie pobiera model z huggingface.co (Qwen2.5-0.5B ≈ 1 GB). "
                                 "Na CPU generacja 100 tokenów trwa kilka sekund; zalecane GPU dla dłuższych testów.",
                                 "Small"))

        syn = QGroupBox("Model syntetyczny")
        syn_form = QFormLayout(syn)
        self.vocab = QSpinBox()
        self.vocab.setRange(100, 100000)
        self.vocab.setValue(5000)
        self.spread = QDoubleSpinBox()
        self.spread.setRange(0.1, 20)
        self.spread.setSingleStep(0.5)
        self.spread.setValue(3.0)
        self.ctx = QSpinBox()
        self.ctx.setRange(1, 8)
        self.ctx.setValue(2)
        self.seed = QSpinBox()
        self.seed.setRange(0, 1_000_000)
        syn_form.addRow("Rozmiar słownika |V|", self.vocab)
        syn_form.addRow("Rozrzut logitów s (mniej = większa entropia)", self.spread)
        syn_form.addRow("Kontekst modelu (tokeny)", self.ctx)
        syn_form.addRow("Ziarno modelu", self.seed)
        syn_form.addRow("", label("Rozkład następnego tokenu: softmax(s·N(0,1)), deterministyczny względem ostatnich "
                                  "tokenów – jak w testach repozytorium. Tekst to pseudosłowa bez znaczenia; "
                                  "wyniki są oznaczane jako „model syntetyczny”.", "Small"))

        lay.addWidget(self.rb_hf)
        lay.addWidget(hf)
        lay.addWidget(self.rb_syn)
        lay.addWidget(syn)
        self.banner = Banner()
        lay.addWidget(self.banner)
        self.progress = ProgressPanel()
        lay.addWidget(self.progress)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.close_btn = QPushButton("Zamknij")
        self.close_btn.clicked.connect(self.reject)
        self.load_btn = primary_button("Wczytaj model")
        self.load_btn.clicked.connect(self.load)
        buttons.addWidget(self.close_btn)
        buttons.addWidget(self.load_btn)
        lay.addLayout(buttons)

        cur = state.model
        if cur is not None and cur.kind == "hf":
            self.rb_hf.setChecked(True)
            self.hf_name.setEditText(cur.name)
        else:
            self.rb_syn.setChecked(True)
            if cur is not None:
                self.vocab.setValue(cur.vocab_size)
                self.spread.setValue(cur.settings.get("spread", 3.0))
                self.ctx.setValue(cur.settings.get("model_context", 2))
                self.seed.setValue(cur.settings.get("model_seed", 0))
        self.rb_hf.toggled.connect(lambda on: (hf.setEnabled(on), syn.setEnabled(not on)))
        hf.setEnabled(self.rb_hf.isChecked())
        syn.setEnabled(self.rb_syn.isChecked())

    def _browse(self):
        path = QFileDialog.getExistingDirectory(self, "Katalog modelu (z config.json)")
        if path:
            self.hf_name.setEditText(path)

    def load(self):
        if self.rb_hf.isChecked():
            name, chat = self.hf_name.currentText(), self.chat.isChecked()
            fn = lambda progress, stop: models.load_hf_model(name, chat)  # noqa: E731
            msg = f"Ładowanie {name}… (pierwsze uruchomienie pobiera model)"
        else:
            v, s, c, sd = self.vocab.value(), self.spread.value(), self.ctx.value(), self.seed.value()
            fn = lambda progress, stop: models.make_synthetic_model(v, s, c, sd)  # noqa: E731
            msg = "Tworzenie modelu syntetycznego…"
        job = self.state.start_job("model", fn)
        if job is None:
            self.banner.set("warn", "Trwa inne zadanie (eksperyment). Poczekaj na jego zakończenie.")
            return
        self.job = job
        self.load_btn.setEnabled(False)
        self.progress.start(msg, indeterminate=True, cancellable=False)
        job.succeeded.connect(self._loaded)
        job.failed.connect(self._failed)
        job.finished.connect(lambda: (self.progress.stop(), self.load_btn.setEnabled(True)))

    def _loaded(self, lm):
        self.state.set_model(lm)
        extra = ""
        if lm.kind == "synthetic":
            extra = f" Średnia entropia rozkładu ≈ {models.synthetic_entropy_estimate(lm, 100):.2f} nat."
        self.banner.set("ok", f"Wczytano: {lm.label}. |V| = {lm.vocab_size}." + extra)
        self.accept()

    def _failed(self, exc, tb):
        self.banner.set("error", "Nie udało się wczytać modelu.")
        show_error(self, exc, tb)

    def reject(self):
        if self.job is not None and self.job.is_running():
            self.banner.set("warn", "Ładowanie trwa – zamknięcie okna nie przerwie pobierania; model zostanie "
                                    "ustawiony po zakończeniu.")
            self.job.succeeded.connect(self.state.set_model)
        super().reject()
