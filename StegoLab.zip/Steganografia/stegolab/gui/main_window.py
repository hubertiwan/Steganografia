"""Główne okno: pasek nawigacji + strony w QStackedWidget."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton, QStackedWidget, QStatusBar,
                               QVBoxLayout, QWidget)

from .. import APP_NAME, __version__
from .model_dialog import ModelDialog
from .pages.documents_page import DocumentsPage
from .pages.experiments_pages import ComparePage, DemoPage, TestPage
from .pages.history_page import HistoryPage
from .pages.overview import AlgorithmsPage, DashboardPage
from .state import AppState

NAV = [("dashboard", "Panel główny"), ("algorithms", "Algorytmy"), ("demo", "Demonstracja"),
       ("test", "Tryb testowy"), ("compare", "Porównanie"), ("history", "Historia"), ("documents", "Dokumenty PDF")]


class MainWindow(QMainWindow):
    def __init__(self, state: AppState = None):
        super().__init__()
        self.state = state or AppState()
        self.setWindowTitle(f"{APP_NAME} – znakowanie wodne tekstu LLM")
        self.resize(1440, 900)
        self.setMinimumSize(1100, 700)

        root = QWidget()
        rl = QHBoxLayout(root)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        self.setCentralWidget(root)

        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(232)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(14, 20, 14, 16)
        sl.setSpacing(4)
        brand = QLabel(APP_NAME)
        brand.setObjectName("Brand")
        sub = QLabel("Znakowanie wodne tekstu LLM")
        sub.setObjectName("BrandSub")
        sl.addWidget(brand)
        sl.addWidget(sub)
        sl.addSpacing(14)
        self.nav_buttons = {}
        for key, title in NAV:
            if key == "demo":
                lab = QLabel("EKSPERYMENTY")
                lab.setObjectName("SideLabel")
                sl.addWidget(lab)
            if key == "history":
                lab = QLabel("WYNIKI I ŹRÓDŁA")
                lab.setObjectName("SideLabel")
                sl.addWidget(lab)
            b = QPushButton(title)
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.setAutoExclusive(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            sl.addWidget(b)
            self.nav_buttons[key] = b
        sl.addStretch(1)
        lab = QLabel("MODEL JĘZYKOWY")
        lab.setObjectName("SideLabel")
        sl.addWidget(lab)
        self.model_chip = QLabel("–")
        self.model_chip.setObjectName("ModelChip")
        self.model_chip.setWordWrap(True)
        sl.addWidget(self.model_chip)
        self.model_btn = QPushButton("Zmień model…")
        self.model_btn.setObjectName("SideButton")
        self.model_btn.clicked.connect(self.change_model)
        sl.addWidget(self.model_btn)
        ver = QLabel(f"wersja {__version__}")
        ver.setObjectName("BrandSub")
        sl.addSpacing(6)
        sl.addWidget(ver)
        rl.addWidget(side)

        self.stack = QStackedWidget()
        self.stack.setObjectName("Content")
        rl.addWidget(self.stack, 1)
        self.pages = {
            "dashboard": DashboardPage(self.state), "algorithms": AlgorithmsPage(self.state),
            "demo": DemoPage(self.state), "test": TestPage(self.state), "compare": ComparePage(self.state),
            "history": HistoryPage(self.state), "documents": DocumentsPage(self.state),
        }
        for p in self.pages.values():
            p.setObjectName("Content") if not p.objectName() else None
            self.stack.addWidget(p)

        self.setStatusBar(QStatusBar())
        self.state.model_changed.connect(self._model_changed)
        self.state.busy_changed.connect(self._busy)
        self.state.navigate.connect(self._navigate)
        self.go("dashboard")
        if self.state.model is not None:
            self._model_changed(self.state.model)

    def go(self, key):
        self.stack.setCurrentWidget(self.pages[key])
        self.nav_buttons[key].setChecked(True)

    def _navigate(self, key, arg):
        self.go(key)
        page = self.pages[key]
        if arg is None:
            return
        if key in ("algorithms", "demo", "test", "compare"):
            page.select(arg)
        elif key == "history":
            page.open(arg)
        elif key == "documents":
            page.open_doc(arg)

    def _model_changed(self, lm):
        syn = lm.kind == "synthetic"
        self.model_chip.setProperty("synthetic", "true" if syn else "false")
        self.model_chip.style().unpolish(self.model_chip)
        self.model_chip.style().polish(self.model_chip)
        if syn:
            self.model_chip.setText(f"Model syntetyczny\n|V| = {lm.vocab_size}, s = {lm.settings['spread']}")
        else:
            self.model_chip.setText(f"{lm.name}\n|V| = {lm.vocab_size} · {lm.device}")
        self.statusBar().showMessage(f"Aktywny model: {lm.label}", 6000)

    def _busy(self, busy):
        self.model_btn.setEnabled(not busy)
        if busy and self.state.job is not None:
            self.statusBar().showMessage("Trwają obliczenia w tle – interfejs pozostaje aktywny.")
        else:
            self.statusBar().clearMessage()

    def change_model(self):
        ModelDialog(self.state, self).exec()

    def closeEvent(self, event):
        if self.state.job is not None:
            self.state.cancel_job()
            self.state.job.wait(15000)  # bieżąca generacja kończy się, wpis trafia do historii jako przerwany
        super().closeEvent(event)
