"""Elementy interfejsu wielokrotnego użytku."""
import html
import traceback

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout,
                               QFrame, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QMessageBox, QProgressBar, QPushButton, QSizePolicy, QSpinBox, QTableWidget,
                               QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from .. import experiments
from ..errors import StegoLabError
from . import theme


# ------------------------------------------------------------------ podstawowe
def clear_layout(layout):
    """Usuwa elementy z layoutu natychmiast (ukrycie + odłączenie), a nie dopiero przy deleteLater."""
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.hide()
            w.setParent(None)
            w.deleteLater()
        elif item.layout() is not None:
            clear_layout(item.layout())
def label(text, name=None, wrap=True, selectable=False):
    lab = QLabel(text)
    if name:
        lab.setObjectName(name)
    lab.setWordWrap(wrap)
    if selectable:
        lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
    return lab


def page_header(title, subtitle):
    box = QVBoxLayout()
    box.setSpacing(2)
    box.addWidget(label(title, "PageTitle"))
    box.addWidget(label(subtitle, "PageSubtitle"))
    return box


class Card(QFrame):
    def __init__(self, title=None, parent=None, spacing=8):
        super().__init__(parent)
        self.setObjectName("Card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(16, 14, 16, 14)
        self.body.setSpacing(spacing)
        if title:
            self.body.addWidget(label(title, "H3"))


class Banner(QLabel):
    def __init__(self, text="", level="info"):
        super().__init__(text)
        self.setObjectName("Banner")
        self.setWordWrap(True)
        self.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.set(level, text)

    def set(self, level, text):
        self.setProperty("level", level)
        self.setText(text)
        self.style().unpolish(self)
        self.style().polish(self)
        self.setVisible(bool(text))


class Pill(QLabel):
    def __init__(self, text="", level="neutral"):
        super().__init__(text)
        self.setObjectName("Pill")
        self.set(level, text)

    def set(self, level, text):
        self.setProperty("level", level)
        self.setText(text)
        self.style().unpolish(self)
        self.style().polish(self)


def primary_button(text):
    b = QPushButton(text)
    b.setObjectName("Primary")
    b.setCursor(Qt.PointingHandCursor)
    return b


def link_button(text):
    b = QPushButton(text)
    b.setObjectName("Link")
    b.setCursor(Qt.PointingHandCursor)
    return b


# ------------------------------------------------------------------ błędy
def show_error(parent, exc, tb=None, title="Wystąpił problem"):
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    if isinstance(exc, StegoLabError):
        box.setText(exc.message)
        if exc.hint:
            box.setInformativeText("Jak rozwiązać: " + exc.hint)
    else:
        box.setText(f"Nieoczekiwany błąd: {type(exc).__name__}: {exc}")
        box.setInformativeText("Operacja została przerwana, aplikacja działa dalej. Szczegóły techniczne "
                               "poniżej – przydadzą się przy zgłaszaniu problemu.")
        box.setDetailedText(tb or "".join(traceback.format_exception(exc)))
    box.exec()


# ------------------------------------------------------------------ formularz parametrów
class ParamForm(QWidget):
    """Formularz generowany z listy ParamSpec algorytmu (grupy: znak, detekcja, próbkowanie)."""
    GROUPS = [("watermark", "Znak wodny"), ("detection", "Detekcja"), ("sampling", "Próbkowanie modelu")]

    def __init__(self, spec, parent=None, compact=False):
        super().__init__(parent)
        self.spec = spec
        self.inputs = {}
        lay = QHBoxLayout(self) if not compact else QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        for group, title in self.GROUPS:
            params = [p for p in spec.params if p.group == group]
            if not params:
                continue
            box = QGroupBox(title)
            form = QFormLayout(box)
            form.setLabelAlignment(Qt.AlignLeft)
            form.setHorizontalSpacing(10)
            form.setVerticalSpacing(6)
            for p in params:
                w = self._make_input(p)
                w.setToolTip(p.help)
                lab = QLabel(p.label)
                lab.setToolTip(p.help)
                form.addRow(lab, w)
                self.inputs[p.name] = w
            lay.addWidget(box)
        reset = QPushButton("Przywróć domyślne")
        reset.setToolTip("Wartości domyślne z publikacji / skryptów demo w repozytorium")
        reset.clicked.connect(self.reset)
        col = QVBoxLayout()
        col.addStretch(1)
        col.addWidget(reset)
        lay.addLayout(col)

    def _make_input(self, p):
        if p.kind == "int" and (p.maximum or 0) <= 2**31 - 1:
            w = QSpinBox()
            w.setRange(int(p.minimum if p.minimum is not None else -2**31), int(p.maximum))
            w.setSingleStep(int(p.step or 1))
            w.setValue(int(p.default))
        elif p.kind == "float":
            w = QDoubleSpinBox()
            w.setDecimals(p.decimals)
            lo = p.minimum if p.minimum is not None else -1e9
            if p.exclusive_min:
                lo += 10 ** -p.decimals
            w.setRange(lo, p.maximum if p.maximum is not None else 1e9)
            w.setSingleStep(p.step or 0.1)
            w.setValue(float(p.default))
        else:  # tekst lub bardzo duża liczba całkowita (np. klucz Unigram do 2^63)
            w = QLineEdit(str(p.default))
        w.setMinimumWidth(110)
        return w

    def values(self) -> dict:
        out = {}
        for name, w in self.inputs.items():
            out[name] = w.value() if hasattr(w, "value") else w.text()
        return out

    def set_values(self, values: dict):
        for name, v in values.items():
            w = self.inputs.get(name)
            if w is None:
                continue
            if isinstance(w, QLineEdit):
                w.setText(str(v))
            else:
                w.setValue(v)

    def reset(self):
        self.set_values(self.spec.defaults())

    def validated(self) -> dict:
        return self.spec.validate(self.values())  # zgłosi ParameterError z opisem


# ------------------------------------------------------------------ tabela metryk
class MetricTable(QTableWidget):
    def __init__(self, headers=("Metryka", "Wartość"), parent=None):
        super().__init__(0, len(headers), parent)
        self.setHorizontalHeaderLabels(list(headers))
        self.verticalHeader().setVisible(False)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setAlternatingRowColors(True)
        self.setWordWrap(True)
        self.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for c in range(1, len(headers)):
            self.horizontalHeader().setSectionResizeMode(c, QHeaderView.Stretch)

    def set_rows(self, rows):
        self.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, v in enumerate(row):
                item = QTableWidgetItem(str(v))
                if c == 0:
                    f = item.font()
                    f.setWeight(QFont.DemiBold)
                    item.setFont(f)
                self.setItem(r, c, item)
        self.resizeRowsToContents()


# ------------------------------------------------------------------ wykres
class ChartView(QWidget):
    """Kontener na Figure matplotlib; replace() podmienia wykres."""

    def __init__(self, fig=None, min_height=300, parent=None):
        super().__init__(parent)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.canvas = None
        self.min_height = min_height
        if fig is not None:
            self.replace(fig)

    def replace(self, fig):
        from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
        if self.canvas is not None:
            self.lay.removeWidget(self.canvas)
            self.canvas.deleteLater()
        self.canvas = FigureCanvasQTAgg(fig)
        self.canvas.setMinimumHeight(self.min_height)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.lay.addWidget(self.canvas)


# ------------------------------------------------------------------ kolorowanie tokenów
def token_html(pieces, annotation, algo_id):
    """Unigram: zielony/czerwony = token z listy zielonej/czerwonej (jak Tabela 1 w pracy).
    SynthID: kolor wg średniej g-wartości tokenu (> 0.5 zielony, < 0.5 czerwony); szary = nieoceniany."""
    spans = []
    for piece, a in zip(pieces, annotation):
        text = html.escape(piece).replace("\n", "<br>")
        if a is None:
            style = f"color:{theme.MUTED};"
            tip = "nieoceniany (początkowe H tokenów lub powtórzony kontekst)"
        else:
            strength = abs(a - 0.5) * 2 if algo_id == "synthid" else 1.0
            if a > 0.5:
                bg, fg = theme.GREEN_TOKEN_BG, theme.GREEN_TOKEN_FG
            elif a < 0.5:
                bg, fg = theme.RED_TOKEN_BG, theme.RED_TOKEN_FG
            else:
                bg, fg = "#eeeeea", theme.TEXT_2
            alpha = 0.35 + 0.65 * strength
            style = f"background-color:{_mix(bg, alpha)}; color:{fg};"
            tip = (f"lista {'zielona' if a > 0.5 else 'czerwona'}" if algo_id == "unigram"
                   else f"średnia g = {a:.3f}")
        spans.append(f'<span style="{style}" title="{html.escape(tip)}">{text}</span>')
    return ("<div style='font-family: \"DejaVu Sans Mono\", Consolas, monospace; font-size:10pt; "
            "line-height:165%'>" + "".join(spans) + "</div>")


def _mix(hex_color, alpha):
    """Mieszanie koloru z bielą (QTextBrowser nie obsługuje rgba w HTML)."""
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    r, g, b = (round(255 + (c - 255) * alpha) for c in (r, g, b))
    return f"#{r:02x}{g:02x}{b:02x}"


class TokenView(QTextBrowser):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setOpenLinks(False)
        self.setMinimumHeight(160)
        self._plain = ""
        self._html = ""
        self.colored = True

    def show_tokens(self, pieces, annotation, algo_id, plain_text):
        self._plain = plain_text
        self._html = token_html(pieces, annotation, algo_id)
        self._render()

    def set_colored(self, on):
        self.colored = on
        self._render()

    def _render(self):
        if self.colored and self._html:
            self.setHtml(self._html)
        else:
            self.setPlainText(self._plain)


def token_legend(algo_id):
    if algo_id == "unigram":
        txt = (f"<span style='background:{theme.GREEN_TOKEN_BG};color:{theme.GREEN_TOKEN_FG}'>&nbsp;zielona lista&nbsp;</span>"
               f"&nbsp;&nbsp;<span style='background:{theme.RED_TOKEN_BG};color:{theme.RED_TOKEN_FG}'>&nbsp;czerwona lista&nbsp;</span>")
    else:
        txt = (f"<span style='background:{theme.GREEN_TOKEN_BG};color:{theme.GREEN_TOKEN_FG}'>&nbsp;średnia g &gt; 0.5&nbsp;</span>"
               f"&nbsp;&nbsp;<span style='background:{theme.RED_TOKEN_BG};color:{theme.RED_TOKEN_FG}'>&nbsp;średnia g &lt; 0.5&nbsp;</span>"
               f"&nbsp;&nbsp;<span style='color:{theme.MUTED}'>szary – nieoceniany</span>&nbsp;&nbsp;(intensywność ∝ |g − 0.5|)")
    lab = QLabel(txt)
    lab.setObjectName("Small")
    lab.setTextFormat(Qt.RichText)
    return lab


# ------------------------------------------------------------------ postęp
class ProgressPanel(QWidget):
    cancel_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        col = QVBoxLayout()
        col.setSpacing(4)
        self.msg = label("", "Small")
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        col.addWidget(self.msg)
        col.addWidget(self.bar)
        lay.addLayout(col, 1)
        self.cancel = QPushButton("Przerwij")
        self.cancel.setObjectName("Danger")
        self.cancel.clicked.connect(self.cancel_requested)
        lay.addWidget(self.cancel)
        self.setVisible(False)

    def start(self, msg="Uruchamianie…", indeterminate=False, cancellable=True):
        self.setVisible(True)
        self.bar.setRange(0, 0 if indeterminate else 1000)
        self.bar.setValue(0)
        self.msg.setText(msg)
        self.cancel.setVisible(cancellable)
        self.cancel.setEnabled(True)

    def update(self, frac, msg, elapsed=None):
        if self.bar.maximum() > 0:
            self.bar.setValue(int(1000 * max(0.0, min(1.0, frac))))
        eta = ""
        if elapsed and 0.03 < frac < 1:
            eta = f" · pozostało ok. {_duration(elapsed * (1 - frac) / frac)}"
        self.msg.setText(f"{msg}  ({100 * frac:.0f}%{eta})" if self.bar.maximum() > 0 else msg)

    def stop(self):
        self.setVisible(False)

    def cancelling(self):
        self.cancel.setEnabled(False)
        self.msg.setText(self.msg.text() + " · przerywanie po bieżącym tekście…")


def _duration(s):
    return f"{s:.0f} s" if s < 90 else f"{s / 60:.1f} min"


# ------------------------------------------------------------------ ustawienia testu
class RunSettingsForm(QGroupBox):
    """Wspólne ustawienia trybu testowego i porównania."""

    def __init__(self, parent=None):
        super().__init__("Ustawienia eksperymentu", parent)
        grid = QGridLayout(self)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(6)
        self.source = QComboBox()
        self.source.addItems(["Wbudowane polecenia z demo.py (20)", "Plik .txt (jedno polecenie w wierszu)"])
        self.file_edit = QLineEdit()
        self.file_edit.setPlaceholderText("ścieżka do pliku z poleceniami")
        self.browse = QPushButton("Wybierz…")
        self.browse.clicked.connect(self._browse)
        self.count = QSpinBox()
        self.count.setRange(1, 10000)
        self.count.setValue(20)
        self.count.setToolTip("Liczba poleceń – dla każdego powstaje tekst ze znakiem i bez znaku. "
                              "Gdy plik ma mniej poleceń, użyte zostaną wszystkie.")
        self.max_tokens = QSpinBox()
        self.max_tokens.setRange(1, 2000)
        self.max_tokens.setValue(100)
        self.seed = QSpinBox()
        self.seed.setRange(0, 1_000_000)
        self.detect_on = QComboBox()
        self.detect_on.addItem("tekście po retokenizacji (realistycznie)", "text")
        self.detect_on.addItem("tokenach z generacji", "tokens")
        self.edits = QLineEdit("0, 0.1, 0.2, 0.3, 0.5")
        self.edits.setToolTip("Ułamki tokenów poddanych losowej edycji (wstawienie/usunięcie/zamiana), przecinkami.")
        self.ppl = QCheckBox("Licz perplexity")
        self.ppl.setChecked(True)
        self.wrong = QCheckBox("Kontrola z błędnym kluczem")
        self.wrong.setChecked(True)

        grid.addWidget(QLabel("Polecenia"), 0, 0)
        grid.addWidget(self.source, 0, 1, 1, 3)
        grid.addWidget(QLabel("Plik"), 1, 0)
        grid.addWidget(self.file_edit, 1, 1, 1, 2)
        grid.addWidget(self.browse, 1, 3)
        grid.addWidget(QLabel("Liczba poleceń"), 2, 0)
        grid.addWidget(self.count, 2, 1)
        grid.addWidget(QLabel("Maks. nowych tokenów"), 2, 2)
        grid.addWidget(self.max_tokens, 2, 3)
        grid.addWidget(QLabel("Ziarno bazowe"), 3, 0)
        grid.addWidget(self.seed, 3, 1)
        grid.addWidget(QLabel("Detekcja na"), 3, 2)
        grid.addWidget(self.detect_on, 3, 3)
        grid.addWidget(QLabel("Edycje (ułamki)"), 4, 0)
        grid.addWidget(self.edits, 4, 1)
        grid.addWidget(self.ppl, 4, 2)
        grid.addWidget(self.wrong, 4, 3)
        self.source.currentIndexChanged.connect(self._toggle)
        self._toggle()

    def _toggle(self):
        use_file = self.source.currentIndex() == 1
        self.file_edit.setEnabled(use_file)
        self.browse.setEnabled(use_file)

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Plik z poleceniami", "", "Pliki tekstowe (*.txt);;Wszystkie (*)")
        if path:
            self.file_edit.setText(path)

    def collect(self):
        """Zwraca (settings, files). Zgłasza InputError dla błędnych danych."""
        files = []
        if self.source.currentIndex() == 1:
            prompts = experiments.read_prompts_file(self.file_edit.text())
            files.append(self.file_edit.text())
        else:
            prompts = experiments.builtin_prompts()
        prompts = prompts[: self.count.value()]
        try:
            fractions = [float(x) for x in self.edits.text().replace(";", ",").split(",") if x.strip()]
        except ValueError:
            from ..errors import InputError
            raise InputError("Nieprawidłowa lista ułamków edycji.", "Podaj liczby z [0, 1] oddzielone przecinkami, np. 0, 0.1, 0.3.")
        settings = {"prompts": prompts, "max_new_tokens": self.max_tokens.value(), "base_seed": self.seed.value(),
                    "detect_on": self.detect_on.currentData(), "edit_fractions": fractions,
                    "compute_perplexity": self.ppl.isChecked(), "wrong_key_control": self.wrong.isChecked()}
        return experiments.normalise_settings(settings), files
