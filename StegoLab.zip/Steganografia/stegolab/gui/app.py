"""Uruchomienie aplikacji."""
import sys
import traceback


def main(argv=None):
    from PySide6.QtWidgets import QApplication, QMessageBox

    from .. import APP_NAME
    from . import theme
    from .main_window import MainWindow
    from .state import AppState

    app = QApplication.instance() or QApplication(argv or sys.argv)
    app.setApplicationName(APP_NAME)
    theme.apply(app)

    def excepthook(exc_type, exc, tb):
        # Ostatnia linia obrony: nieobsłużony wyjątek w wątku GUI nie zamyka aplikacji.
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        sys.stderr.write(text)
        box = QMessageBox(QMessageBox.Critical, "Nieoczekiwany błąd",
                          f"{exc_type.__name__}: {exc}\n\nAplikacja działa dalej, ale ostatnia operacja mogła się "
                          "nie powieść.")
        box.setDetailedText(text)
        box.exec()

    sys.excepthook = excepthook
    state = AppState()
    try:
        state.load_default_model()
    except Exception as exc:  # np. brak PyTorch – okno i tak się otworzy, a błąd będzie widoczny
        QMessageBox.warning(None, APP_NAME, f"Nie udało się utworzyć modelu domyślnego:\n{exc}")
    win = MainWindow(state)
    win.show()
    return app.exec()
