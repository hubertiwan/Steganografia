"""Wykonywanie długich operacji poza wątkiem GUI.

Job opakowuje funkcję fn(progress, should_stop) i uruchamia ją w QThread. Wyniki, postęp
i błędy wracają do wątku GUI przez sygnały Qt (bezpieczne między wątkami).
Przerwanie: flaga sprawdzana przez eksperymenty między kolejnymi generacjami tekstu.
"""
import threading
import time
import traceback

from PySide6.QtCore import QObject, QThread, Signal

from ..errors import ExperimentCancelled


class _Runner(QObject):
    progress = Signal(float, str)
    succeeded = Signal(object)
    failed = Signal(object, str)      # wyjątek, traceback
    cancelled = Signal(object)        # wyjątek ExperimentCancelled
    done = Signal()

    def __init__(self, fn, stop_event):
        super().__init__()
        self.fn = fn
        self.stop_event = stop_event

    def run(self):
        try:
            result = self.fn(lambda f, m="": self.progress.emit(float(f), str(m)), self.stop_event.is_set)
            self.succeeded.emit(result)
        except ExperimentCancelled as exc:
            self.cancelled.emit(exc)
        except Exception as exc:  # każdy błąd trafia do GUI jako komunikat – aplikacja się nie zamyka
            self.failed.emit(exc, traceback.format_exc())
        finally:
            self.done.emit()


class Job(QObject):
    """Jedno zadanie w tle. Obiekt trzeba przechowywać do sygnału finished."""
    progress = Signal(float, str)
    succeeded = Signal(object)
    failed = Signal(object, str)
    cancelled = Signal(object)
    finished = Signal()

    def __init__(self, name, fn, parent=None):
        super().__init__(parent)
        self.name = name
        self.started_at = None
        self._stop = threading.Event()
        self._thread = QThread()
        self._thread.setObjectName(f"job:{name}")
        self._runner = _Runner(fn, self._stop)
        self._runner.moveToThread(self._thread)
        self._thread.started.connect(self._runner.run)
        self._runner.progress.connect(self.progress)
        self._runner.succeeded.connect(self.succeeded)
        self._runner.failed.connect(self.failed)
        self._runner.cancelled.connect(self.cancelled)
        self._runner.done.connect(self._thread.quit)
        self._thread.finished.connect(self.finished)

    def start(self):
        self.started_at = time.perf_counter()
        self._thread.start()

    def cancel(self):
        self._stop.set()

    @property
    def elapsed(self):
        return time.perf_counter() - self.started_at if self.started_at else 0.0

    def is_running(self):
        return self._thread.isRunning()

    def wait(self, ms=30000):
        return self._thread.wait(ms)
