"""Dokumenty PDF: import, podgląd stron i tekstu, wyszukiwanie, przypisywanie do algorytmów."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea,
                               QSpinBox, QSplitter, QTabWidget, QVBoxLayout, QWidget)

from ... import algorithms, documents
from ...errors import StegoLabError
from ..widgets import Banner, Card, label, page_header, primary_button, show_error


class DocumentsPage(QWidget):
    def __init__(self, state):
        super().__init__()
        self.state = state
        self.pdf = None
        self.doc = None
        self.page = 0
        self.hits = []
        lay = QHBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)

        # ---- lewa kolumna: biblioteka i przypisania
        left = QVBoxLayout()
        left.addLayout(page_header("Dokumenty PDF", "Materiały źródłowe algorytmów"))
        row = QHBoxLayout()
        self.import_btn = primary_button("Importuj PDF…")
        self.import_btn.clicked.connect(self.import_pdf)
        self.remove_btn = QPushButton("Usuń")
        self.remove_btn.setObjectName("Danger")
        self.remove_btn.clicked.connect(self.remove)
        row.addWidget(self.import_btn)
        row.addWidget(self.remove_btn)
        row.addStretch(1)
        left.addLayout(row)
        self.list = QListWidget()
        self.list.currentItemChanged.connect(self._select)
        left.addWidget(self.list, 1)

        self.info = Card("Informacje o dokumencie")
        self.info_text = label("", "Small", selectable=True)
        self.info.body.addWidget(self.info_text)
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Tytuł w bibliotece")
        self.title_edit.editingFinished.connect(self._save_title)
        self.info.body.addWidget(self.title_edit)
        left.addWidget(self.info)

        self.assign_card = Card("Przypisanie do algorytmu")
        form = QFormLayout()
        self.a_algo = QComboBox()
        for aid, ad in algorithms.available().items():
            self.a_algo.addItem(ad.spec.name, aid)
        self.a_role = QComboBox()
        self.a_role.addItems(documents.ROLES)
        self.a_pages = QLineEdit()
        self.a_pages.setPlaceholderText("np. 3–5, Alg. 1")
        self.a_note = QLineEdit()
        self.a_note.setPlaceholderText("notatka (opcjonalnie)")
        form.addRow("Algorytm", self.a_algo)
        form.addRow("Rola dokumentu", self.a_role)
        form.addRow("Istotne strony", self.a_pages)
        form.addRow("Notatka", self.a_note)
        self.assign_card.body.addLayout(form)
        brow = QHBoxLayout()
        assign = primary_button("Przypisz")
        assign.clicked.connect(self.assign)
        unassign = QPushButton("Usuń przypisanie")
        unassign.clicked.connect(self.unassign)
        brow.addWidget(assign)
        brow.addWidget(unassign)
        brow.addStretch(1)
        self.assign_card.body.addLayout(brow)
        self.assignments = label("", "Small")
        self.assign_card.body.addWidget(self.assignments)
        self.assign_card.body.addWidget(label("Dokument pełni rolę materiału referencyjnego. Aplikacja nie weryfikuje "
                                              "jego treści ani nie dopisuje do niego informacji.", "Small"))
        left.addWidget(self.assign_card)
        lw = QWidget()
        lw.setLayout(left)
        lw.setFixedWidth(400)
        lay.addWidget(lw)

        # ---- prawa kolumna: podgląd
        right = QVBoxLayout()
        self.banner = Banner()
        right.addWidget(self.banner)
        search = QHBoxLayout()
        self.query = QLineEdit()
        self.query.setPlaceholderText("Szukaj w dokumencie (Enter)…")
        self.query.returnPressed.connect(self.search)
        sb = QPushButton("Szukaj")
        sb.clicked.connect(self.search)
        search.addWidget(self.query, 1)
        search.addWidget(sb)
        right.addLayout(search)
        split = QSplitter(Qt.Horizontal)
        self.tabs = QTabWidget()
        pages = QWidget()
        pl = QVBoxLayout(pages)
        nav = QHBoxLayout()
        self.prev_btn = QPushButton("◀ Poprzednia")
        self.prev_btn.clicked.connect(lambda: self.goto(self.page - 1))
        self.next_btn = QPushButton("Następna ▶")
        self.next_btn.clicked.connect(lambda: self.goto(self.page + 1))
        self.page_spin = QSpinBox()
        self.page_spin.setMinimum(1)
        self.page_spin.valueChanged.connect(lambda v: self.goto(v - 1) if v - 1 != self.page else None)
        self.page_total = QLabel("/ –")
        self.zoom = QDoubleSpinBox()
        self.zoom.setRange(0.5, 4.0)
        self.zoom.setSingleStep(0.25)
        self.zoom.setValue(1.0)
        self.zoom.setSuffix("×")
        self.zoom.valueChanged.connect(lambda _: self.render())
        for w in (self.prev_btn, self.page_spin, self.page_total, self.next_btn):
            nav.addWidget(w)
        nav.addStretch(1)
        nav.addWidget(QLabel("Powiększenie"))
        nav.addWidget(self.zoom)
        pl.addLayout(nav)
        self.page_label = QLabel()
        self.page_label.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        self.page_scroll = QScrollArea()
        self.page_scroll.setWidgetResizable(True)
        self.page_scroll.setWidget(self.page_label)
        self.page_scroll.setStyleSheet("background:#e9e8e3; border-radius:8px;")
        pl.addWidget(self.page_scroll, 1)
        self.tabs.addTab(pages, "Strony")
        self.text_view = QPlainTextEdit(readOnly=True)
        self.tabs.addTab(self.text_view, "Tekst")
        split.addWidget(self.tabs)
        self.hit_list = QListWidget()
        self.hit_list.setWordWrap(True)
        self.hit_list.itemClicked.connect(self._hit_clicked)
        hw = QWidget()
        hl = QVBoxLayout(hw)
        hl.setContentsMargins(0, 0, 0, 0)
        self.hit_label = label("Wyniki wyszukiwania", "H3")
        hl.addWidget(self.hit_label)
        hl.addWidget(self.hit_list)
        split.addWidget(hw)
        split.setSizes([800, 260])
        right.addWidget(split, 1)
        lay.addLayout(right, 1)
        self.refresh()
        self._set_enabled(False)

    # ---------------------------------------------------------------- biblioteka
    def refresh(self, select_id=None):
        lib = documents.load_library()
        if lib.get("warning"):
            self.banner.set("warn", lib["warning"])
        cur = select_id or (self.doc["id"] if self.doc else None)
        self.list.blockSignals(True)
        self.list.clear()
        row = None
        for i, d in enumerate(lib["documents"]):
            tag = "" if d["has_text"] else "  [bez warstwy tekstowej]"
            assigned = ", ".join(a["algorithm"] for a in d["assignments"])
            it = QListWidgetItem(f"{d['title']}{tag}\n{d['pages']} str. · {assigned or 'nieprzypisany'}")
            it.setData(Qt.UserRole, d["id"])
            self.list.addItem(it)
            if d["id"] == cur:
                row = i
        self.list.blockSignals(False)
        if row is not None:
            self.list.setCurrentRow(row)
        elif self.list.count() == 0:
            self._close()
            self.banner.set("info", "Biblioteka jest pusta. Zaimportuj publikację (PDF), na podstawie której "
                                    "zaimplementowano algorytm, np. arXiv:2306.17439 dla Unigram-Watermark.")

    def open_doc(self, doc_id):
        self.refresh(select_id=doc_id)

    def import_pdf(self):
        path, _ = QFileDialog.getOpenFileName(self, "Importuj dokument PDF", "", "Dokumenty PDF (*.pdf);;Wszystkie (*)")
        if not path:
            return
        job = self.state.start_job("pdf-import", lambda p, s: documents.import_pdf(path))
        if job is None:
            show_error(self, StegoLabError("Trwa inne zadanie.", "Poczekaj na jego zakończenie."))
            return
        self.banner.set("info", f"Importowanie {path}…")
        job.succeeded.connect(self._imported)
        job.failed.connect(lambda exc, tb: (self.banner.set("error", "Import nieudany."), show_error(self, exc, tb)))

    def _imported(self, doc):
        self.state.documents_changed.emit()
        self.refresh(select_id=doc["id"])

    def remove(self):
        if not self.doc:
            return
        if QMessageBox.question(self, "Usuń dokument",
                                f"Usunąć „{self.doc['title']}” z biblioteki? Plik oryginalny na dysku nie zostanie "
                                "usunięty.") != QMessageBox.Yes:
            return
        doc_id = self.doc["id"]
        self._close()
        documents.remove(doc_id)
        self.state.documents_changed.emit()
        self.refresh()

    def _close(self):
        if self.pdf is not None:
            self.pdf.close()
        self.pdf, self.doc, self.hits = None, None, []
        self.page_label.clear()
        self.text_view.clear()
        self.hit_list.clear()
        self.info_text.setText("")
        self.title_edit.clear()
        self.assignments.setText("")
        self._set_enabled(False)

    def _set_enabled(self, on):
        for w in (self.remove_btn, self.assign_card, self.tabs, self.query, self.title_edit):
            w.setEnabled(on)

    def _select(self, item, _prev=None):
        if item is None:
            return
        doc_id = item.data(Qt.UserRole)
        self._close()
        try:
            self.doc = documents.get(doc_id)
            self.pdf = documents.open_document(self.doc)
        except StegoLabError as exc:
            self.banner.set("error", f"{exc.message} {exc.hint}")
            return
        self._set_enabled(True)
        info = self.pdf.info()
        self.title_edit.setText(self.doc["title"])
        meta = [f"<b>Plik:</b> {self.doc['file']} ({info['size_bytes'] / 1024:.0f} kB, {info['pages']} str.)"]
        for key, name in (("title", "Tytuł (metadane)"), ("author", "Autor"), ("subject", "Temat"),
                          ("creation_date", "Utworzono"), ("producer", "Producent")):
            if info.get(key):
                meta.append(f"<b>{name}:</b> {info[key]}")
        meta.append(f"<b>Warstwa tekstowa:</b> {info['pages_with_text']}/{info['pages']} stron, "
                    f"{info['chars_total']} znaków")
        meta.append(f"<b>Zaimportowano:</b> {self.doc['added'].replace('T', ' ')} z {self.doc['original_path']}")
        self.info_text.setText("<br>".join(meta))
        if not info["has_text"]:
            self.banner.set("warn", "Ten PDF nie zawiera warstwy tekstowej (prawdopodobnie skan). Podgląd stron "
                                    "działa, ale wyszukiwanie i wyodrębnianie tekstu nie są możliwe. Rozwiązanie: "
                                    "wykonaj OCR zewnętrznym narzędziem (np. ocrmypdf) i zaimportuj wynik.")
        elif info["likely_scanned"]:
            self.banner.set("warn", f"Tylko {info['pages_with_text']} z {info['pages']} stron ma warstwę tekstową – "
                                    "część dokumentu to prawdopodobnie skany; wyszukiwanie obejmie tylko strony z tekstem.")
        else:
            self.banner.set("info", "")
        self.text_view.setPlainText(self.pdf.full_text() if info["has_text"] else
                                    "(Brak warstwy tekstowej – zob. podgląd stron.)")
        self.page_spin.setMaximum(self.pdf.page_count)
        self.page_total.setText(f"/ {self.pdf.page_count}")
        self._show_assignments()
        self.page = -1
        self.goto(0)

    def _save_title(self):
        if self.doc and self.title_edit.text().strip() and self.title_edit.text() != self.doc["title"]:
            self.doc = documents.update(self.doc["id"], title=self.title_edit.text().strip())
            self.state.documents_changed.emit()
            self.refresh()

    # ---------------------------------------------------------------- przypisania
    def _show_assignments(self):
        if not self.doc:
            return
        names = {aid: ad.spec.name for aid, ad in algorithms.available().items()}
        lines = [f"• {names.get(a['algorithm'], a['algorithm'])} – {a['role']}"
                 + (f", str. {a['pages']}" if a.get("pages") else "") + (f" ({a['note']})" if a.get("note") else "")
                 for a in self.doc["assignments"]]
        self.assignments.setText("Przypisania:\n" + "\n".join(lines) if lines else "Brak przypisań.")

    def assign(self):
        if not self.doc:
            return
        self.doc = documents.assign(self.doc["id"], self.a_algo.currentData(), self.a_role.currentText(),
                                    self.a_pages.text().strip(), self.a_note.text().strip())
        self._show_assignments()
        self.state.documents_changed.emit()
        self.refresh()

    def unassign(self):
        if not self.doc:
            return
        self.doc = documents.unassign(self.doc["id"], self.a_algo.currentData())
        self._show_assignments()
        self.state.documents_changed.emit()
        self.refresh()

    # ---------------------------------------------------------------- podgląd i wyszukiwanie
    def goto(self, index):
        if self.pdf is None or not 0 <= index < self.pdf.page_count:
            return
        self.page = index
        self.page_spin.blockSignals(True)
        self.page_spin.setValue(index + 1)
        self.page_spin.blockSignals(False)
        self.prev_btn.setEnabled(index > 0)
        self.next_btn.setEnabled(index < self.pdf.page_count - 1)
        self.render()

    def render(self):
        if self.pdf is None or self.page < 0:
            return
        rects = [r for h in self.hits if h.page == self.page for r in h.rects]
        try:
            w, h, data = self.pdf.render_page(self.page, self.zoom.value(), rects)
        except Exception as exc:
            self.page_label.setText(f"Nie udało się wyrenderować strony: {exc}")
            return
        img = QImage(data, w, h, 3 * w, QImage.Format_RGB888).copy()
        self.page_label.setPixmap(QPixmap.fromImage(img))

    def search(self):
        if self.pdf is None:
            return
        q = self.query.text().strip()
        self.hit_list.clear()
        self.hits = self.pdf.search(q) if q else []
        total = sum(len(h.rects) for h in self.hits)
        self.hit_label.setText(f"Wyniki: {total} trafień na {len(self.hits)} stronach" if q else "Wyniki wyszukiwania")
        for hit in self.hits:
            it = QListWidgetItem(f"Str. {hit.page + 1} ({len(hit.rects)}×)\n{hit.snippet}")
            it.setData(Qt.UserRole, hit.page)
            self.hit_list.addItem(it)
        if q and not self.hits:
            msg = "Brak trafień."
            if not self.doc["has_text"]:
                msg += " Dokument nie ma warstwy tekstowej, więc wyszukiwanie nie jest możliwe."
            self.hit_list.addItem(msg)
        if self.hits:
            self.goto(self.hits[0].page)
        else:
            self.render()

    def _hit_clicked(self, item):
        page = item.data(Qt.UserRole)
        if page is not None:
            self.tabs.setCurrentIndex(0)
            self.goto(page)
