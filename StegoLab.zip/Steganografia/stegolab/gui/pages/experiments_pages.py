"""Strony eksperymentów: demonstracja, test, porównanie."""
import difflib
import time

from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QHBoxLayout, QPlainTextEdit,
                               QPushButton, QScrollArea, QSpinBox, QTabWidget, QVBoxLayout, QWidget)

from ... import algorithms, experiments, history
from ...errors import StegoLabError
from ..results import (ComparisonResultView, DemoResultView, DetectResultView, ExportBar, TestResultView)
from ..widgets import (Banner, Card, ParamForm, ProgressPanel, RunSettingsForm, label, page_header, primary_button,
                       show_error)


class ExperimentPage(QWidget):
    """Wspólna obsługa: uruchomienie w tle, postęp, przerwanie, zapis do historii, eksport."""

    def __init__(self, state):
        super().__init__()
        self.state = state
        self.job = None
        self.record = None
        self.run_buttons = []
        state.busy_changed.connect(self._busy)

    def _busy(self, busy):
        for b in self.run_buttons:
            b.setEnabled(not busy)

    def model_or_error(self):
        if self.state.model is None:
            raise StegoLabError("Nie wczytano modelu językowego.", "Wybierz model przyciskiem „Zmień model”.")
        return self.state.model

    def launch(self, kind, title, algos, params, files, fn, on_result, progress_panel, model):
        record = history.new_record(kind, title, algos, params, files, model.describe())
        job = self.state.start_job(kind, fn)
        if job is None:
            show_error(self, StegoLabError("Trwa inne zadanie.", "Poczekaj na jego zakończenie lub je przerwij."))
            return None
        self.job = job
        progress_panel.start(f"{title}…")
        old = getattr(progress_panel, "_cancel_conn", None)
        if old is not None:
            progress_panel.cancel_requested.disconnect(old)
        progress_panel._cancel_conn = progress_panel.cancel_requested.connect(
            lambda: (job.cancel(), progress_panel.cancelling()))
        job.progress.connect(lambda f, m: progress_panel.update(f, m, job.elapsed))

        def ok(result):
            record.update(status="ok", duration_s=job.elapsed, result=result)
            self._store(record)
            on_result(result, record)

        def failed(exc, tb):
            record.update(status="error", duration_s=job.elapsed,
                          error={"message": str(exc), "type": type(exc).__name__, "traceback": tb})
            self._store(record)
            show_error(self, exc, tb)

        def cancelled(exc):
            done = getattr(exc, "completed", None)
            record.update(status="cancelled", duration_s=job.elapsed,
                          error={"message": "Przerwany przez użytkownika"
                                            + (f" po {done} poleceniach." if done is not None else ".")})
            self._store(record)
            self.on_cancel()

        job.succeeded.connect(ok)
        job.failed.connect(failed)
        job.cancelled.connect(cancelled)
        job.finished.connect(progress_panel.stop)
        return job

    def _store(self, record):
        try:
            self.state.save_record(record)
        except OSError as exc:
            show_error(self, StegoLabError(f"Nie udało się zapisać eksperymentu w historii: {exc}",
                                           "Sprawdź uprawnienia do katalogu stegolab_data."))

    def on_cancel(self):
        pass


def _algo_combo():
    combo = QComboBox()
    for aid, adapter in algorithms.available().items():
        combo.addItem(adapter.spec.name, aid)
    return combo


class ParamStack(QWidget):
    """Formularz parametrów zmieniany razem z wybranym algorytmem."""

    def __init__(self, combo):
        super().__init__()
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.forms = {}
        for i in range(combo.count()):
            aid = combo.itemData(i)
            f = ParamForm(algorithms.get(aid).spec)
            self.forms[aid] = f
            self.lay.addWidget(f)
        combo.currentIndexChanged.connect(lambda _: self.show_for(combo.currentData()))
        self.show_for(combo.currentData())

    def show_for(self, aid):
        for k, f in self.forms.items():
            f.setVisible(k == aid)

    def current(self, aid):
        return self.forms[aid]


def _scroll_page(inner):
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    inner.setObjectName("Content")
    scroll.setWidget(inner)
    return scroll


# ------------------------------------------------------------------ DEMO
class DemoPage(ExperimentPage):
    def __init__(self, state):
        super().__init__(state)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        inner = QWidget()
        outer.addWidget(_scroll_page(inner))
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(12)
        lay.addLayout(page_header("Demonstracja", "Kodowanie (generacja ze znakiem) → dekodowanie (detekcja) dla "
                                                  "jednego polecenia, z porównaniem do tekstu bez znaku"))
        top = QHBoxLayout()
        top.addWidget(label("Algorytm:", "H3"))
        self.algo = _algo_combo()
        top.addWidget(self.algo)
        top.addStretch(1)
        lay.addLayout(top)
        self.params = ParamStack(self.algo)
        lay.addWidget(self.params)

        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)
        self._build_generate_tab()
        self._build_detect_tab()

    # --- zakładka 1: generacja i detekcja
    def _build_generate_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        inp = QHBoxLayout()
        col = QVBoxLayout()
        col.addWidget(label("Polecenie (prompt) dla modelu", "H3"))
        self.prompt = QPlainTextEdit("Is it possible to fail several times and succeed once?")
        self.prompt.setMaximumHeight(70)
        col.addWidget(self.prompt)
        inp.addLayout(col, 1)
        opts = QVBoxLayout()
        self.max_tokens = QSpinBox()
        self.max_tokens.setRange(1, 2000)
        self.max_tokens.setValue(120)
        self.seed = QSpinBox()
        self.seed.setRange(0, 1_000_000)
        self.seed.setValue(1)
        r1 = QHBoxLayout()
        r1.addWidget(label("Maks. tokenów"))
        r1.addWidget(self.max_tokens)
        r1.addWidget(label("Ziarno"))
        r1.addWidget(self.seed)
        opts.addLayout(r1)
        r2 = QHBoxLayout()
        load = QPushButton("Wczytaj polecenie z pliku…")
        load.clicked.connect(self._load_prompt)
        self.run_btn = primary_button("Generuj i wykryj")
        self.run_btn.clicked.connect(self.run_demo)
        self.run_buttons.append(self.run_btn)
        r2.addWidget(load)
        r2.addWidget(self.run_btn)
        opts.addLayout(r2)
        inp.addLayout(opts)
        lay.addLayout(inp)
        self.progress = ProgressPanel()
        lay.addWidget(self.progress)
        self.export = ExportBar(self.state)
        lay.addWidget(self.export)
        self.result_view = DemoResultView()
        self.result_view.setMinimumHeight(560)
        self.result_view.setVisible(False)
        lay.addWidget(self.result_view, 1)

        # analiza zmian tekstu: porównanie wyniku dla oryginału i wersji zmodyfikowanej
        self.edit_card = Card("Modyfikacja tekstu ze znakiem i ponowna detekcja")
        self.edit_card.body.addWidget(label("Edytuj tekst ręcznie lub zastosuj losowe edycje tokenów (funkcja "
                                            "random_edits z repozytorium), a następnie wykryj znak ponownie. Wynik "
                                            "jest porównywany z detekcją tekstu oryginalnego.", "Small"))
        self.edit_text = QPlainTextEdit()
        self.edit_text.setMinimumHeight(110)
        self.edit_card.body.addWidget(self.edit_text)
        row = QHBoxLayout()
        self.edit_frac = QDoubleSpinBox()
        self.edit_frac.setRange(0, 1)
        self.edit_frac.setSingleStep(0.05)
        self.edit_frac.setValue(0.2)
        rnd = QPushButton("Zastosuj losowe edycje")
        rnd.clicked.connect(self._random_edit)
        restore = QPushButton("Przywróć oryginał")
        restore.clicked.connect(lambda: self.edit_text.setPlainText(self.last_demo["watermarked"]["text"]))
        self.redetect_btn = primary_button("Wykryj ponownie")
        self.redetect_btn.clicked.connect(self._redetect)
        self.run_buttons.append(self.redetect_btn)
        row.addWidget(label("Ułamek edytowanych tokenów"))
        row.addWidget(self.edit_frac)
        row.addWidget(rnd)
        row.addWidget(restore)
        row.addStretch(1)
        row.addWidget(self.redetect_btn)
        self.edit_card.body.addLayout(row)
        self.edit_result = Banner()
        self.edit_card.body.addWidget(self.edit_result)
        self.edit_card.setVisible(False)
        lay.addWidget(self.edit_card)
        self.last_demo = None
        self.tabs.addTab(w, "Generacja i detekcja")

    def _load_prompt(self):
        path, _ = QFileDialog.getOpenFileName(self, "Polecenie", "", "Pliki tekstowe (*.txt);;Wszystkie (*)")
        if not path:
            return
        try:
            self.prompt.setPlainText(experiments.read_text_file(path).strip())
        except StegoLabError as exc:
            show_error(self, exc)

    def run_demo(self):
        try:
            lm = self.model_or_error()
            aid = self.algo.currentData()
            params = self.params.current(aid).validated()
            prompt = self.prompt.toPlainText().strip()
            if not prompt:
                raise StegoLabError("Polecenie jest puste.", "Wpisz polecenie dla modelu językowego.")
        except StegoLabError as exc:
            show_error(self, exc)
            return
        n, seed = self.max_tokens.value(), self.seed.value()
        name = algorithms.get(aid).spec.name
        fn = lambda progress, stop: experiments.run_demo(lm, aid, params, prompt, n, seed, progress, stop)  # noqa
        self.launch("demo", f"Demonstracja: {name}", [aid], params, [], fn, self._show_demo, self.progress, lm)

    def _show_demo(self, result, record):
        self.last_demo = result
        self.result_view.set_result(result)
        self.result_view.setVisible(True)
        self.export.set_record(record)
        self.edit_text.setPlainText(result["watermarked"]["text"])
        self.edit_result.set("info", "")
        self.edit_card.setVisible(True)

    def _random_edit(self):
        if not self.last_demo:
            return
        try:
            edited = experiments.random_edit_text(self.state.model, self.edit_text.toPlainText(),
                                                  self.edit_frac.value(), seed=int(time.time()) % 100000)
            self.edit_text.setPlainText(edited)
        except StegoLabError as exc:
            show_error(self, exc)

    def _redetect(self):
        if not self.last_demo:
            return
        lm = self.state.model
        demo = self.last_demo
        text = self.edit_text.toPlainText()
        aid, params = demo["algorithm"], demo["params"]
        if lm.describe().get("vocab_size") != demo["model"].get("vocab_size") or lm.name != demo["model"]["name"]:
            show_error(self, StegoLabError("Od czasu demonstracji zmieniono model językowy.",
                                           "Detekcja wymaga tego samego tokenizera – wygeneruj tekst ponownie."))
            return
        job = self.state.start_job("redetect", lambda p, s: experiments.detect_text(lm, aid, params, text))
        if job is None:
            return
        job.succeeded.connect(self._show_redetect)
        job.failed.connect(lambda exc, tb: show_error(self, exc, tb))

    def _show_redetect(self, res):
        orig = self.last_demo["watermarked"]["detection"]
        d = res["detection"]
        a, b = self.last_demo["watermarked"]["tokens"], res["tokens"]
        # wyrównanie sekwencji (wstawienia/usunięcia przesuwają pozycje, więc porównanie pozycyjne by kłamało)
        kept = sum(m.size for m in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks())
        msg = (f"Oryginał: z = {orig['z']:.2f} ({'wykryty' if orig['watermarked'] else 'nie wykryty'}), "
               f"{len(a)} tokenów.  Po zmianach: z = {d['z']:.2f} ({'wykryty' if d['watermarked'] else 'NIE wykryty'}), "
               f"{len(b)} tokenów, z czego {kept} zachowanych z oryginału (dopasowanie sekwencji). "
               f"Próg z = {d['threshold']:g}.")
        self.edit_result.set("ok" if d["watermarked"] else "warn", msg)

    # --- zakładka 2: detekcja dowolnego tekstu
    def _build_detect_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(label("Wklej tekst albo wczytaj plik .txt. Detekcja używa klucza i parametrów z formularza "
                            "powyżej oraz tokenizera aktywnego modelu (musi być ten sam, co przy generacji).", "Muted"))
        self.detect_input = QPlainTextEdit()
        self.detect_input.setPlaceholderText("Tekst do sprawdzenia…")
        self.detect_input.setMinimumHeight(140)
        lay.addWidget(self.detect_input)
        row = QHBoxLayout()
        load = QPushButton("Wczytaj z pliku…")
        load.clicked.connect(self._load_detect)
        self.detect_btn = primary_button("Wykryj znak")
        self.detect_btn.clicked.connect(self.run_detect)
        self.run_buttons.append(self.detect_btn)
        row.addWidget(load)
        row.addStretch(1)
        row.addWidget(self.detect_btn)
        lay.addLayout(row)
        self.detect_progress = ProgressPanel()
        lay.addWidget(self.detect_progress)
        self.detect_export = ExportBar(self.state)
        lay.addWidget(self.detect_export)
        self.detect_view = DetectResultView()
        self.detect_view.setMinimumHeight(420)
        self.detect_view.setVisible(False)
        lay.addWidget(self.detect_view, 1)
        self.detect_file = None
        self.tabs.addTab(w, "Detekcja dowolnego tekstu")

    def _load_detect(self):
        path, _ = QFileDialog.getOpenFileName(self, "Tekst do detekcji", "", "Pliki tekstowe (*.txt);;Wszystkie (*)")
        if not path:
            return
        try:
            self.detect_input.setPlainText(experiments.read_text_file(path))
            self.detect_file = path
        except StegoLabError as exc:
            show_error(self, exc)

    def run_detect(self):
        try:
            lm = self.model_or_error()
            aid = self.algo.currentData()
            params = self.params.current(aid).validated()
        except StegoLabError as exc:
            show_error(self, exc)
            return
        text = self.detect_input.toPlainText()
        files = [self.detect_file] if self.detect_file else []
        fn = lambda progress, stop: experiments.detect_text(lm, aid, params, text)  # noqa: E731
        self.launch("detect", f"Detekcja tekstu: {algorithms.get(aid).spec.name}", [aid], params, files, fn,
                    self._show_detect, self.detect_progress, lm)

    def _show_detect(self, result, record):
        self.detect_view.set_result(result)
        self.detect_view.setVisible(True)
        self.detect_export.set_record(record)

    def select(self, algo_id):
        i = self.algo.findData(algo_id)
        if i >= 0:
            self.algo.setCurrentIndex(i)


# ------------------------------------------------------------------ TEST
class TestPage(ExperimentPage):
    def __init__(self, state):
        super().__init__(state)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        inner = QWidget()
        outer.addWidget(_scroll_page(inner))
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(12)
        lay.addLayout(page_header("Tryb testowy", "Seria tekstów ze znakiem i bez znaku: skuteczność detekcji, "
                                                  "jakość, czas i odporność na edycje"))
        top = QHBoxLayout()
        top.addWidget(label("Algorytm:", "H3"))
        self.algo = _algo_combo()
        top.addWidget(self.algo)
        top.addStretch(1)
        lay.addLayout(top)
        self.params = ParamStack(self.algo)
        lay.addWidget(self.params)
        self.settings = RunSettingsForm()
        lay.addWidget(self.settings)
        row = QHBoxLayout()
        self.estimate = label("", "Small")
        row.addWidget(self.estimate, 1)
        self.run_btn = primary_button("Uruchom test")
        self.run_btn.clicked.connect(self.run)
        self.run_buttons.append(self.run_btn)
        row.addWidget(self.run_btn)
        lay.addLayout(row)
        self.progress = ProgressPanel()
        lay.addWidget(self.progress)
        self.notice = Banner()
        lay.addWidget(self.notice)
        self.export = ExportBar(self.state)
        lay.addWidget(self.export)
        self.view = TestResultView()
        self.view.setMinimumHeight(700)
        self.view.setVisible(False)
        lay.addWidget(self.view, 1)
        for sig in (self.settings.count.valueChanged, self.settings.max_tokens.valueChanged):
            sig.connect(self._update_estimate)
        state.model_changed.connect(lambda _: self._update_estimate())
        self._update_estimate()

    def _update_estimate(self):
        n = self.settings.count.value()
        lm = self.state.model
        txt = f"Zostanie wygenerowanych {2 * n} tekstów po maks. {self.settings.max_tokens.value()} tokenów."
        if lm is not None and lm.kind == "hf" and lm.device == "cpu":
            txt += " Model działa na CPU – długi test może potrwać kilka–kilkanaście minut (można go przerwać)."
        self.estimate.setText(txt)

    def run(self):
        try:
            lm = self.model_or_error()
            aid = self.algo.currentData()
            params = self.params.current(aid).validated()
            settings, files = self.settings.collect()
        except StegoLabError as exc:
            show_error(self, exc)
            return
        self.notice.set("info", "")
        name = algorithms.get(aid).spec.name
        fn = lambda progress, stop: experiments.run_test(lm, aid, params, settings, progress, stop)  # noqa: E731
        self.launch("test", f"Test: {name} ({len(settings['prompts'])} poleceń, {settings['max_new_tokens']} tok.)",
                    [aid], params, files, fn, self._show, self.progress, lm)

    def _show(self, result, record):
        self.view.set_result(result)
        self.view.setVisible(True)
        self.export.set_record(record)

    def on_cancel(self):
        self.notice.set("warn", "Test przerwany. Częściowy przebieg zapisano w historii ze statusem „Przerwany”.")

    def select(self, algo_id):
        i = self.algo.findData(algo_id)
        if i >= 0:
            self.algo.setCurrentIndex(i)


# ------------------------------------------------------------------ PORÓWNANIE
class ComparePage(ExperimentPage):
    def __init__(self, state):
        super().__init__(state)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        inner = QWidget()
        outer.addWidget(_scroll_page(inner))
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(12)
        lay.addLayout(page_header("Porównanie algorytmów", "Ten sam model, te same polecenia, ziarna i długość "
                                                           "tekstu – warunki porównania są zapisywane w wynikach"))
        self.includes = {}
        self.forms = {}
        tabs = QTabWidget()
        for aid, adapter in algorithms.available().items():
            w = QWidget()
            wl = QVBoxLayout(w)
            cb = QCheckBox(f"Uwzględnij {adapter.spec.name}")
            cb.setChecked(True)
            wl.addWidget(cb)
            form = ParamForm(adapter.spec)
            wl.addWidget(form)
            self.includes[aid] = cb
            self.forms[aid] = form
            tabs.addTab(w, adapter.spec.name)
        lay.addWidget(tabs)
        self.settings = RunSettingsForm()
        self.settings.count.setValue(10)
        lay.addWidget(self.settings)
        row = QHBoxLayout()
        row.addWidget(label("Każdy algorytm porównywany jest z własną linią bazową bez znaku. Różne progi i "
                            "sposoby próbkowania są jawnie oznaczane w wynikach.", "Small"), 1)
        self.run_btn = primary_button("Uruchom porównanie")
        self.run_btn.clicked.connect(self.run)
        self.run_buttons.append(self.run_btn)
        row.addWidget(self.run_btn)
        lay.addLayout(row)
        self.progress = ProgressPanel()
        lay.addWidget(self.progress)
        self.notice = Banner()
        lay.addWidget(self.notice)
        self.export = ExportBar(self.state)
        lay.addWidget(self.export)
        self.view = ComparisonResultView()
        self.view.setMinimumHeight(760)
        self.view.setVisible(False)
        lay.addWidget(self.view, 1)

    def run(self):
        try:
            lm = self.model_or_error()
            configs = [(aid, self.forms[aid].validated()) for aid, cb in self.includes.items() if cb.isChecked()]
            settings, files = self.settings.collect()
            if len(configs) < 2:
                raise StegoLabError("Zaznacz co najmniej dwa algorytmy.", "Porównanie wymaga ≥ 2 konfiguracji.")
        except StegoLabError as exc:
            show_error(self, exc)
            return
        self.notice.set("info", "")
        fn = lambda progress, stop: experiments.run_comparison(lm, configs, settings, progress, stop)  # noqa: E731
        names = " vs ".join(algorithms.get(a).spec.name.split(" (")[0] for a, _ in configs)
        self.launch("comparison", f"Porównanie: {names} ({len(settings['prompts'])} poleceń)",
                    [a for a, _ in configs], {a: p for a, p in configs}, files, fn, self._show, self.progress, lm)

    def _show(self, result, record):
        self.view.set_result(result)
        self.view.setVisible(True)
        self.export.set_record(record)

    def on_cancel(self):
        self.notice.set("warn", "Porównanie przerwane. Wpis zapisano w historii ze statusem „Przerwany”.")

    def select(self, algo_id):
        pass
