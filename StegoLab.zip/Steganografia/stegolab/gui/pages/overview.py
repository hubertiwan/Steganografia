"""Panel główny i strona opisu algorytmów."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QGridLayout, QHBoxLayout, QHeaderView, QListWidget,
                               QListWidgetItem, QScrollArea, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from ... import APP_NAME, algorithms, documents, history
from ...history import KIND_LABELS, STATUS_LABELS
from ..widgets import Banner, Card, MetricTable, label, link_button, page_header, primary_button


from ..widgets import clear_layout as _clear  # noqa: E402


def _dot_icon(color):
    from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap
    pm = QPixmap(14, 14)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor(color))
    p.setPen(Qt.NoPen)
    p.drawEllipse(2, 2, 10, 10)
    p.end()
    return QIcon(pm)


def _dot(color):
    return f"<span style='color:{color}; font-size:14pt'>●</span>"


class DashboardPage(QWidget):
    def __init__(self, state):
        super().__init__()
        self.state = state
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        body = QWidget()
        body.setObjectName("Content")
        scroll.setWidget(body)
        lay = QVBoxLayout(body)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)
        lay.addLayout(page_header(f"{APP_NAME} — znakowanie wodne tekstu generowanego przez LLM",
                                  "Narzędzie do demonstracji, testowania i analizy algorytmów z repozytorium "
                                  "Steganografia (praca inżynierska)."))
        about = Card()
        about.body.addWidget(label(
            "Algorytmy w repozytorium ukrywają w tekście tworzonym przez model językowy niewidoczny dla czytelnika "
            "znak wodny – statystyczny ślad wyboru tokenów zależny od tajnego klucza. Właściciel klucza wykrywa go "
            "testem statystycznym (z-score), bez dostępu do modelu. Jest to steganografia lingwistyczna typu "
            "„zero-bit”: osadzany jest jeden bit – informacja, że tekst pochodzi z oznaczonego modelu.", "Muted"))
        lay.addWidget(about)
        self.model_banner = Banner(level="info")
        lay.addWidget(self.model_banner)

        lay.addWidget(label("Algorytmy z repozytorium", "H2"))
        self.algo_grid = QGridLayout()
        self.algo_grid.setSpacing(14)
        lay.addLayout(self.algo_grid)

        lay.addWidget(label("Ostatnie eksperymenty", "H2"))
        stats = QHBoxLayout()
        self.stat_total = self._stat("Wszystkie eksperymenty")
        self.stat_ok = self._stat("Zakończone poprawnie")
        self.stat_docs = self._stat("Dokumenty źródłowe")
        for c in (self.stat_total, self.stat_ok, self.stat_docs):
            stats.addWidget(c)
        lay.addLayout(stats)
        self.recent = QTableWidget(0, 5)
        self.recent.setHorizontalHeaderLabels(["Data", "Rodzaj", "Opis", "Model", "Status"])
        self.recent.verticalHeader().setVisible(False)
        self.recent.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.recent.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.recent.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.recent.setMinimumHeight(220)
        self.recent.cellDoubleClicked.connect(self._open_recent)
        lay.addWidget(self.recent)
        lay.addWidget(label("Dwuklik otwiera eksperyment w historii.", "Small"))
        lay.addStretch(1)

        state.history_changed.connect(self.refresh)
        state.documents_changed.connect(self.refresh)
        state.model_changed.connect(self._model_info)
        self.refresh()

    def _stat(self, title):
        c = Card()
        c.body.setSpacing(2)
        c.body.addWidget(label(title, "Small"))
        c.value = label("0", "BigNumber")
        c.body.addWidget(c.value)
        return c

    def _model_info(self, lm):
        if lm is None:
            return
        if lm.kind == "synthetic":
            self.model_banner.set("warn", f"Aktywny model: {lm.label}. Służy do szybkich eksperymentów statystycznych; "
                                          "do wyników w pracy wczytaj rzeczywisty model (przycisk „Zmień model” w "
                                          "panelu bocznym, domyślnie Qwen/Qwen2.5-0.5B-Instruct jak w demo.py).")
        else:
            self.model_banner.set("ok", f"Aktywny model: {lm.label}, słownik |V| = {lm.vocab_size}.")

    def refresh(self):
        _clear(self.algo_grid)
        for i, (aid, adapter) in enumerate(algorithms.available().items()):
            spec = adapter.spec
            c = Card()
            c.body.addWidget(label(f"{_dot(spec.color)} <b>{spec.name}</b>", wrap=True))
            c.body.addWidget(label(spec.short, "Muted"))
            c.body.addWidget(label(spec.paper, "Small"))
            docs = documents.documents_for(aid)
            c.body.addWidget(label(f"Dokumenty źródłowe: {len(docs)}" if docs else
                                   "Brak przypisanego dokumentu źródłowego", "Small"))
            row = QHBoxLayout()
            b1 = primary_button("Demonstracja")
            b1.clicked.connect(lambda _=False, a=aid: self.state.navigate.emit("demo", a))
            b2 = link_button("Test")
            b2.clicked.connect(lambda _=False, a=aid: self.state.navigate.emit("test", a))
            b3 = link_button("Opis algorytmu")
            b3.clicked.connect(lambda _=False, a=aid: self.state.navigate.emit("algorithms", a))
            row.addWidget(b1)
            row.addWidget(b2)
            row.addWidget(b3)
            row.addStretch(1)
            c.body.addLayout(row)
            self.algo_grid.addWidget(c, 0, i)
        for j, (aid, (pkg, reason, _)) in enumerate(algorithms.unavailable().items()):
            c = Card()
            c.body.addWidget(label(f"<b>{pkg}</b> – niedostępny"))
            c.body.addWidget(label(reason, "Small"))
            self.algo_grid.addWidget(c, 1, j)

        recs = history.list_records()
        self.stat_total.value.setText(str(len(recs)))
        self.stat_ok.value.setText(str(sum(r.get("status") == "ok" for r in recs)))
        self.stat_docs.value.setText(str(len(documents.load_library()["documents"])))
        recent = recs[:8]
        self.recent.setRowCount(len(recent))
        for r, rec in enumerate(recent):
            m = rec.get("model") or {}
            model = "syntetyczny" if m.get("kind") == "synthetic" else m.get("name", "–")
            vals = [rec.get("created", "").replace("T", " "), KIND_LABELS.get(rec.get("kind"), rec.get("kind")),
                    rec.get("title", ""), model, STATUS_LABELS.get(rec.get("status"), rec.get("status"))]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(str(v))
                item.setData(Qt.UserRole, rec.get("id"))
                self.recent.setItem(r, c, item)
        self.recent.resizeColumnsToContents()
        self.recent.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)

    def _open_recent(self, row, _col):
        item = self.recent.item(row, 0)
        if item:
            self.state.navigate.emit("history", item.data(Qt.UserRole))


class AlgorithmsPage(QWidget):
    def __init__(self, state):
        super().__init__()
        self.state = state
        lay = QHBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(18)
        left = QVBoxLayout()
        left.addLayout(page_header("Algorytmy", "Lista z pakietów repozytorium"))
        self.list = QListWidget()
        self.list.setFixedWidth(280)
        self.list.currentItemChanged.connect(self._show)
        left.addWidget(self.list, 1)
        lay.addLayout(left)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.detail = QWidget()
        self.detail.setObjectName("Content")
        self.dl = QVBoxLayout(self.detail)
        self.dl.setSpacing(12)
        scroll.setWidget(self.detail)
        lay.addWidget(scroll, 1)
        for aid, adapter in algorithms.available().items():
            it = QListWidgetItem(_dot_icon(adapter.spec.color), adapter.spec.name)
            it.setData(Qt.UserRole, aid)
            self.list.addItem(it)
        for aid, (pkg, reason, _) in algorithms.unavailable().items():
            it = QListWidgetItem(f"✗  {pkg} (niedostępny)")
            it.setData(Qt.UserRole, "!" + aid)
            self.list.addItem(it)
        state.documents_changed.connect(lambda: self._show(self.list.currentItem()))
        if self.list.count():
            self.list.setCurrentRow(0)

    def select(self, algo_id):
        for i in range(self.list.count()):
            if self.list.item(i).data(Qt.UserRole) == algo_id:
                self.list.setCurrentRow(i)

    def _show(self, item, _prev=None):
        _clear(self.dl)
        if item is None:
            return
        aid = item.data(Qt.UserRole)
        if aid.startswith("!"):
            pkg, reason, tb = algorithms.unavailable()[aid[1:]]
            self.dl.addWidget(label(f"Pakiet {pkg} nie mógł zostać zaimportowany", "H2"))
            self.dl.addWidget(Banner(reason, "error"))
            self.dl.addWidget(label(tb, "Small", selectable=True))
            self.dl.addStretch(1)
            return
        spec = algorithms.get(aid).spec
        self.dl.addWidget(label(f"{_dot(spec.color)} {spec.name}", "PageTitle"))
        self.dl.addWidget(label(spec.paper, "Muted", selectable=True))
        self.dl.addWidget(label(f"Implementacja: {spec.source_package}", "Small", selectable=True))
        row = QHBoxLayout()
        b1 = primary_button("Uruchom demonstrację")
        b1.clicked.connect(lambda: self.state.navigate.emit("demo", aid))
        b2 = link_button("Przetestuj")
        b2.clicked.connect(lambda: self.state.navigate.emit("test", aid))
        b3 = link_button("Porównaj")
        b3.clicked.connect(lambda: self.state.navigate.emit("compare", aid))
        for b in (b1, b2, b3):
            row.addWidget(b)
        row.addStretch(1)
        self.dl.addLayout(row)

        def section(title, content):
            c = Card(title)
            if isinstance(content, str):
                c.body.addWidget(label(content, selectable=True))
            elif isinstance(content, list):
                c.body.addWidget(label("<br>".join(f"• {x}" for x in content), selectable=True))
            else:
                c.body.addWidget(content)
            self.dl.addWidget(c)

        section("Opis", spec.description)
        section("Zasada działania", "<br>".join(f"<b>{i + 1}.</b> {x}" for i, x in enumerate(spec.principle)))
        two = QHBoxLayout()
        c1, c2 = Card("Kodowanie (osadzanie znaku)"), Card("Dekodowanie (detekcja)")
        c1.body.addWidget(label(spec.embedding))
        c2.body.addWidget(label(spec.detection))
        two.addWidget(c1)
        two.addWidget(c2)
        self.dl.addLayout(two)
        params = MetricTable(("Parametr", "Domyślnie", "Opis"))
        params.set_rows([(p.label, p.default, p.help) for p in spec.params])
        params.setMinimumHeight(min(60 + 34 * len(spec.params), 340))
        section("Parametry", params)
        section("Wymagane dane wejściowe", spec.inputs)
        section("Obsługiwane formaty", spec.formats)
        section("Dostępne operacje", spec.operations)
        section("Metryki oceny", spec.metrics)
        section("Metryki nieadekwatne dla tego algorytmu (celowo nie liczone)", spec.not_applicable)
        section("Ograniczenia", spec.limitations)

        docs = documents.documents_for(aid)
        c = Card("Dokumenty źródłowe (przypisane przez użytkownika)")
        if not docs:
            c.body.addWidget(label("Brak. Zaimportuj publikację w zakładce „Dokumenty PDF” i przypisz ją do "
                                   "algorytmu.", "Muted"))
        for doc, a in docs:
            pages = f", strony: {a['pages']}" if a.get("pages") else ""
            note = f" – {a['note']}" if a.get("note") else ""
            c.body.addWidget(label(f"<b>{doc['title']}</b> ({doc['file']}, {doc['pages']} str.)<br>"
                                   f"<span style='color:#55534e'>{a['role']}{pages}{note}</span>"))
            b = link_button("Otwórz dokument")
            b.clicked.connect(lambda _=False, d=doc["id"]: self.state.navigate.emit("documents", d))
            c.body.addWidget(b)
        c.body.addWidget(label("Dokument jest materiałem referencyjnym wskazanym przez użytkownika – aplikacja "
                               "nie weryfikuje jego zgodności z implementacją.", "Small"))
        self.dl.addWidget(c)
        self.dl.addStretch(1)
