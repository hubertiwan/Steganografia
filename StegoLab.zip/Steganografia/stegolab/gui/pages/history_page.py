"""Historia eksperymentów: lista, filtrowanie, ponowne wyświetlenie wyników, eksport, usuwanie."""
import json

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QHBoxLayout, QHeaderView, QLineEdit, QMessageBox,
                               QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from ... import history
from ...history import KIND_LABELS, STATUS_LABELS
from ...paths import experiments_dir
from ..results import ExportBar, view_for
from ..widgets import Banner, MetricTable, clear_layout, page_header, show_error


class HistoryPage(QWidget):
    def __init__(self, state):
        super().__init__()
        self.state = state
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(10)
        lay.addLayout(page_header("Historia eksperymentów", f"Zapis w katalogu {experiments_dir()}"))
        filters = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItem("Wszystkie rodzaje", None)
        for k, v in KIND_LABELS.items():
            self.kind.addItem(v, k)
        self.status = QComboBox()
        self.status.addItem("Każdy status", None)
        for k, v in STATUS_LABELS.items():
            self.status.addItem(v, k)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Szukaj w opisie, algorytmie, modelu…")
        for w in (self.kind, self.status):
            w.currentIndexChanged.connect(self.refresh)
        self.search.textChanged.connect(self.refresh)
        filters.addWidget(self.kind)
        filters.addWidget(self.status)
        filters.addWidget(self.search, 1)
        lay.addLayout(filters)

        split = QSplitter(Qt.Vertical)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Data i godzina", "Rodzaj", "Opis", "Model", "Status", "Czas [s]"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.itemSelectionChanged.connect(self._selected)
        split.addWidget(self.table)

        detail = QWidget()
        detail.setObjectName("Content")
        dl = QVBoxLayout(detail)
        dl.setContentsMargins(0, 8, 0, 0)
        bar = QHBoxLayout()
        self.export = ExportBar(state)
        bar.addWidget(self.export, 1)
        self.delete_btn = QPushButton("Usuń wpis")
        self.delete_btn.setObjectName("Danger")
        self.delete_btn.clicked.connect(self._delete)
        bar.addWidget(self.delete_btn)
        dl.addLayout(bar)
        self.meta = MetricTable(("Pole", "Wartość"))
        self.meta.setFixedHeight(300)
        dl.addWidget(self.meta)
        self.error_banner = Banner()
        dl.addWidget(self.error_banner)
        self.result_holder = QVBoxLayout()
        dl.addLayout(self.result_holder, 1)
        detail_scroll = QScrollArea()
        detail_scroll.setWidgetResizable(True)
        detail_scroll.setWidget(detail)
        split.addWidget(detail_scroll)
        split.setSizes([230, 730])
        lay.addWidget(split, 1)
        self.current = None
        state.history_changed.connect(self.refresh)
        self.refresh()
        self._show(None)

    def refresh(self):
        keep = self.current["id"] if self.current else None
        q = self.search.text().strip().lower()
        recs = []
        for r in history.list_records():
            if self.kind.currentData() and r.get("kind") != self.kind.currentData():
                continue
            if self.status.currentData() and r.get("status") != self.status.currentData():
                continue
            if q and q not in json.dumps(r, ensure_ascii=False).lower():
                continue
            recs.append(r)
        self.table.blockSignals(True)
        self.table.setRowCount(len(recs))
        select_row = None
        for i, r in enumerate(recs):
            m = r.get("model") or {}
            model = "syntetyczny" if m.get("kind") == "synthetic" else m.get("name", "–")
            vals = [r.get("created", "").replace("T", " "), KIND_LABELS.get(r.get("kind"), r.get("kind")),
                    r.get("title", ""), model, STATUS_LABELS.get(r.get("status"), r.get("status")),
                    f"{r['duration_s']:.1f}" if r.get("duration_s") else "–"]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                it.setData(Qt.UserRole, r["id"])
                self.table.setItem(i, c, it)
            if r["id"] == keep:
                select_row = i
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.blockSignals(False)
        if select_row is not None:
            self.table.selectRow(select_row)

    def open(self, record_id):
        for i in range(self.table.rowCount()):
            if self.table.item(i, 0).data(Qt.UserRole) == record_id:
                self.table.selectRow(i)
                return

    def _selected(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        rid = self.table.item(rows[0].row(), 0).data(Qt.UserRole)
        if self.current and self.current["id"] == rid:
            return
        try:
            self._show(history.load(rid))
        except (OSError, json.JSONDecodeError) as exc:
            self._show(None)
            self.error_banner.set("error", f"Nie można odczytać wpisu: {exc}")

    def _show(self, rec):
        self.current = rec
        clear_layout(self.result_holder)
        self.export.set_record(rec)
        self.delete_btn.setEnabled(rec is not None)
        if rec is None:
            self.meta.set_rows([])
            self.error_banner.set("info", "Wybierz eksperyment z listy, aby zobaczyć jego wyniki.")
            return
        m = rec.get("model") or {}
        params = rec.get("params") or {}
        rows = [("Data i godzina", rec["created"].replace("T", " ")), ("Rodzaj", KIND_LABELS.get(rec["kind"], rec["kind"])),
                ("Algorytm(y)", ", ".join(rec.get("algorithms", []))),
                ("Model", m.get("name") if m.get("kind") != "synthetic" else
                 f"syntetyczny (|V| = {m.get('vocab_size')}, s = {m.get('spread')})"),
                ("Parametry", json.dumps(params, ensure_ascii=False)),
                ("Pliki wejściowe", "; ".join(rec.get("files") or []) or "–"),
                ("Status", STATUS_LABELS.get(rec["status"], rec["status"])),
                ("Czas trwania", f"{rec['duration_s']:.2f} s" if rec.get("duration_s") else "–")]
        self.meta.set_rows(rows)
        if rec.get("error"):
            self.error_banner.set("warn" if rec["status"] == "cancelled" else "error", rec["error"].get("message", ""))
            if rec["error"].get("traceback"):
                tb = QPlainTextEdit(rec["error"]["traceback"], readOnly=True)
                self.result_holder.addWidget(tb)
        else:
            self.error_banner.set("info", "")
        if rec.get("result"):
            try:
                self.result_holder.addWidget(view_for(rec["result"]))
            except Exception as exc:  # np. plik z innej wersji aplikacji
                self.error_banner.set("error", f"Nie można wyświetlić wyników: {type(exc).__name__}: {exc}")

    def _delete(self):
        if not self.current:
            return
        ans = QMessageBox.question(self, "Usuń wpis", f"Usunąć eksperyment „{self.current['title']}” z historii?")
        if ans != QMessageBox.Yes:
            return
        try:
            history.delete(self.current["id"])
        except OSError as exc:
            show_error(self, exc)
        self._show(None)
        self.state.history_changed.emit()
