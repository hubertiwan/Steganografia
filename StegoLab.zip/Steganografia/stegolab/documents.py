"""Biblioteka dokumentów źródłowych (PDF) i ich przypisań do algorytmów.

Każdy zaimportowany PDF jest kopiowany do stegolab_data/documents/ (aplikacja działa
dalej nawet po przeniesieniu oryginału), a metadane trafiają do library.json.
Przypisanie dokumentu do algorytmu jest deklaracją użytkownika („ten materiał był podstawą
implementacji”) – aplikacja nie sprawdza merytorycznie treści dokumentu.
"""
import hashlib
import json
import shutil
import uuid
from datetime import datetime
from pathlib import Path

from .errors import InputError, PdfError
from .paths import documents_dir
from .pdf_reader import PdfDocument

ROLES = ["Publikacja źródłowa algorytmu", "Dokumentacja / instrukcja do zajęć", "Materiał uzupełniający"]


def _library_path() -> Path:
    return documents_dir() / "library.json"


def load_library() -> dict:
    path = _library_path()
    if not path.exists():
        return {"documents": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        data.setdefault("documents", [])
        return data
    except json.JSONDecodeError:
        backup = path.with_suffix(".corrupt.json")
        shutil.copy2(path, backup)
        return {"documents": [], "warning": f"Plik biblioteki był uszkodzony; kopia: {backup.name}"}


def save_library(data: dict):
    path = _library_path()
    tmp = path.with_suffix(".tmp")
    data = {k: v for k, v in data.items() if k != "warning"}
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_pdf(source_path) -> dict:
    """Waliduje PDF (otwiera go), kopiuje do biblioteki i zapisuje metadane."""
    src = Path(source_path)
    if src.suffix.lower() != ".pdf":
        raise InputError(f"Plik {src.name} nie ma rozszerzenia .pdf.", "Wybierz dokument w formacie PDF.")
    with PdfDocument(src) as pdf:  # zgłosi PdfError dla uszkodzonego / zaszyfrowanego pliku
        info = pdf.info()
    digest = _sha256(src)
    lib = load_library()
    for doc in lib["documents"]:
        if doc["sha256"] == digest:
            raise InputError(f"Ten dokument jest już w bibliotece jako „{doc['title']}”.",
                             "Wybierz go z listy dokumentów zamiast importować ponownie.")
    doc_id = uuid.uuid4().hex[:10]
    stored = documents_dir() / f"{doc_id}.pdf"
    shutil.copy2(src, stored)
    record = {
        "id": doc_id, "title": info["title"] or src.stem, "file": src.name, "stored": stored.name,
        "original_path": str(src), "sha256": digest, "added": datetime.now().isoformat(timespec="seconds"),
        "pages": info["pages"], "author": info["author"], "has_text": info["has_text"],
        "likely_scanned": info["likely_scanned"], "size_bytes": info["size_bytes"],
        "assignments": [], "notes": "",
    }
    lib["documents"].append(record)
    save_library(lib)
    return record


def stored_path(doc: dict) -> Path:
    return documents_dir() / doc["stored"]


def get(doc_id) -> dict:
    for doc in load_library()["documents"]:
        if doc["id"] == doc_id:
            return doc
    raise InputError("Nie znaleziono dokumentu w bibliotece.", "Odśwież listę dokumentów.")


def update(doc_id, **fields):
    lib = load_library()
    for doc in lib["documents"]:
        if doc["id"] == doc_id:
            for key in ("title", "notes"):
                if key in fields:
                    doc[key] = fields[key]
            save_library(lib)
            return doc
    raise InputError("Nie znaleziono dokumentu w bibliotece.", "Odśwież listę dokumentów.")


def assign(doc_id, algorithm_id, role=ROLES[0], pages="", note=""):
    lib = load_library()
    for doc in lib["documents"]:
        if doc["id"] == doc_id:
            doc["assignments"] = [a for a in doc["assignments"] if a["algorithm"] != algorithm_id]
            doc["assignments"].append({"algorithm": algorithm_id, "role": role, "pages": pages, "note": note,
                                       "assigned": datetime.now().isoformat(timespec="seconds")})
            save_library(lib)
            return doc
    raise InputError("Nie znaleziono dokumentu w bibliotece.", "Odśwież listę dokumentów.")


def unassign(doc_id, algorithm_id):
    lib = load_library()
    for doc in lib["documents"]:
        if doc["id"] == doc_id:
            doc["assignments"] = [a for a in doc["assignments"] if a["algorithm"] != algorithm_id]
            save_library(lib)
            return doc
    raise InputError("Nie znaleziono dokumentu w bibliotece.", "Odśwież listę dokumentów.")


def remove(doc_id):
    lib = load_library()
    keep = [d for d in lib["documents"] if d["id"] != doc_id]
    removed = [d for d in lib["documents"] if d["id"] == doc_id]
    lib["documents"] = keep
    save_library(lib)
    for d in removed:  # usuwana jest tylko KOPIA w bibliotece, nigdy plik oryginalny
        p = stored_path(d)
        if p.exists():
            p.unlink()


def documents_for(algorithm_id) -> list[tuple[dict, dict]]:
    """Lista (dokument, przypisanie) dla algorytmu."""
    out = []
    for doc in load_library()["documents"]:
        for a in doc["assignments"]:
            if a["algorithm"] == algorithm_id:
                out.append((doc, a))
    return out


def open_document(doc: dict) -> PdfDocument:
    path = stored_path(doc)
    if not path.exists():
        raise PdfError(f"Brak pliku dokumentu w bibliotece ({path.name}).",
                       "Usuń wpis z biblioteki i zaimportuj dokument ponownie.")
    return PdfDocument(path)
