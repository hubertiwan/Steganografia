"""Odczyt dokumentów PDF (PyMuPDF): informacje, tekst, podgląd stron, wyszukiwanie.

Treść PDF jest traktowana wyłącznie jako materiał referencyjny – aplikacja niczego do niej
nie dopisuje ani nie interpretuje jej jako zweryfikowanej dokumentacji algorytmu.
"""
from dataclasses import dataclass
from pathlib import Path

from .errors import PdfError

# Strona z mniej niż tyloma znakami tekstu uznawana jest za „bez warstwy tekstowej”.
MIN_CHARS_PER_TEXT_PAGE = 25


def _fitz():
    try:
        import pymupdf  # PyMuPDF ≥ 1.24
        return pymupdf
    except ImportError:
        pass
    try:
        import fitz  # starsze wersje PyMuPDF
        return fitz
    except ImportError as exc:
        raise PdfError("Brak biblioteki PyMuPDF do obsługi PDF.",
                       "Zainstaluj zależności: pip install -r requirements-app.txt") from exc


@dataclass
class SearchHit:
    page: int          # numer strony od 0
    rects: list        # prostokąty w układzie strony (x0, y0, x1, y1)
    snippet: str


class PdfDocument:
    def __init__(self, path):
        fitz = _fitz()
        self.path = Path(path)
        if not self.path.exists():
            raise PdfError(f"Plik nie istnieje: {self.path}", "Wybierz plik PDF ponownie.")
        if self.path.stat().st_size == 0:
            raise PdfError(f"Plik {self.path.name} jest pusty.", "Wskaż poprawny dokument PDF.")
        try:
            self.doc = fitz.open(str(self.path), filetype="pdf")
        except Exception as exc:
            raise PdfError(f"Nie udało się otworzyć {self.path.name} jako PDF ({type(exc).__name__}).",
                           "Plik może być uszkodzony albo nie jest dokumentem PDF. Spróbuj otworzyć go w "
                           "innej przeglądarce PDF i zapisać ponownie.") from exc
        if self.doc.needs_pass:
            self.doc.close()
            raise PdfError(f"Dokument {self.path.name} jest zaszyfrowany hasłem.",
                           "Usuń zabezpieczenie hasłem (np. zapisując kopię bez hasła) i zaimportuj ponownie.")
        if self.doc.page_count == 0:
            self.doc.close()
            raise PdfError(f"Dokument {self.path.name} nie zawiera stron.", "Wskaż inny plik PDF.")
        self._texts = None

    def close(self):
        self.doc.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    @property
    def page_count(self):
        return self.doc.page_count

    def page_text(self, index: int) -> str:
        if self._texts is None:
            self._texts = []
            for page in self.doc:
                try:
                    self._texts.append(page.get_text("text"))
                except Exception:  # pojedyncza uszkodzona strona nie blokuje całego dokumentu
                    self._texts.append("")
        return self._texts[index]

    def full_text(self) -> str:
        return "\n".join(f"──── Strona {i + 1} ────\n{self.page_text(i)}" for i in range(self.page_count))

    def text_layer_stats(self) -> dict:
        chars = [len(self.page_text(i).strip()) for i in range(self.page_count)]
        text_pages = sum(c >= MIN_CHARS_PER_TEXT_PAGE for c in chars)
        return {"chars_total": sum(chars), "pages_with_text": text_pages,
                "pages_without_text": self.page_count - text_pages,
                "has_text": text_pages > 0,
                "likely_scanned": text_pages == 0 or text_pages < 0.5 * self.page_count}

    def info(self) -> dict:
        meta = {k: v for k, v in (self.doc.metadata or {}).items() if v}
        first = self.doc[0].rect
        return {"file": self.path.name, "path": str(self.path), "size_bytes": self.path.stat().st_size,
                "pages": self.page_count, "title": meta.get("title", ""), "author": meta.get("author", ""),
                "subject": meta.get("subject", ""), "keywords": meta.get("keywords", ""),
                "creator": meta.get("creator", ""), "producer": meta.get("producer", ""),
                "creation_date": meta.get("creationDate", ""), "format": meta.get("format", ""),
                "page_size_pt": (round(first.width), round(first.height)), **self.text_layer_stats()}

    def render_page(self, index: int, zoom: float = 1.5, highlights=None):
        """Zwraca (szerokość, wysokość, bajty RGB) strony; highlights – prostokąty do podświetlenia."""
        fitz = _fitz()
        if not 0 <= index < self.page_count:
            raise PdfError(f"Strona {index + 1} nie istnieje (dokument ma {self.page_count} stron).", "")
        page = self.doc[index]
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
        if highlights:
            # podświetlenie rysowane na kopii obrazu, dokument źródłowy pozostaje niezmieniony
            import numpy as np
            img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n).copy()
            for (x0, y0, x1, y1) in highlights:
                a, b = int(y0 * zoom), int(y1 * zoom)
                c, d = int(x0 * zoom), int(x1 * zoom)
                region = img[max(a, 0):b, max(c, 0):d, :3].astype(np.float32)
                region = region * 0.55 + np.array([255, 214, 0], dtype=np.float32) * 0.45
                img[max(a, 0):b, max(c, 0):d, :3] = region.astype(np.uint8)
            return pix.width, pix.height, img[:, :, :3].tobytes()
        return pix.width, pix.height, pix.samples

    def search(self, query: str, max_hits: int = 500) -> list[SearchHit]:
        query = (query or "").strip()
        if not query:
            return []
        hits = []
        for i, page in enumerate(self.doc):
            rects = page.search_for(query)
            if not rects:
                continue
            text = self.page_text(i)
            low = text.lower()
            pos = low.find(query.lower())
            if pos >= 0:
                snippet = text[max(0, pos - 60): pos + len(query) + 60].replace("\n", " ")
            else:  # dopasowanie np. przez dzielenie wyrazów między wierszami
                snippet = f"(dopasowanie na stronie {i + 1})"
            hits.append(SearchHit(i, [tuple(r) for r in rects], snippet.strip()))
            if len(hits) >= max_hits:
                break
        return hits
