"""Metryki oceny znaków wodnych tekstu.

Tam, gdzie repozytorium ma już implementację, używana jest ona bezpośrednio:
  * tpr_at_fpr, random_edits  – unigram_watermark.generation
  * auc, perplexity           – demo_synthid.py
Dodatkowo: przedział Wilsona dla proporcji (TPR/FPR z małej próby) i statystyki opisowe.

Metryki obrazowe (PSNR, MSE, MAE, SSIM) i BER celowo NIE są tu liczone – algorytmy z
repozytorium nie mają nośnika obrazowego ani wielobitowej wiadomości (zob. README_APP.md).
"""
import math

import numpy as np

from .paths import ensure_repo_on_path

ensure_repo_on_path()
from unigram_watermark import random_edits, tpr_at_fpr  # noqa: E402,F401  (random_edits re-eksportowane)


def auc(pos, neg):
    """ROC AUC = P(z_ze_znakiem > z_bez_znaku) – oryginalna funkcja z demo_synthid.py."""
    from demo_synthid import auc as repo_auc
    if len(pos) == 0 or len(neg) == 0:
        return None
    return float(repo_auc(list(pos), list(neg)))


def perplexity(lm, prompt, new_tokens):
    """Perplexity wygenerowanych tokenów przy danym poleceniu – funkcja z demo_synthid.py.
    Dla pustej generacji zwraca None (brak tokenów do oceny)."""
    from demo_synthid import perplexity as repo_perplexity
    if not new_tokens:
        return None
    value = repo_perplexity(lm.model, lm.tokenizer, prompt, list(new_tokens), lm.use_chat_template)
    return float(value) if math.isfinite(value) else None


def wilson_interval(successes: int, n: int, z: float = 1.959964):
    """95% przedział ufności Wilsona dla proporcji. Przy małej liczbie tekstów TPR/FPR
    obarczone są dużą niepewnością – raporty zawsze podają ten przedział."""
    if n == 0:
        return (None, None)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    lo, hi = max(0.0, centre - half), min(1.0, centre + half)
    # przypadki brzegowe są dokładne analitycznie (unikamy 0.9999999999999999 z arytmetyki float)
    if successes == 0:
        lo = 0.0
    if successes == n:
        hi = 1.0
    return (lo, hi)


def rate(flags):
    flags = [bool(f) for f in flags]
    k, n = sum(flags), len(flags)
    lo, hi = wilson_interval(k, n)
    return {"k": k, "n": n, "rate": (k / n) if n else None, "ci_low": lo, "ci_high": hi}


def describe(values):
    vals = np.asarray([v for v in values if v is not None], dtype=float)
    if vals.size == 0:
        return {"n": 0, "mean": None, "std": None, "median": None, "min": None, "max": None}
    return {"n": int(vals.size), "mean": float(vals.mean()),
            "std": float(vals.std(ddof=1)) if vals.size > 1 else 0.0,
            "median": float(np.median(vals)), "min": float(vals.min()), "max": float(vals.max())}


def empirical_tpr_at_fpr(z_wm, z_plain, fpr):
    """TPR przy progu dobranym tak, by FPR na tekstach bez znaku = fpr (jak w pracy).
    Przy n tekstach bez znaku najmniejszy sensowny FPR to 1/n – wtedy wynik jest oznaczany."""
    if len(z_wm) == 0 or len(z_plain) == 0:
        return None
    tpr, thr = tpr_at_fpr(z_wm, z_plain, fpr)
    return {"fpr": fpr, "tpr": tpr, "threshold": thr,
            "reliable": len(z_plain) * fpr >= 1.0}
